python -u crawler.py 2300 2675 > log-2300-2675.txt
