# -*- coding: utf-8 -*-

"""
Created on 2019-12-25 15:29  

@author: congyingxu

originals from LibDetectPy / localServer.py

Server的main文件

###目前已整理好buggy method的poj
['commons-collections', 'commons-codec', 'logging-log4j2', 'slf4j', 'commons-io', 'httpcomponents-client', 'commons-lang', 'logback', 'commons-cli', 'commons-logging']
这些项目在范围内
"""

from http.server import BaseHTTPRequestHandler
from http.server import HTTPServer
import sys
import json,sqlite3

sys.path.append('../')

from config.Config import Config

# BuggyMethodFilePath = '../BuggyMethodData.json'
# DBPath = '../DB/RISK_DB.sqlite'
# GAV_CVE_BuggyMethod_Filepath = '../GAV_CVE_BuggyMethod.json'

GAV_CVE_BuggyMethod = {}

BuggyMethodFilePath = ''
DBPath = ''
GAV_CVE_BuggyMethod_Filepath = ''


class PostHandler(BaseHTTPRequestHandler):



    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        post_data = json.loads(post_data)
        print('post data from client:')
        print(post_data)

        result_data = {}

        opration = post_data['opration']
        if opration == 'getBuggyMethod':
            Issuekey = post_data['issuekey']
            BuggyMethods = getBuggyMethods(Issuekey)
            result_data = BuggyMethods
        elif opration == 'getIssuekey':
            GAV = post_data['GAV']
            issuekeys = getIssuekeys(GAV)
            result_data = issuekeys
        elif opration == 'getCVEBuggyMethod':
            CVEID = post_data['cveid']
            GAV = post_data['GAV']
            BuggyMethods = getCVEBuggyMethod(GAV,CVEID)
            result_data = BuggyMethods
        elif opration == 'getCVEID':
            GAV = post_data['GAV']
            CVEIDs = getCVEIDs(GAV)
            result_data = CVEIDs

        self.send_response(200)
        self.end_headers()
        # self.wfile.write( bytes(str(result_data), encoding = "utf8" ))
        self.wfile.write( bytes(json.dumps( result_data ), encoding = "utf8"  ))

def init():
    global GAV_CVE_BuggyMethod
    # read
    with open(GAV_CVE_BuggyMethod_Filepath,'r') as f:
        GAV_CVE_BuggyMethod = json.loads(f.read())


def getCVEIDs(GAV):
    CVEIDs = []

    if GAV not in GAV_CVE_BuggyMethod.keys():
        return CVEIDs
    else:
        CVEIDs = list( GAV_CVE_BuggyMethod[GAV].keys() )

    CVEIDs = ["CVE-" + ele for ele in CVEIDs]
    return CVEIDs

def getCVEBuggyMethod(GAV,CVEID):
    CVEID = CVEID.split("CVE-")[1]
    # print(CVEID)
    result_data = []
    try:
        result_data = GAV_CVE_BuggyMethod[GAV][CVEID]
    except:
        result_data = ["Invalid Input!"]
    return result_data


def getBuggyMethods(Issuekey):
    BuggyMethods =[]
    with open(BuggyMethodFilePath,'r') as f:
        BuggyMethodData = json.loads(f.read())

    print(BuggyMethodData.keys())
    for poj in BuggyMethodData.keys():
        if Issuekey in BuggyMethodData[poj].keys():
            BuggyMethods  = BuggyMethodData[poj][Issuekey]
            break

    return BuggyMethods


def getIssuekeys(GAV):
    GroupId = GAV.split('__fdse__')[0]
    ArtifactID = GAV.split('__fdse__')[1]
    Version = GAV.split('__fdse__')[2]

    conn = sqlite3.connect(DBPath)
    cursor = conn.cursor()

    #找到GA 对应的prefix
    issue_name_prefix = ''
    sql = "select * from group_artifact_issue_map where group_id=? and artifact_id=?"
    cursor.execute(sql, (GroupId,ArtifactID,))
    values = cursor.fetchall()  # 返回最终一次sql结果，列表元组形式   #[(1, 'ch.qos.logback', .....), (2, 'commons-cli', ...)]
    for ele in values:
        issue_name_prefix = ele[5]

    #找到prefix中满足条件的issuekey
    sql = "select * from issues where issue_name_prefix=?"
    cursor.execute(sql, (issue_name_prefix,))
    values = cursor.fetchall()  # 返回最终一次sql结果，列表元组形式   #[(1, 'ch.qos.logback', .....), (2, 'commons-cli', ...)]

    issuekeys = []
    for ele in values:
        version_value = ele[3]
        issuekey = ele[2]
        if version_value == Version:
            issuekeys.append(issuekey)

    cursor.close()
    conn.commit()
    conn.close()

    return issuekeys

def StartServer():
    print('RiskDB server started')
    sever = HTTPServer(("", 10080), PostHandler)
    sever.serve_forever()


if __name__ == '__main__':
    config_path = "../config/path_config.properties"
    BuggyMethodFilePath = Config.instance(config_path).Buggy_Method_File_Path
    DBPath = Config.instance(config_path).RiskDB_Path
    GAV_CVE_BuggyMethod_Filepath = Config.instance(config_path).GAV_CVE_BuggyMethod_Filepath
    init()
    StartServer()