public class Test2 {
    public static void main(String[] args) {
        TEst tEst = new TEst();
        int a = tEst.c;
        TEst.Bucket bucket= new TEst.Bucket();
    }
}
