package gr.gousiosg.javacg.stat;

public class CheckMapResult {

	String methodString;
	boolean success;
	
	public CheckMapResult(String methodString,boolean success) {
		this.methodString = methodString;
		this.success = success;
	}
	
	public String getMethodString() {
		return this.methodString;
	}
	public boolean getSuccess() {
		return this.success;
	}
	
}
