public class TEst {
    private int a;
    public int b;
    int c;
    static final class Bucket {
    }
}
