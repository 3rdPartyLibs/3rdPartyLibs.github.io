package cn.edu.fudan.se.cfg.rq2.utils;

import cn.edu.fudan.se.cfg.CallGraphVisitor;
import cn.edu.fudan.se.cfg.SootFileUtils;
import cn.edu.fudan.se.cfg.SootUtil;
import cn.edu.fudan.se.util.JavaMethodUtil;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import soot.*;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.options.Options;
import soot.util.dot.DotGraph;
import soot.util.dot.DotGraphNode;

import java.lang.reflect.Field;
import java.util.*;

public class SootUtils {

    /**
     * 将method string转化为 SootMethod
     *
     * @param args
     * @param jarName
     * @param classesPath
     * @param methodNameString
     * @param outputPath
     * @return
     */
    public static List<SootMethod> convertStringToSootMethod(String args[], String jarName, String classesPath, String methodNameString, String outputPath) {
        List<String> classNames = new ArrayList<>();
        Map<String, List<String>> mmap = SootFileUtils.getClassNameAndMethodNames(methodNameString, classNames);
        G.reset();
        List<String> argsList = new ArrayList<>(Arrays.asList(args));
        //
        argsList.addAll(Arrays.asList(new String[]{"-allow-phantom-refs",
                "-w",
                // "-no-bodies-for-excluded",
                "-cp",
                //"C:\\cs\\jdk1.8.0_181\\jre\\lib\\jce;C:\\cs\\jdk1.8.0_181\\jre\\lib\\rt;" + classesPath,
                "C:/cs/jdk1.8.0_181/jre/lib/jce.jar;C:/cs/jdk1.8.0_181/jre/lib/rt.jar;" + classesPath,
                //classesPath,
                "-process-dir",
                classesPath,
                "jb",
                "enabled:true"}));

        args = argsList.toArray(new String[0]);
        Options.v().parse(args);
        Options.v().set_src_prec(Options.src_prec_java);
//        Options.v().set_process_dir(Collections.singletonList(processDir));
        Options.v().set_whole_program(true);
        Options.v().set_allow_phantom_refs(true);

//        Options.v().set_verbose(true);
        Options.v().set_output_format(Options.output_format_none);
        Options.v().setPhaseOption("cg.spark", "on");
        Options.v().set_no_bodies_for_excluded(true);
//        Options.v().set_app(true);
        //enableSpark();
        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
        List<SootMethod> entryPoints = SootUtil.loadEntryPoints(classNames, mmap);
        return entryPoints;
    }

    public static List<String> getInvokeMethodList(String args[], String jarName, String classesPath, String methodNameString, String outputPath, List<SootMethod> entryPoints) throws NoSuchFieldException, IllegalAccessException {

        CallGraphVisitor callGraphVisitor = new CallGraphVisitor(outputPath + "/" + jarName + ".dot");
        List<String> classNames = new ArrayList<>();
        Map<String, List<String>> mmap = SootFileUtils.getClassNameAndMethodNames(methodNameString, classNames);
        G.reset();
        List<String> argsList = new ArrayList<>(Arrays.asList(args));
        //
        argsList.addAll(Arrays.asList(new String[]{"-allow-phantom-refs", "-w",
                // "-no-bodies-for-excluded",
                "-cp",
                // "C:\\cs\\jdk1.8.0_181\\jre\\lib\\jce;C:\\cs\\jdk1.8.0_181\\jre\\lib\\rt;" + classesPath,
                "C:/cs/jdk1.8.0_181/jre/lib/jce.jar;C:/cs/jdk1.8.0_181/jre/lib/rt.jar;" + classesPath,
                //classesPath,
                "-process-dir",
                classesPath,
                "jb",
                "enabled:true"}));

        args = argsList.toArray(new String[0]);
        Options.v().parse(args);
        Options.v().set_src_prec(Options.src_prec_java);
//        Options.v().set_process_dir(Collections.singletonList(processDir));
        Options.v().set_whole_program(true);
        Options.v().set_allow_phantom_refs(true);

//        Options.v().set_verbose(true);
        Options.v().set_output_format(Options.output_format_none);
        Options.v().setPhaseOption("cg.spark", "on");
        Options.v().set_no_bodies_for_excluded(true);
//        Options.v().set_app(true);
        //enableSpark();
        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
        Scene.v().setEntryPoints(entryPoints);
        enableSpark();
        PackManager.v().runPacks();

        CallGraph callGraph = Scene.v().getCallGraph();
        for (SootMethod entryPoint : entryPoints) {
            callGraphVisitor.visit(callGraph, entryPoint);
        }
        DotGraph dotGraph = callGraphVisitor.getDot();
        Class<DotGraph> dotGraphClass = (Class<DotGraph>) dotGraph.getClass();
        Field nodesField = dotGraphClass.getDeclaredField("nodes");
        nodesField.setAccessible(true);
        HashMap<String, DotGraphNode> nodes = (HashMap<String, DotGraphNode>) nodesField.get(dotGraph);
        List<String> invokeList = new ArrayList<>();

        for (Map.Entry<String, DotGraphNode> entry : nodes.entrySet()) {
            //eg1:<org.openjdk.jmh.util.Utils: void check(java.lang.Class,java.lang.String)>
            //eg2:<java.lang.StringBuilder: void <init>()>
            String method = entry.getKey();
            int length = method.length();
            method = method.substring(1, length - 1);
            //method:java.lang.StringBuilder: void <init>()
            String className = method.split(": ")[0];
            String methodName = method.split(": ")[1];
            String invokeMethodName = className + "." + methodName.split(" ")[1];
            boolean isJDKMethod = JavaMethodUtil.isJDKMethod(className);
            if (!isJDKMethod) {
                //构造函数单独处理
            /*    if (methodName.contains(" <init>")) {
                    //className:org.openjdk.jmh.util.Optional
                    //methodName:void <init>(java.lang.Object)
                    String[] classNameStrs = className.split("\\.");
                    invokeMethodName = invokeMethodName.replace("<init>", classNameStrs[classNameStrs.length - 1]);
                    invokeList.add(invokeMethodName);
                } else if (methodName.contains(" <clinit>")) {
                    //invokeList.add("");
                } else {*/
                if (methodName.contains("<clinit>")) {
                    continue;
                }
                invokeList.add(invokeMethodName);
                //}
            }
        }

        //排序，方便后续比较
        Collections.sort(invokeList);
        return invokeList;
    }

    private static void enableSpark() {
        HashMap opt = new HashMap();
        opt.put("verbose", "true");
        opt.put("propagator", "worklist");
        opt.put("simple-edges-bidirectional", "false");
        opt.put("on-fly-cg", "true");
        opt.put("apponly", "true");
        opt.put("set-impl", "double");
        opt.put("double-set-old", "hybrid");
        opt.put("double-set-new", "hybrid");
        SparkTransformer.v().transform("", opt);
    }

    public static boolean compareSootMethod(SootMethod preSootMethod, SootMethod currSootMethod) {
       /* System.out.println(currSootMethod.retrieveActiveBody().toString());
        System.out.println(preSootMethod.retrieveActiveBody().toString());*/
        Body preBody = preSootMethod.retrieveActiveBody();
        Body currBody = currSootMethod.retrieveActiveBody();
        /*JimpleBody preJimple = (JimpleBody) preSootMethod.retrieveActiveBody();
        JimpleBody currJimple = (JimpleBody) currSootMethod.retrieveActiveBody();*/

        /*System.out.println(preJimple.toString());
        System.out.println(currJimple.toString());*/
//        DavaBody preDavaBody =  Dava.v().newBody(preSootMethod);
//        DavaBody currDavaBody =  Dava.v().newBody(currSootMethod);

        // GrimpBody preBody = Grimp.v().newBody(preSootMethod.retrieveActiveBody(), "gb");
//        GrimpBody preBody = Grimp.v().newBody(preSootMethod);
//        preSootMethod.setActiveBody(preBody);
//        System.out.println(preBody.toString());
//
//       // GrimpBody currBody = Grimp.v().newBody(currSootMethod.retrieveActiveBody(), "gb");
//        GrimpBody currBody = Grimp.v().newBody(currSootMethod);
//        currSootMethod.setActiveBody(currBody);
//        System.out.println(currBody.toString());

        //  System.out.println(preDavaBody + " " + currDavaBody);
        return true;
        // return preSootMethod.getActiveBody().toString().equals(currSootMethod.getActiveBody().toString());
    }

    public static boolean compareSootMethod2(SootMethod preSootMethod, SootMethod currSootMethod, String prevJar, String currJar) {
        if (!preSootMethod.toString().equals(currSootMethod.toString())) {
            return false;
        }
        List<BodyDeclaration> preBodyDeclarationList = JDTUtils.getCompilationUnitByJar(prevJar, preSootMethod.getDeclaringClass().toString().replaceAll("\\.", "/"));
        List<BodyDeclaration> currBodyDeclarationList = JDTUtils.getCompilationUnitByJar(currJar, currSootMethod.getDeclaringClass().toString().replaceAll("\\.", "/"));
        MethodDeclaration preBodyDeclaration = SootJDTAdapter.searchMethod(preSootMethod, preBodyDeclarationList);
        MethodDeclaration currBodyDeclaration = SootJDTAdapter.searchMethod(currSootMethod, currBodyDeclarationList);
        //判断是否是默认的构造方法
        boolean preDefaultConstructor = SootJDTAdapter.isDefaultConstructor(preSootMethod, preBodyDeclaration);
        boolean currDefaultConstructor = SootJDTAdapter.isDefaultConstructor(currSootMethod, currBodyDeclaration);
        if (preDefaultConstructor && currDefaultConstructor) {
            //如果两个都是默认的构造方法，直接返回相同
            return true;
        }

        if (preBodyDeclaration == null || currBodyDeclaration == null) {
            System.out.println("error: " + preSootMethod.getDeclaringClass().toString() + " " + preSootMethod.getName());
            System.out.println("error: " + currSootMethod.getDeclaringClass().toString() + " " + currSootMethod.getName());
        }
        if (preBodyDeclaration.getBody() == null && currBodyDeclaration.getBody() == null) {
            //接口 抽象类不考虑
            return true;
        }
        return preBodyDeclaration.getBody().toString().equals(currBodyDeclaration.getBody().toString());
    }
}
