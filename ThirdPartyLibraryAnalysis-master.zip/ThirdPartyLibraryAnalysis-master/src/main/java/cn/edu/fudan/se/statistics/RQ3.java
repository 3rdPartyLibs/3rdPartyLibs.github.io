package cn.edu.fudan.se.statistics;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import cn.edu.fudan.se.db.DB;
import cn.edu.fudan.se.git.JgitRepository;
import cn.edu.fudan.se.util.MyException;

public class RQ3 {
	public static void main(String[] args) {
//		String time1 = JgitRepository.stampToDate(1367078400);
//		String time2 = JgitRepository.stampToDate(1367141696);
//		System.out.println(time1);
//		System.out.println(time2);
//		updateReleaseTime();
//		DateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
//		String formatStr1 = "2018-01-20";
//		String formatStr2 = "2018-02-14";
//		Date date;
//		try {
//			date = format.parse(formatStr1);
//			System.out.println((int) (date.getTime()/1000));
//			date = format.parse(formatStr2);
//			System.out.println((int) (date.getTime()/1000));
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

//		System.out.println((1518537600-1516377600)/60/60/24);
//		updateReleaseTime();
		calculateTimeInterval();
//		castReleaseTimeToInt();
	}
	
	public static void calculateTimeInterval() {
		String sql = "insert into lib_update (id,time_interval) values ";
		int count = 0;
		for(int i = 650000;i<=700000;i++) {
			System.out.println("----------------------"+i);
			try {
				ResultSet rs = DB.query("SELECT * FROM `lib_update` where `id`= " + i);
				while (rs.next()) {
					count ++;
					int id = rs.getInt("id");
					int time1  = rs.getInt("curr_time");
					int time2 = rs.getInt("curr_release_time_num");
					if(time1 == -1 || time2 == -1)
						continue;
					int interval = (time1 - time2)/60/60;
										
					sql += "("+id+","+interval+"),";
					if(count == 5000) {
						if(sql.endsWith(","))
							sql = sql.substring(0, sql.length()-1);
						sql += " on duplicate key update time_interval=values(time_interval)";
						System.out.println(sql);
						DB.update(sql);
						
						count = 0;
						sql = "insert into lib_update (id,time_interval) values ";
					}
					
				}		
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		if(sql.endsWith(",")) {
			sql = sql.substring(0, sql.length()-1);
			System.out.println(sql);
			sql += " on duplicate key update time_interval=values(time_interval)";
			DB.update(sql);
		}			
	}	
	
	public static void castReleaseTimeToInt() {
		String sql = "insert into lib_update (id,prev_release_time_num,curr_release_time_num) values ";
		int count = 0;
		for(int i = 800000;i<=820000;i++) {
			System.out.println("----------------------"+i);
			try {
				ResultSet rs = DB.query("SELECT * FROM `lib_update` where `id`= " + i);
				while (rs.next()) {
					count ++;
					int id = rs.getInt("id");
					String prevTime  = rs.getString("prev_release_time");
					String currTime  = rs.getString("curr_release_time");
					int time1 = -1,time2 = -1;
					if(prevTime != null && !prevTime.equals("NULL")) {
						time1 = dateToInt(prevTime);
					}
					if(currTime != null && !currTime.equals("NULL")) {
						time2 = dateToInt(currTime);
					}
//					sql += "("+id+",";
//					if(time1 == -1)
//						sql += "'NULL',";
//					else
//						sql += time1+",";
//					if(time2 == -1)
//						sql += "'NULL'),";
//					else
//						sql += time2+"),";
//					System.out.println(time1);
//					System.out.println(time2);
//					System.out.println();
										
					sql += "("+id+","+time1+","+time2+"),";
					if(count == 5000) {
						if(sql.endsWith(","))
							sql = sql.substring(0, sql.length()-1);
						sql += " on duplicate key update prev_release_time_num=values(prev_release_time_num),curr_release_time_num=values(curr_release_time_num)";
						System.out.println(sql);
						DB.update(sql);
						
						count = 0;
						sql = "insert into lib_update (id,prev_release_time_num,curr_release_time_num) values ";
					}
					
				}		
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		if(sql.endsWith(",")) {
			sql = sql.substring(0, sql.length()-1);
			System.out.println(sql);
			sql += " on duplicate key update prev_release_time_num=values(prev_release_time_num),curr_release_time_num=values(curr_release_time_num)";
			DB.update(sql);
		}
			
	}	
	
	public static int dateToInt(String dateStr) {
		try {
			dateStr =dateStr.trim();
//			System.out.println(dateStr.startsWith("("));
//			System.out.println(dateStr.endsWith(")"));
//			System.out.println(!dateStr.startsWith("(") || !dateStr.endsWith(")"));
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
			if(dateStr.startsWith("(") && dateStr.endsWith(")")) {
				dateStr = dateStr.substring(1, dateStr.length()-1);
				String[] data = dateStr.split(",");				
				if(data.length != 2)
					throw new MyException("can't split by ,:"+dateStr);	
				String year = data[1].trim();
				String[] day = data[0].split(" ");
				if(day.length != 2)
					throw new MyException("can't split by ,:"+dateStr);	
				String formatStr = year+"-"+parseMonth(day[0])+"-"+day[1];
//				System.out.println(formatStr);
				Date date = format.parse(formatStr);
				return (int) (date.getTime()/1000);
//				System.out.println(date.getTime()/1000);

			}
			else {		 	
				throw new MyException("no parentheses:"+dateStr);					
			}
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(0);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(0);
		}
		return -1;
	}
	
	public static String parseMonth(String input) {
		switch(input){
		case "Jan":
			return "01";
		case "Feb":
			return "02";
		case "Mar":
			return "03";
		case "Apr":
			return "04";
		case "May":
			return "05";
		case "Jun":
			return "06";
		case "Jul":
			return "07";
		case "Aug":
			return "08";
		case "Sep":
			return "09";	
		case "Oct":
			return "10";
		case "Nov":
			return "11";
		case "Dec":
			return "12";
		}
		return "";
	}
	
	public static void updateReleaseTime() {
		String sql = "insert into lib_update (id,prev_release_time,curr_release_time) values ";
		int count = 0;
		for(int i = 0;i<=10;i++) {
			System.out.println("----------------------"+i);
			try {
				ResultSet rs = DB.query("SELECT * FROM `lib_update` where `id`= " + i);
				while (rs.next()) {
					count ++;
//					System.out.println(count);
					int id = rs.getInt("id");
					String group  = rs.getString("group_str");
					String name  = rs.getString("name_str");
					String prevVersion  = rs.getString("prev_version");
					String currVersion  = rs.getString("curr_version");
					String key1 = group +" "+ name +" "+ prevVersion;
					String key2 = group +" "+ name +" "+ currVersion;
					String time1 = null,time2 = null;
					ResultSet trs1 = DB.query("SELECT * FROM `lib_release_time` where `lib_name`= '" + key1+"'");
					while (trs1.next()) {
						time1 = trs1.getString("time");
						break;
					}
					ResultSet trs2 = DB.query("SELECT * FROM `lib_release_time` where `lib_name`= '" + key2+"'");
					while (trs2.next()) {
						time2 = trs2.getString("time");
						break;
					}
					if(time1 == null)
						time1 = "NULL";
					if(time2 == null)
						time2 = "NULL";
					System.out.println(time1 +" "+ time2);
					if(!(time1.equals("NULL")&&time2.equals("NULL"))) {
						sql += "("+id+",'"+time1+"','"+time2+"'),";
						if(count == 5000) {
							if(sql.endsWith(","))
								sql = sql.substring(0, sql.length()-1);
							sql += " on duplicate key update prev_release_time=values(prev_release_time),curr_release_time=values(curr_release_time)";
							System.out.println(sql);
							DB.update(sql);
							
							count = 0;
							sql = "insert into lib_update (id,prev_release_time,curr_release_time) values ";
						}
					}
					
				}		
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		if(sql.endsWith(",")) {
			sql = sql.substring(0, sql.length()-1);
			System.out.println(sql);
			sql += " on duplicate key update prev_release_time=values(prev_release_time),curr_release_time=values(curr_release_time)";
			DB.update(sql);
		}
			
	}
	
	
}
