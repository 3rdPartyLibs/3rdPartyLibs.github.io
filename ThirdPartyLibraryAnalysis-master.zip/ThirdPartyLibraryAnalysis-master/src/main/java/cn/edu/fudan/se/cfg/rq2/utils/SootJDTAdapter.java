package cn.edu.fudan.se.cfg.rq2.utils;

import org.eclipse.jdt.core.dom.*;
import org.w3c.dom.NodeList;
import soot.Body;
import soot.SootMethod;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SootJDTAdapter {

    public static MethodDeclaration searchMethod(SootMethod sootMethod, List<BodyDeclaration> bodyDeclarationList) {

        //比较方法名、返回值、参数列表，如果比较成功则返回，否则返回null
        for (BodyDeclaration bodyDeclaration : bodyDeclarationList) {
            if (bodyDeclaration instanceof MethodDeclaration) {
                //如果不是构造函数，需要比较名字
                if (!sootMethod.isConstructor() || !((MethodDeclaration) bodyDeclaration).isConstructor()) {
                    String sootMethodName = sootMethod.getName();
                    String jdtMethodName = ((MethodDeclaration) bodyDeclaration).getName().toString();
                    if (!sootMethodName.equals(jdtMethodName)) {
                        continue;
                    }
                }
                Map<String, String> typeMap = handleTypeParameters(bodyDeclaration);
                String sootReturnTypeStr = sootMethod.getReturnType().toString();
                Type jdtReturnType = ((MethodDeclaration) bodyDeclaration).getReturnType2();
                String jdtReturnTypeStr = handleJDTType(jdtReturnType, typeMap);
                boolean returnTypeEquals = typeEquals(sootReturnTypeStr, jdtReturnTypeStr);
                if (!returnTypeEquals) {
                    continue;
                }

                List<soot.Type> sootParams = sootMethod.getParameterTypes();
                List<Type> jdtParams = ((MethodDeclaration) bodyDeclaration).parameters();
                boolean paramsSame = paramListEquals(sootParams, jdtParams, typeMap);
                if (paramsSame) {
                    return (MethodDeclaration) bodyDeclaration;
                }
            }
        }

        return null;
    }

    //
    private static Map<String, String> handleTypeParameters(BodyDeclaration bodyDeclaration) {
        Map<String, String> typeMap = new HashMap<>();
        List<TypeParameter> typeParameters = ((MethodDeclaration) bodyDeclaration).typeParameters();
        TypeDeclaration parent = (TypeDeclaration) bodyDeclaration.getParent();
        //parent.typeParameters();
        //typeParameters.addAll(((TypeDeclaration) bodyDeclaration.getParent()).typeParameters());
        List<TypeParameter> parentTypeParameters = parent.typeParameters();
        parentTypeParameters.addAll(typeParameters);
        for (TypeParameter typeParameter : parentTypeParameters) {
            String[] types = typeParameter.toString().trim().split(" ");
            if (types.length == 3) {
                typeMap.put(types[0], types[2]);
            }
        }
        return typeMap;
    }

    /**
     * 对JDT的类型做一些特殊处理
     *
     * @param jdtReturnType
     * @param typeMap
     * @return
     */
    private static String handleJDTType(ASTNode jdtReturnType, Map<String, String> typeMap) {
        String jdtReturnTypeStr = jdtReturnType == null ? "void" : jdtReturnType.toString();

        if (typeMap.containsKey(jdtReturnTypeStr)) {
            jdtReturnTypeStr = typeMap.get(jdtReturnTypeStr);
        }
        return jdtReturnTypeStr;
    }

    //参数列表是否相同
    private static boolean paramListEquals(List<soot.Type> sootParams, List<Type> jdtParams, Map<String, String> typeMap) {
        int sootSize = sootParams.size();
        int jdtSize = jdtParams.size();
        if (sootSize != jdtSize) {
            return false;
        }

        for (int index = 0; index < sootSize; index++) {
            soot.Type sootType = sootParams.get(index);
            ASTNode jdtType = jdtParams.get(index);
            String jdtTypeStr = handleJDTType(jdtType, typeMap);
            boolean same = typeEquals(sootType.toString(), jdtTypeStr.split(" ")[0]);
            if (!same) {
                return false;
            }
        }
        return true;
    }


    //类型是否相同
    private static boolean typeEquals(String sootType, String jdtType) {
        //sootType : java.lang.String
        //jdtType : String || java.lang.String ||String ...||Map<String,String>
        if (jdtType.contains("...")) {
            jdtType = jdtType.replace("...", "[]").trim();
        }
        if (jdtType.contains("<")) {
            int startIndex = jdtType.indexOf("<");
            //int endIndex = jdtType.indexOf(">");
            jdtType = jdtType.substring(0, startIndex);
        }
        String[] sootReturnTypes = sootType.split("\\.");
        int sootReturnTypeSize = sootReturnTypes.length;
        if (!sootType.equals(jdtType) && !sootReturnTypes[sootReturnTypeSize - 1].equals(jdtType)) {
            return false;
        }
        return true;
    }


    public static boolean isDefaultConstructor(SootMethod sootMethod, MethodDeclaration bodyDeclaration) {

        //jdt找不到对应方法且这个方法是构造方法，视为默认构造方法
        if (bodyDeclaration == null && sootMethod.isConstructor()) {
            return true;
        }
        return false;
    }
}
