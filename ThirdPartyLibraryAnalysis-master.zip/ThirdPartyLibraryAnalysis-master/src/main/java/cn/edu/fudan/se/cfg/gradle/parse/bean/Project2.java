package cn.edu.fudan.se.cfg.gradle.parse.bean;

import java.util.ArrayList;
import java.util.List;

public class Project2 {

    List<DependencyUrl> dependencyUrlList;

    List<DependencyUrl> parentDependencyUrlList;

    public Project2() {
    }


    public Project2(List<DependencyUrl> dependencyUrlList,List<DependencyUrl> parentDependencyUrlList) {
        this.dependencyUrlList = dependencyUrlList;
        this.parentDependencyUrlList = parentDependencyUrlList;
    }

    public List<DependencyUrl> getDependencyUrlList() {
        if (dependencyUrlList == null) {
            dependencyUrlList = new ArrayList<>();
        }

        return dependencyUrlList;
    }

    public void setDependencyUrlList(List<DependencyUrl> dependencyUrlList) {
        this.dependencyUrlList = dependencyUrlList;
    }

    public List<DependencyUrl> getParentDependencyUrlList() {
        if(parentDependencyUrlList == null){
            parentDependencyUrlList = new ArrayList<>();
        }
        return parentDependencyUrlList;
    }

    public void setParentDependencyUrlList(List<DependencyUrl> parentDependencyUrlList) {
        this.parentDependencyUrlList = parentDependencyUrlList;
    }
}
