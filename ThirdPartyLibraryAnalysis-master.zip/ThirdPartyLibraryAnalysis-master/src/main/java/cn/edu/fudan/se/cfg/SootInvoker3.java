package cn.edu.fudan.se.cfg;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;
import org.apache.commons.io.IOUtils;
import soot.*;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Targets;
import soot.options.Options;
import soot.util.dot.DotGraph;

import java.io.*;
import java.util.*;

/**
 * Created by huangkaifeng on 2018/9/13.
 */
public class SootInvoker3 {

    public static void main(String args[]){

        String inputPath = "C:/Users/huangkaifeng/Desktop/temp";
        File f = new File(inputPath);
        File[] files = f.listFiles();
        List<String> unzipPath  = new ArrayList<>();
        List<String> jarPath = new ArrayList<>();
        for(File tmp:files){
            if(tmp.getAbsolutePath().endsWith(".jar")){
                String newPath = tmp.getAbsolutePath().substring(0,tmp.getAbsolutePath().length()-4)+"_unzip";
                File ff = new File(newPath);
                if(!ff.exists()){
                    ZipUtil.zip(tmp.getAbsolutePath(),newPath);
                }
                unzipPath.add(newPath);
                jarPath.add(tmp.getAbsolutePath());
            }
        }
        JSONObject jo = SootFileUtils.fromJsonText(inputPath+"/meta.txt");
        String prevJar = jo.getString("prev_jar");
        String currJar = jo.getString("curr_jar");
        JSONArray jaPrev = (JSONArray)jo.get("prev_api_call_list");
        JSONArray jaCurr = (JSONArray)jo.get("curr_api_call_list");
        for(int i =0;i<jarPath.size();i++){
            String item  = jarPath.get(i);
            String item2 = unzipPath.get(i);
            if(item.contains(prevJar)){
                invokeSoot(args,prevJar,item2,jaPrev,inputPath);
            }
            if(item.contains(currJar)){
                invokeSoot(args,currJar,item2,jaCurr,inputPath);
            }
        }
    }


    public static void invokeSoot(String args[],String jarName,String classesPath,JSONArray methodNames,String outputPath){
        CallGraphVisitor callGraphVisitor = new CallGraphVisitor(outputPath+"/"+jarName+".dot");
        List<String> classNames = new ArrayList<>();
        Map<String,List<String>> mmap = SootFileUtils.getClassNameAndMethodNames(methodNames,classNames);
        G.reset();
        List<String> argsList = new ArrayList<>(Arrays.asList(args));
        //
        argsList.addAll(Arrays.asList(new String[] {"-android-jars","C:/Users/huangkaifeng/Desktop/SootExec/android.jar","-allow-phantom-refs", "-w",
                // "-no-bodies-for-excluded",
                "-cp", classesPath, "-process-dir",
                classesPath }));

        args = argsList.toArray(new String[0]);
        Options.v().parse(args);
        Options.v().set_src_prec(Options.src_prec_java);
//        Options.v().set_process_dir(Collections.singletonList(processDir));
        Options.v().set_whole_program(true);
        Options.v().set_allow_phantom_refs(true);

//        Options.v().set_verbose(true);
        Options.v().set_output_format(Options.output_format_none);
        Options.v().setPhaseOption("cg.spark", "on");
        Options.v().set_no_bodies_for_excluded(true);
//        Options.v().set_app(true);
        enableSpark();
        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
//        String mainClass = "Test1";
//        SootClass c = loadClass("org.openjdk.jmh.runner.options.ChainedOptionsBuilder",false);
        List<SootMethod> entryPoints = SootUtil.loadEntryPoints(classNames,mmap);
        Scene.v().setEntryPoints(entryPoints);
//        enableSpark();
        PackManager.v().runPacks();
        CallGraph callGraph = Scene.v().getCallGraph();
        for(SootMethod entryPoint:entryPoints) {
            callGraphVisitor.visit(callGraph, entryPoint);
        }
        SootFileUtils.toFile(outputPath.substring(0,outputPath.length()-4)+"/"+jarName+"_dot.dot",callGraphVisitor.getDot());
    }



    private static SootClass loadClass(String name, boolean main) {
        SootClass c = Scene.v().loadClassAndSupport(name);
        c.setApplicationClass();
        if (main)
            Scene.v().setMainClass(c);
        return c;
    }


    private static void enableSpark(){
        HashMap opt = new HashMap();
        opt.put("verbose","true");
        opt.put("propagator","worklist");
        opt.put("simple-edges-bidirectional","false");
        opt.put("on-fly-cg","true");
        opt.put("apponly", "true");
        opt.put("set-impl","double");
        opt.put("double-set-old","hybrid");
        opt.put("double-set-new","hybrid");
        SparkTransformer.v().transform("",opt);
    }




}

