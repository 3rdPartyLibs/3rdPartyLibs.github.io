package cn.edu.fudan.se.cfg.rq1;

public class MethodPublic {
    public static void main(String[] args) {

        for (int i = 0;i<2000;i++){
            if (isPublic(i)){
                System.out.println(i);
            }
        }

    }

    public static boolean isPublic(int m){
        return (m & 1) != 0;
    }

}
