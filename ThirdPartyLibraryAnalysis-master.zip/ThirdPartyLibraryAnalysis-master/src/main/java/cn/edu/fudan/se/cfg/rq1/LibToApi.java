package cn.edu.fudan.se.cfg.rq1;

import cn.edu.fudan.se.cfg.rq1.bean.ClassField;
import cn.edu.fudan.se.cfg.rq1.bean.Field;
import cn.edu.fudan.se.cfg.rq1.bean.Method;
import cn.edu.fudan.se.cfg.rq1.utils.SootClassUtils;
import cn.edu.fudan.se.cfg.rq2.utils.JDTUtils;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import soot.SootClass;
import soot.SootField;
import soot.SootMethod;
import soot.util.Chain;

import java.io.File;
import java.util.*;

public class LibToApi {

    private static String SOURCE_PATH = ":\\wangying\\rq1/lib0.json";
    //private static String JAR_DIR = ":\\wangying\\rq1/lib\\";
    private static String JAR_DIR = "H:\\wangying\\lib_all\\";
    private static String DECOMPILE_OUTPUT_DIR = ":\\wangying\\rq1\\decompile\\";
    static String BASE_OUTPUT = ":/wangying/rq1/lib_to_field/";
    static String NORMAL_OUTPUT = "";
    static String EXCEPTION_OUTPUT = "";


    public static void main(String[] args) {

        String wyDisk = args[0];
        SOURCE_PATH = wyDisk + SOURCE_PATH;
        BASE_OUTPUT = wyDisk + BASE_OUTPUT;
        NORMAL_OUTPUT = BASE_OUTPUT + "lib_field/";
        EXCEPTION_OUTPUT = BASE_OUTPUT + "exception/";
        DECOMPILE_OUTPUT_DIR = wyDisk + DECOMPILE_OUTPUT_DIR;
        //JAR_DIR = wyDisk + JAR_DIR;

        initDir();

        List<String> jarList = new Gson().fromJson(FileUtil.read(SOURCE_PATH), new TypeToken<List<String>>() {
        }.getType());

        for (String jar : jarList) {

            if (jar.contains("byteman-4.0.1")) {
                int a = 1;
            }
            File resultFile1 = new File(NORMAL_OUTPUT + jar + ".json");
            File resultFile2 = new File(EXCEPTION_OUTPUT + jar + ".json");
            System.out.println(jar);
            if (resultFile1.exists() || resultFile2.exists()) {
                continue;
            }
            String outputPath = JDTUtils.decompileJar(JAR_DIR + jar, DECOMPILE_OUTPUT_DIR);
            System.out.println(outputPath);
            List<String> paths = getAllJavaFile(outputPath);
            List<ClassField> result = new ArrayList<>();
            int index = 0;
            try {
                for (String path : paths) {
                    String className = path.substring(DECOMPILE_OUTPUT_DIR.length() + jar.replace(".jar", "_decompile\\").length());
                    className = className.replace("\\", ".");
                    className = className.substring(0, className.length() - 5);
                    System.out.println(String.valueOf(index) + "/" + String.valueOf(paths.size()) + " " + className);
                    index++;
                    SootClass sootClass = SootClassUtils.loadSootClass(JAR_DIR + jar, className, index);
                    List<Field> sootFieldResultList = new ArrayList<>();
                    List<Method> sootMethodResultList = new ArrayList<>();
                    List<SootMethod> sootMethodList = sootClass.getMethods();
                    for (SootMethod sootMethod : sootMethodList) {
                        sootMethodResultList.add(new Method(sootMethod.toString(), sootMethod.getModifiers()));
                    }
                    Chain<SootField> sootFields = sootClass.getFields();
                    Iterator<SootField> iterator = sootFields.iterator();
                    while (iterator.hasNext()) {
                        SootField temp = iterator.next();
                        sootFieldResultList.add(new Field(temp.getType().toString(), temp.getName(), temp.getModifiers()));
                    }
                    result.add(new ClassField(sootClass.getName(), sootFieldResultList, sootMethodResultList));
                }
                Gson gson = new GsonBuilder().setPrettyPrinting().create();
                FileUtil.writeFlie(NORMAL_OUTPUT + jar + ".json", gson.toJson(result));
                removeDir(outputPath);
            } catch (Exception e) {
                e.printStackTrace();
                FileUtil.writeFlie(EXCEPTION_OUTPUT + jar + ".json", e.getMessage() == null ? "" : e.getMessage());
            }

        }
    }

    private static void initDir() {
 /*       SOURCE_PATH = wdDisk + SOURCE_PATH;
        BASE_OUTPUT = wyDisk + BASE_OUTPUT;
        NORMAL_OUTPUT = BASE_OUTPUT + "lib_field/";
        EXCEPTION_OUTPUT = BASE_OUTPUT + "exception/";
        DECOMPILE_OUTPUT_DIR = wyDisk + DECOMPILE_OUTPUT_DIR;
        JAR_DIR = wyDisk + JAR_DIR;*/
        if (!new File(NORMAL_OUTPUT).exists()){
            new File(NORMAL_OUTPUT).mkdirs();
        }
        if (!new File(EXCEPTION_OUTPUT).exists()){
            new File(EXCEPTION_OUTPUT).mkdirs();
        }
        if (!new File(DECOMPILE_OUTPUT_DIR).exists()){
            new File(DECOMPILE_OUTPUT_DIR).mkdirs();
        }
    }

    private static List<String> getAllJavaFile(String outputPath) {

        Queue<String> q = new LinkedList<>();
        q.offer(outputPath);
        List<String> javaPaths = new ArrayList<>();
        while (!q.isEmpty()) {
            String path = q.poll();

            if (new File(path).isDirectory()) {
                File[] files = new File(path).listFiles();

                for (File file : files) {
                    q.offer(file.getAbsolutePath());
                }
            } else if (new File(path).isFile()) {
                if (path.endsWith(".java"))
                    javaPaths.add(path);
            }

        }
        return javaPaths;
    }

    /**
     * delete Dir
     *
     * @param unZipDir
     */
    private static void removeDir(String unZipDir) {
        System.out.println(unZipDir + "remove start");
        delFolder(unZipDir); //删除完里面所有内容
        System.out.println(unZipDir + "remove end");
    }

    //param folderPath 文件夹完整绝对路径
    public static void delFolder(String folderPath) {
        try {
            delAllFile(folderPath); //删除完里面所有内容
            String filePath = folderPath;
            filePath = filePath.toString();
            java.io.File myFilePath = new java.io.File(filePath);
            myFilePath.delete(); //删除空文件夹
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //删除指定文件夹下所有文件
//param path 文件夹完整绝对路径
    public static boolean delAllFile(String path) {
        boolean flag = false;
        File file = new File(path);
        if (!file.exists()) {
            return flag;
        }
        if (!file.isDirectory()) {
            return flag;
        }
        String[] tempList = file.list();
        File temp = null;
        for (int i = 0; i < tempList.length; i++) {
            if (path.endsWith(File.separator)) {
                temp = new File(path + tempList[i]);
            } else {
                temp = new File(path + File.separator + tempList[i]);
            }
            if (temp.isFile()) {
                temp.delete();
            }
            if (temp.isDirectory()) {
                delAllFile(path + "/" + tempList[i]);//先删除文件夹里面的文件
                delFolder(path + "/" + tempList[i]);//再删除空文件夹
                flag = true;
            }
        }
        return flag;
    }

}
