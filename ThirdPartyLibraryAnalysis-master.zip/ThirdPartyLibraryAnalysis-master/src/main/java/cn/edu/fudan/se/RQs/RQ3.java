package cn.edu.fudan.se.RQs;

import cn.edu.fudan.se.git.IssueCommitId;
import cn.edu.fudan.se.git.IssueUtil;
import cn.edu.fudan.se.git.JgitRepository;
//import cn.edu.fudan.se.git.ProjectVersion;
import cn.edu.fudan.se.preprocessingfile.FilePairPreDiff;
import cn.edu.fudan.se.preprocessingfile.JDTParserFactory;
import cn.edu.fudan.se.preprocessingfile.data.BodyDeclarationPair;
import cn.edu.fudan.se.util.FileUtil;
//import cn.edu.fudan.se.util.JavaMethodUtil;
//import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.*;
//import jdk.internal.util.xml.impl.Input;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
//import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import java.io.File;
import java.io.InputStream;
import java.util.Map;
import java.util.Map.Entry;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by huangkaifeng on 2018/11/9.
 */
public class RQ3 {

    public static void main(String[] args) {
//        runGit();
        try {
            readGitChangeFiles(args[0], args[1], args[2], args[3]);
        }catch(Exception e){
             System.out.print("Exception:");
             System.out.println(args[0]+" "+args[1]+" "+ args[2]+" "+ args[3]);
        }
//        test();
//        genBatchCmds();
    }
    public static void genBatchCmds(){
        String[] issueFiles = {"CLI", "CODEC", "COLLECTIONS", "COMMON-IO", "LANG", "LOGGING", "HTTPCLIENT", "LOGBACK", "LOG4J2", "SLF4J"};
        String basePath = "C:\\Users\\huangkaifeng\\Desktop\\RQ3";
        String[] projectNames = {"commons-cli", "commons-codec", "commons-collections", "commons-io", "commons-lang",
                "commons-logging", "httpcomponents-client", "logback", "logging-log4j2", "slf4j"};
        String inputPath = basePath+"\\commits\\";
        String outputPath = basePath+"\\output2\\";
        for(int i =0;i<issueFiles.length;i++){
            String a =issueFiles[i];
            String b = projectNames[i];
            String gitPath = basePath+"\\git\\"+b+"\\.git";
            String filePath = inputPath+a+".txt";
            String content = FileUtil.read(filePath);
            JSONArray jsonArray=JSONArray.parseArray(content.trim());
            Iterator iterator = jsonArray.iterator();
            try {
                while (iterator.hasNext()) {
//                    System.out.println(gitPath);
                    JSONObject jo = (JSONObject) iterator.next();
                    System.out.println("java -jar RQ3.jar "+gitPath+" "+projectNames[i]+" "+jo.getString("commitId")+" "+jo.getString("issueId"));
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    public static void runGit(){
        String basePath = "C:\\Users\\huangkaifeng\\Desktop\\RQ3";
        String issuePath = basePath+"\\issues\\";
        String outputPath = basePath+"\\output\\";
        String realIssuePath = basePath+"\\projects2\\";
        String[] projectNames = {"commons-cli", "commons-codec", "commons-collections", "commons-io", "commons-lang",
                "commons-logging", "httpcomponents-client", "logback", "logging-log4j2", "slf4j"};
        String[] issueFiles = {"CLI", "CODEC", "COLLECTIONS", "COMMON-IO", "LANG", "LOGGING", "HTTPCLIENT", "LOGBACK", "LOG4J2", "SLF4J"};
        List<String> issueIds = new ArrayList<>();
        String currentProjectName;
        StringBuffer sb ;
        List<String> out = new ArrayList<>();
        for (int index = 0; index < projectNames.length; index++) {
            issueIds.clear();
            issueIds = IssueUtil.getRealUniqueIssueId(issuePath + issueFiles[index] + ".txt",realIssuePath + issueFiles[index] + ".txt");
            currentProjectName = issueFiles[index];
            System.out.println("=======");
            System.out.println(currentProjectName);
            JgitRepository jgit = new JgitRepository();
            String gitPath = basePath +"\\git\\"+ projectNames[index] + "\\.git";
            String repositoryPath = basePath +"\\git\\" +projectNames[index];
            if(index ==3){
                jgit.setCurrentProjectName("IO");
            }else {
                jgit.setCurrentProjectName(issueFiles[index]);
            }
            jgit.buildRepository(gitPath, -1);
            jgit.walkRepository(repositoryPath);
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            FileUtil.writeFlie(outputPath + currentProjectName + ".txt", gson.toJson(jgit.getIssueCommitIdList()));
            Map<String,String> flag = new HashMap<>();
            for(IssueCommitId item:jgit.getIssueCommitIdList()){
                if(issueIds.contains(item.getIssueId())){
                    flag.put(item.getIssueId(),"a");
                }
            }
            sb = new StringBuffer();
            sb.append(issueFiles[index]);
            sb.append(": ");
            sb.append(flag.size());
            sb.append("/");
            sb.append(issueIds.size());
            out.add(sb.toString());
        }
        for(String s:out){
            System.out.println(s);
        }
    }
    public static void test(){
        try {
            String gitPath = "C:\\Users\\huangkaifeng\\Desktop\\RQ3\\git\\commons-cli\\.git";
            JgitRepository jgit = new JgitRepository();
            jgit.buildRepository(gitPath, -1);
            List<String> addedMethodList = new ArrayList<>();
            List<String> deletedMethodList = new ArrayList<>();
            List<String> modifiedMethodList = new ArrayList<>();
            String commitId = "7054900f3187c70c60e9e86f1c2bcd4c13d7878f";
            Map<String, Map<String, List<String>>> mMap = jgit.getCommitParentMappedFileList(commitId);
            for (Entry<String, Map<String, List<String>>> entry : mMap.entrySet()) {
                String parentId = entry.getKey();
                Map<String, List<String>> changedFiles = entry.getValue();
                List<String> addedFiles = changedFiles.get("addedFiles");
                List<String> removedFiles = changedFiles.get("deletedFiles");
                List<String> modifiedFiles = changedFiles.get("modifiedFiles");
                //todo added removed
                for (String addFile : addedFiles) {
                    if (!addFile.endsWith(".java")) {
                        continue;
                    }
                    InputStream prevIS = jgit.extract(addFile, commitId);
                    JSONObject methods = methodNameList(prevIS,"add");
//                    addedMethodList.addAll(methods);
                }
                for (String file : removedFiles) {
                    if (!file.endsWith(".java")) {
                        continue;
                    }
                    InputStream currIS = jgit.extract(file, parentId);
                    JSONObject methods = methodNameList(currIS,"delete");
//                    deletedMethodList.addAll(methods);
                }
                //todo modified
                for (String file : modifiedFiles) {
                    if (!file.endsWith(".java")) {
                        continue;
                    }
                    InputStream prevIS = jgit.extract(file, parentId);
                    byte[] prev = FileUtil.toByteArray(prevIS);
                    InputStream currIS = jgit.extract(file, commitId);
                    byte[] curr = FileUtil.toByteArray(currIS);
                    FilePairPreDiff preDiff = new FilePairPreDiff();
                    preDiff.initFileContent(prev, curr);
                    int result = preDiff.compareTwoFile();
                    JSONObject jo = preDiff.methodsToJson();
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }

    }

    public static void readGitChangeFiles(String gitPath,String projName,String commitId,String issueName){
        String basePath = "C:\\Users\\huangkaifeng\\Desktop\\RQ3\\buggymethods";
        File out = new File(basePath+"\\"+projName+"-"+commitId+".json");
        if(out.exists()){
            return;
        }
        JSONObject joAll = new JSONObject();
        JgitRepository jgit = new JgitRepository();
        jgit.buildRepository(gitPath, -1);
        joAll.put("project_name",projName);
        joAll.put("commit_id",commitId);
        joAll.put("gitPath",gitPath);
        joAll.put("issue_name",issueName);
        JSONArray result = parse(commitId,issueName,jgit);
        joAll.put("array",result);
        jgit.close();
        FileUtil.writeFlie(basePath+"\\"+projName+"-"+commitId+".json",joAll.toJSONString());
    }


    public static JSONArray parse(String commitId,String issueId,JgitRepository jgit){
        try {
//            System.out.println(commitId);
            JSONArray fileArray = new JSONArray();
            Map<String, Map<String, List<String>>> mMap = jgit.getCommitParentMappedFileList(commitId);
            for (Entry<String, Map<String, List<String>>> entry : mMap.entrySet()) {
                String parentId = entry.getKey();
                Map<String, List<String>> changedFiles = entry.getValue();
                List<String> addedFiles = changedFiles.get("addedFiles");
                List<String> removedFiles = changedFiles.get("deletedFiles");
                List<String> modifiedFiles = changedFiles.get("modifiedFiles");

                for (String addFile : addedFiles) {
                    if (!addFile.endsWith(".java")) {
                        continue;
                    }
                    InputStream prevIS = jgit.extract(addFile, commitId);
                    JSONObject addedObj = methodNameList(prevIS, "added_methods");
                    addedObj.put("file_name", addFile);
                    addedObj.put("type", "deleted");
                    fileArray.add(addedObj);
                }
                for (String file : removedFiles) {
                    if (!file.endsWith(".java")) {
                        continue;
                    }
                    InputStream currIS = jgit.extract(file, parentId);
                    JSONObject rmObj = methodNameList(currIS, "deleted_methods");
                    rmObj.put("file_name", file);
                    rmObj.put("type", "deleted");
                    fileArray.add(rmObj);
                }
                for (String file : modifiedFiles) {
                    if (!file.endsWith(".java")) {
                        continue;
                    }
                    InputStream prevIS = jgit.extract(file, parentId);
                    byte[] prev = FileUtil.toByteArray(prevIS);
                    InputStream currIS = jgit.extract(file, commitId);
                    byte[] curr = FileUtil.toByteArray(currIS);
                    FilePairPreDiff preDiff = new FilePairPreDiff();
                    preDiff.initFileContent(prev, curr);
                    int result = preDiff.compareTwoFile();
                    JSONObject joo = preDiff.methodsToJson();
                    joo.put("file_name", file);
                    joo.put("type", "change");
                    fileArray.add(joo);
                }
            }
            return fileArray;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }


    public static JSONObject methodNameList(InputStream is,String key){
        try {
            JSONObject result = new JSONObject();
            JSONArray arr = new JSONArray();
            CompilationUnit currUnit = JDTParserFactory.getCompilationUnit(is);
            if(currUnit.types().size()== 0 ||
                    !(currUnit.types().get(0) instanceof TypeDeclaration)){
                result.put(key,arr);
                return result;
            }
            TypeDeclaration type = (TypeDeclaration) currUnit.types().get(0);
            List<BodyDeclaration> bodyList = type.bodyDeclarations();
            for (BodyDeclaration bd : bodyList) {
                JSONObject joo = FilePairPreDiff.bodyDeclarationToString(new BodyDeclarationPair(bd,type.getName().toString()+"."));
                arr.add(joo);
            }
            result.put(key,arr);
            return result;
        }catch(Exception e){
            e.printStackTrace();

        }
        return null;
    }



}
