package cn.edu.fudan.se.statistics;

import java.io.File;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;

import cn.edu.fudan.se.util.JsonFileUtil;

public class ErrorStatistics {
	
	public static void projectCallError() {
		String dir = "D:/data/call";
		int total = 0,error = 0;
		String[] files = new File(dir).list();
		for(String file : files) {
			try {
//				System.out.println(file);
				String content = JsonFileUtil.readJsonFile(dir+"/"+file);
				JSONArray li = JSONArray.parseArray(content);
				String countStr = li.getString(li.size()-1);
				String[] splitedStr = countStr.split(" ");
				int errorTemp = Integer.parseInt(splitedStr[0]);
				int totalTemp = Integer.parseInt(splitedStr[1]);
				total += totalTemp;
				error += errorTemp;
				if(totalTemp == errorTemp && errorTemp != 0) {
					System.out.println(file+":"+errorTemp+" " +totalTemp);
				}
			}catch(JSONException e){
				System.out.println("JSONException:" + file);
			}			
		}
		System.out.println(error);
		System.out.println(total);
	}
	
	public static void main(String[] args) {
		projectCallError();
	}

}
