package cn.edu.fudan.se.cfg.rq1;

import cn.edu.fudan.se.cfg.rq1.bean.DependencyLib;
import cn.edu.fudan.se.cfg.rq1.bean.ErrorExceptionLib;
import cn.edu.fudan.se.cfg.rq1.bean.SortResult;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LibSort {
    static List<String> errorList;
    static final String ERROR_JAR_FILE_NAME = "F:/lib_field.json";
    static final String DEPENDENCY_DIR = "G:/dependency/";
    static Map<DependencyLib, Integer> dependencyMap;
    static Map<String, SortResult> sortResultMap;

    public static void main(String[] args) {

        errorList = initErrorList();

        initDependencyLib();

        List<DependencyLib> dependencyLibList = new ArrayList<>();

        for (DependencyLib key : dependencyMap.keySet()) {
            int count = dependencyMap.get(key);
            key.setCount(count);
            dependencyLibList.add(key);
        }

        Collections.sort(dependencyLibList, (o1, o2) -> {
            int count1 = o1.getCount();
            int count2 = o2.getCount();
            if (count1 > count2) return -1;
            if (count1 < count2) return 1;
            else return 0;
        });

        List<DependencyLib> errorJarsWithRank = new ArrayList<>();
        System.out.println("totalJars: " + String.valueOf(dependencyLibList.size()));
        FileUtil.writeFlie("F:/LibSort_temp_list.json", new GsonBuilder().setPrettyPrinting().create().toJson(dependencyLibList));
        DependencyLib dependencyLib;
        for (String errorJar : errorList) {
            dependencyLib = new DependencyLib();
            dependencyLib.setJar_url(errorJar);
            int index = dependencyLibList.indexOf(dependencyLib);
            if (index == -1) {
                System.out.println(errorJar);
                continue;
            }

            DependencyLib rankJar = dependencyLibList.get(index);
            rankJar.setRank(index);
            errorJarsWithRank.add(rankJar);
        }

        Collections.sort(errorJarsWithRank, (o1, o2) -> {
            int rank1 = o1.getRank();
            int rank2 = o2.getRank();
            if (rank1 < rank2) return -1;
            if (rank1 > rank2) return 1;
            else return 0;
        });

        FileUtil.writeFlie("F:/LibSort_Rank.json", new GsonBuilder().setPrettyPrinting().create().toJson(errorJarsWithRank));

        sortResultMap = new HashMap<>();
        System.out.println("find lib size: " + String.valueOf(errorJarsWithRank.size()));
        for (DependencyLib lib : errorJarsWithRank) {
            int rank = lib.getRank();
            int start = rank / 1000 * 1000;
            int end = start + 999;
            String key = String.valueOf(start) + "-" + String.valueOf(end);

            if (!sortResultMap.containsKey(key)) {
                sortResultMap.put(key, new SortResult(start, end));
            }
            SortResult sortResult = sortResultMap.get(key);
            sortResult.getDependencyLibs().add(lib);
            sortResult.setSize(sortResult.getDependencyLibs().size());
        }
        FileUtil.writeFlie("F:/LibSort_Rank_2.json", new GsonBuilder().setPrettyPrinting().create().toJson(sortResultMap));


    }

    private static void initDependencyLib() {
        dependencyMap = new HashMap<>();
        File file = new File(DEPENDENCY_DIR);
        File[] projects = file.listFiles();
        for (File project : projects) {
            String content = FileUtil.read(project.getAbsolutePath());
            List<DependencyLib> dependencyLibs = new Gson().fromJson(content, new TypeToken<List<DependencyLib>>() {
            }.getType());
            for (DependencyLib dependencyLib : dependencyLibs) {
                if (!dependencyMap.containsKey(dependencyLib)) {
                    dependencyMap.put(dependencyLib, 1);
                } else {
                    dependencyMap.put(dependencyLib, dependencyMap.get(dependencyLib) + 1);
                }
            }
        }
        FileUtil.writeFlie("F:/LibSort_temp_map.json", new GsonBuilder().setPrettyPrinting().create().toJson(dependencyMap));
    }

    private static List<String> initErrorList() {
        String content = FileUtil.read(ERROR_JAR_FILE_NAME);
        ErrorExceptionLib exceptionLib = new Gson().fromJson(content, new TypeToken<ErrorExceptionLib>() {
        }.getType());
        List<String> errorList = new ArrayList<>();
        errorList.addAll(exceptionLib.getError());
        errorList.addAll(exceptionLib.getException());

        int index = 0;
        for (String jar : errorList) {
            Pattern p = Pattern.compile("[a-zA-Z](\\S+)");
            Matcher m = p.matcher(jar);
            m.find();
            String newJar = m.group();
            errorList.set(index, newJar);
            index++;
        }

        return errorList;
    }
}
