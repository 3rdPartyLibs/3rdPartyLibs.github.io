package cn.edu.fudan.se.git;

import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.List;

public class Count {
    public static void main(String[] args) {
        String basePath = "C:\\cs\\issues\\";
        String issueCommitPath = "C:\\cs\\issues\\output\\";
        String issueBasePath = "\\projs\\projs\\";
        String[] issueFiles = {"CLI", "CODEC", "COLLECTIONS", "COMMON-IO", "LANG", "LOGGING", "HTTPCLIENT", "LOGBACK", "LOG4J2", "SLF4J"};
        String outputPath = "C:\\cs\\issues\\output\\filter\\";
        for (int index = 0; index < issueFiles.length; index++) {
            List<String> issueList = IssueUtil.getUniqueIssueId(basePath + issueBasePath + issueFiles[index] + ".txt");
            List<String> issueCommitIdList = IssueUtil.getUniqueIssueCommitId(issueCommitPath + issueFiles[index] + ".txt");
            List<String> resultList = new ArrayList<>();
            for (String issue : issueList) {
                if (issueCommitIdList.contains(issue)) {
                    resultList.add(issue);
                }
            }
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            System.out.println(issueFiles[index]+" : "+ String.valueOf(resultList.size())+"/"+String.valueOf(issueList.size()));
            FileUtil.writeFlie(outputPath + issueFiles[index] + ".txt", gson.toJson(resultList));
        }
    }

}
