package cn.edu.fudan.se.cfg.gradle.parse;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class TEST {
    public static void main(String[] args) {
        Map<String, Set<String>> map = new HashMap<>();
        Set<String> a = new HashSet<>();
        Set<String> b = new HashSet<>();

        a.add("abc");
        a.add("bcd");
        a.add("cde");
        a.add("def");

        b.add("abc");
        b.add("fgh");
        map.put("test", b);

        Set<String> c = map.get("test");

        for (String s : a) {
            System.out.println(s);
            System.out.println(c.remove(s));
        }

        Set<String> d = map.get("test");
        for (String s : d) {
            System.out.println(s);
        }

    }
}
