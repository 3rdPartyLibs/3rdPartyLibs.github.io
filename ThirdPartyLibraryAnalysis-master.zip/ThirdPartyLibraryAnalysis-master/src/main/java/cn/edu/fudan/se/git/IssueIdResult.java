package cn.edu.fudan.se.git;

import java.util.Set;

public class IssueIdResult {
    boolean success;
    Set<String> issueIds;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public Set<String> getIssueIds() {
        return issueIds;
    }

    public void setIssueIds(Set<String> issueIds) {
        this.issueIds = issueIds;
    }

    public IssueIdResult() {

    }

    public IssueIdResult(boolean success, Set<String> issueIds) {

        this.success = success;
        this.issueIds = issueIds;
    }
}
