package cn.edu.fudan.se.cfg;

import org.eclipse.jdt.core.dom.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 节点方法
 */

public class Method {

    private String className;//a.b.c package+classname
    //void check(java.lang.Class,java.lang.String)
    private String methodName;//方法名

    private String returnType;//返回值，特殊值是void
    private String methodName2;//纯方法名 void aaa(int a ) 的纯方法名为aaa
    private List<String> parameters;//参数列表 原生参数列表item为包名+类名（java.lang.String），由bodyDeclaration转换而来的item为类名（String）
    private int bodyHashCode;//方法体hash值
    private boolean isInitMethod;//是否是构造方法

    /**
     * 将MethodDeclaration 转化为 Method
     *
     * @param bodyDeclaration
     */
    public Method(MethodDeclaration bodyDeclaration) {

        Type returnTypeName = bodyDeclaration.getReturnType2();
        if (returnTypeName == null) {
            returnType = "void";
        } else {
            returnType = returnTypeName.toString();

            if (returnType.contains("<")) {
                returnType = returnType.substring(0, returnType.indexOf("<"));
            }

        }
        /*else if (returnTypeName instanceof SimpleType) {
            returnType = returnTypeName == null ? "void" : ((SimpleType) returnTypeName).getName().getFullyQualifiedName();
        } else if (returnTypeName instanceof PrimitiveType) {
            returnType = returnTypeName == null ? "void" : ((PrimitiveType) returnTypeName).getPrimitiveTypeCode().toString();
        } else if (returnTypeName instanceof ParameterizedType) {
            returnType = returnTypeName.toString();
        } else {
            //ArrayType String[]
            returnType = ((SimpleType) ((ArrayType) returnTypeName).getElementType()).getName().getFullyQualifiedName();
            List<Dimension> dimensions = ((ArrayType) returnTypeName).dimensions();
            for (Dimension dimension : dimensions) {
                returnType += dimension;
            }
        }*/
        //returnType = returnTypeName == null ? "void" : returnTypeName.getName().getFullyQualifiedName();
        TypeDeclaration parent = (TypeDeclaration) bodyDeclaration.getParent();
        String tempClassName = parent.getName().getIdentifier();//类名
        CompilationUnit packageParent = (CompilationUnit) parent.getParent();//package级别的parent，用于获取包名
        QualifiedName qualifiedName = (QualifiedName) (packageParent.getPackage()).getName();
        String packageName = qualifiedName.getQualifier() + "." + qualifiedName.getName().getIdentifier();
        className = packageName + "." + tempClassName;

        parameters = new ArrayList<>();
        List parametersNodeList = bodyDeclaration.parameters();
        for (Object param : parametersNodeList) {
            String paramType = param.toString().split(" ")[0];
            parameters.add(paramType);
            /*String tempParam = "";
            if (paramType instanceof SimpleType) {
                tempParam = ((SimpleType) paramType).getName().getFullyQualifiedName();
            } else if (paramType instanceof PrimitiveType) {
                //PrimitiveType
                tempParam = ((PrimitiveType) paramType).getPrimitiveTypeCode().toString();
            } else if (paramType instanceof ParameterizedType) {
                //ParameterizedType
                paramType = ((ParameterizedType) paramType).getType();

                if (paramType instanceof SimpleType) {
                    tempParam = ((SimpleType) paramType).getName().getFullyQualifiedName();
                } else if (paramType instanceof PrimitiveType) {
                    //PrimitiveType
                    tempParam = ((PrimitiveType) paramType).getPrimitiveTypeCode().toString();
                }
            } else {
                //ArrayType
                //ArrayType String[]
                tempParam = ((SimpleType) ((ArrayType) paramType).getElementType()).getName().getFullyQualifiedName();
                List<Dimension> dimensions = ((ArrayType) paramType).dimensions();
                for (Dimension dimension : dimensions) {
                    tempParam += dimension;
                }
            }*/
        }

        methodName2 = bodyDeclaration.getName().getIdentifier();
        //methodName = returnType + " " + methodName2 + "(";

        bodyHashCode = bodyDeclaration.getBody().toString().hashCode();
    }

    /**
     * 比较原生的Method与由MethodDeclaration转化而来的Method是否相同
     *
     * @param m
     */

    public boolean isSameWithMethodDeclaration(Method m) {
        //比较className
        if (!className.equals(m.className)) {
            return false;
        }

        //比较返回值
        if (!returnType.endsWith(m.returnType)) {
            return false;
        }

        //比较纯方法名
        if (!methodName2.equals(m.methodName2)) {
            return false;
        }

        //比较参数列表
        int size1 = parameters.size();
        int size2 = m.getParameters().size();
        if (size1 != size2) {
            return false;
        }

        for (int index = 0; index < size1; index++) {
            String param1 = parameters.get(index);
            String param2 = m.getParameters().get(index);
            //class<?>
            if (param2.endsWith("<?>")) {
                param2 = param2.substring(0, param2.indexOf("<"));
            }
            if (param2.endsWith("...")) {
                param2 = param2.substring(0, param2.indexOf("...")) + "[]";
            }
            if (param1.equals("java.lang.Object") || param2.equals("java.lang.Object") || param1.equals("Object") || param2.equals("Object")) {
                return true;
            }
            //正常情况下 param1为xxx.xx.xxx包含包名的类名
            //param2为xxx纯包名
            //只要判断param1是否以param2结尾
            if (!param1.endsWith(param2)) {
                return false;
            }
        }
        return true;

    }


    public boolean isInitMethod() {
        return isInitMethod;
    }

    public void setInitMethod(boolean initMethod) {
        isInitMethod = initMethod;
    }

    private void initMethod(String methodName) {
        returnType = methodName.split(" ")[0];//void
        methodName2 = methodName.split(" ")[1].split("\\(")[0];//check

        // String paraMetersContent = methodName.split(" ")[1].split("\\(")[1].split("\\)")[0];
        String paraMetersContent = methodName.split(" ")[1];
        paraMetersContent = paraMetersContent.split("\\)")[0];
        String[] tempParamArray = paraMetersContent.split("\\(");
        paraMetersContent = tempParamArray.length == 1 ? "" : paraMetersContent.split("\\(")[1];

        //paraMetersContent为java.lang.Class,java.lang.String 或 空字符串
        //如果为空不做处理，否则参数分割出来存入parameters
        if ("".equals(paraMetersContent)||paraMetersContent==null) {
            parameters = new ArrayList<>();            
        } else {
            String[] tempParams = paraMetersContent.split(",");
            parameters = Arrays.asList(tempParams);
        }

    }


    public int getBodyHashCode() {
        return bodyHashCode;
    }

    public void setBodyHashCode(int bodyHashCode) {
        this.bodyHashCode = bodyHashCode;
    }

    public String getReturnType() {
        return returnType;
    }

    public void setReturnType(String returnType) {
        this.returnType = returnType;
    }

    public String getMethodName2() {
        return methodName2;
    }

    public void setMethodName2(String methodName2) {
        this.methodName2 = methodName2;
    }

    public List<String> getParameters() {
        return parameters;
    }

    public void setParameters(List<String> parameters) {
        this.parameters = parameters;
    }

    /**
     * 如果是构造函数，调用静态方法，在方法内部调用private的构造函数
     *
     * @param className
     * @param methodName
     * @return
     */
    public static Method initMethod(String className, String methodName) {
        return new Method(className, methodName, true);
    }


    //构造方法
    private Method(String className, String methodName, boolean isInitMethod) {

        this.className = className;
        this.methodName = methodName;
        this.isInitMethod = true;


//        private String returnType;//返回值，特殊值是void
//        private String methodName2;//纯方法名 void aaa(int a ) 的纯方法名为aaa
//        private List<String> parameters;//参数列表 原生参数列表item为包名+类名（java.lang.String），由bodyDeclaration转换而来的item为类名（String）
//        private int bodyHashCode;//方法体hash值
        //className:org.openjdk.jmh.util.Optional
        //methodName:void <init>(java.lang.Object)
        this.returnType = "void";
        String[] classNames = className.split("\\.");
        int size = classNames.length;
        this.methodName2 = classNames[size - 1];
        //paraMetersContent为java.lang.Class,java.lang.String 或 空字符串
        //如果为空不做处理，否则参数分割出来存入parameters
        String paraMetersContent = methodName.split(" ")[1];
        paraMetersContent = paraMetersContent.split("\\)")[0];
        String[] tempParamArray = paraMetersContent.split("\\(");
        paraMetersContent = tempParamArray.length == 1 ? "" : paraMetersContent.split("\\(")[1];
        if ("".equals(paraMetersContent)||paraMetersContent==null) {
            parameters = new ArrayList<>();            
        } else {
            String[] tempParams = paraMetersContent.split(",");
            parameters = Arrays.asList(tempParams);
        }

    }

    public Method(String className, String methodName) {
        this.className = className;
        this.methodName = methodName;
        initMethod(methodName);
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof Method && ((Method) obj).getClassName().equals(className) && ((Method) obj).getMethodName().equals(methodName);
    }
}
