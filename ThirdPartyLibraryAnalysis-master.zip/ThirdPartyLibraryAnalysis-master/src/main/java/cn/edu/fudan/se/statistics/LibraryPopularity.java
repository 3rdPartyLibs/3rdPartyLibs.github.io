package cn.edu.fudan.se.statistics;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import cn.edu.fudan.se.db.DB;
import cn.edu.fudan.se.util.JsonFileUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class LibraryPopularity {
	public static void main(String[] args) {
		// getLibrary();
//		statistics();
		readProjectFile();
//		int count = 0;
//		for(int i=700;i<1266;i++){
//			Map<String,String> libs1 = readProjectFile("E:\\ThirdPartyLibraryAnalysis\\curr_result7.20_",i);
//			Map<String,String> libs2 = readProjectFile("E:\\ThirdPartyLibraryAnalysis\\curr_result7.25",i);
//			int prev = libs1.size();
//			int curr = libs2.size();
//			if(prev > curr) {
//				System.out.println(i+": "+prev+" "+curr);
//				count ++;
//			}
//		}
//		System.out.println(count);
//		
		// 602
//		int count = 0;
////		List<String> libs1 = readProjectFile("C:\\Users\\yw\\Desktop\\result",35);
//		Map<String,String> libs1 = readProjectFile("E:\\ThirdPartyLibraryAnalysis\\curr_result7.20",602);
//		Map<String,String> libs2 = readProjectFile("E:\\ThirdPartyLibraryAnalysis\\curr_result7.25",602);
//		System.out.println(libs1.size());
//		System.out.println(libs2.size());
//		for (Map.Entry<String, String> entry : libs1.entrySet()) {
//			String lib = entry.getKey();
//			if(!libs2.containsKey(lib)) {
//				System.out.println(lib+"   "+entry.getValue());
//				count++;
//			}
//		}
//		System.out.println(count);
	}
	
	public static Map<String,String> readProjectFile(String path,int id) {
		Map<String,String> libs = new HashMap<String,String>();
		path = path + File.separator + id + ".txt";
		File file = new File(path);
		if (!file.exists()) {
			return libs;
		}
		String whole = JsonFileUtil.readJsonFile(path); 
		JSONArray array = JSONArray.fromObject(whole);	
		
		for (int a = 0; a < array.size(); a++) {
			JSONObject obj = array.getJSONObject(a);
			String group = obj.optString("groupId");
			String name = obj.optString("artifactId");
			String version = obj.optString("version");
			String module = obj.optString("module");
			
			group = group.trim();
			name = name.trim();
			version = version.trim();
			
			String lib = group +" "+name;
			
			if (version == null || version.equals("")) {
			}
			else {
				lib += " "+version;
			}
			
			String type = obj.optString("type");
			if(type != null && type.equals("")) 
				lib +=" "+type;
			if(!libs.containsValue(lib)) 
				libs.put(lib, module);
		}
		
		return libs;
	}
	
	public static void readProjectFile() {
		String path = null;
		List<String> libs = new ArrayList<String>();
		int projectCount = 0;
		// 1602 1619 1707 1758 1840 1878 1993
		for (int i = 941; i <= 941; i++) {
//			System.out.println("++++++++++++++++++++++++++" + i + ".txt");
//			path = "C:\\Users\\yw\\Desktop\\result" + File.separator + i + ".txt";
//			path = "E:\\data\\curr_result7.25" + File.separator + i + ".txt";
			path = "E:\\data\\curr_result_add" + File.separator + i + ".txt";
			File file = new File(path);
			if (!file.exists()) {
//				System.out.println("path : " + path + " not exists");
//				System.out.println();
				continue;
			}
			String whole = JsonFileUtil.readJsonFile(path);
			JSONArray array = JSONArray.fromObject(whole);			
			
			System.out.println("size:"+array.size());
//			if(array.size()<=1) {
//				projectCount ++;
//				System.out.println("mark ");
//			}
			for (int a = 0; a < array.size(); a++) {
				JSONObject obj = array.getJSONObject(a);
				if (obj.has("id")) {
//					if(obj.getString("local_addr").contains("springside4-4.2.2.GA"))
//						System.out.println("+++contains:"+i);
					System.out.println(obj.getInt("id")+" "+obj.getString("url"));
					continue;
				}
				String group = obj.optString("groupId");
				String name = obj.optString("artifactId");
				String version = obj.optString("version");
				String type = obj.optString("type");
				String classifier = obj.optString("classifier");
				System.out.println("group : " + group);
				System.out.println("name : " + name);
				System.out.println("version : " + version);
				System.out.println("module : " + obj.optString("module"));			
				System.out.println("classifier : " + obj.optString("classifier"));	
				System.out.println("type : " + type);
				if(type.equals("nbm-file")) {
					System.out.println("==========================" + i + ".txt");
					return;
				}
				
				if (version == null || version.equals("")) {
					System.out.println("++++++++++++++++++++++++++" + i + ".txt");
					System.out.println("version is null");
//					String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
//							+ i + "," + a + ",\'" + group + "\',\'" + name
//							+ "\',\'O\',\'version == null || version=\')";
//					DB.update(sql);
					continue;
				}
				if (group == null || group.equals("")) {
					System.out.println("++++++++++++++++++++++++++" + i + ".txt");
					System.out.println("group is null");
//					String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
//							+ i + "," + a + ",\'o\',\'" + name + "\',\'" + version + "\',\'group == null || group=\')";
//					DB.update(sql);
					continue;
				}
				if (name == null || name.equals("")) {
					System.out.println("++++++++++++++++++++++++++" + i + ".txt");
					System.out.println("name is null");
//					String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
//							+ i + "," + a + ",\'" + group + "\',\'o\',\'" + version + "\',\'name == null || name=\')";
//					DB.update(sql);
					continue;
				}
				if (type == null || type.equals("")) {
					System.out.println("++++++++++++++++++++++++++" + i + ".txt");
					System.out.println("type is null");
//					String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
//							+ i + "," + a + ",\'" + group + "\',\'o\',\'" + version + "\',\'name == null || name=\')";
//					DB.update(sql);
					continue;
				}
				if (group.contains("${") || name.contains("${") || version.contains("${")|| type.contains("${")) {
					System.out.println("++++++++++++++++++++++++++" + i + ".txt");
					System.out.println("contains(${)");
//					String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
//							+ i + "," + a + ",\'" + group + "\',\'"+name+"\',\'" + version + "\',\'contains(${)\')";
//					DB.update(sql);
					continue;
				}
				if(classifier != null && classifier.contains("${")) {
					System.out.println("++++++++++++++++++++++++++" + i + ".txt");
					System.out.println("classifier contains(${)");
					continue;
				}
				group = group.trim();
				name = name.trim();
				version = version.trim();
				
				String lib = group +" "+name+" "+version;
				if(type != null && type.equals("")) 
					lib +=" "+type;
				if(!libs.contains(lib)) 
					libs.add(lib);
//				try {
//					ResultSet rs = DB.query("SELECT id FROM `library_usage` where `group_str`=\'" + group
//							+ "\' and `name_str`=\'" + name + "\' and `version`=\'" + version + "\'");
//					rs.last();
//					if (rs.getRow() > 0) {
//						rs.beforeFirst();
//						while (rs.next()) {
//							int id = rs.getInt("id");
//							String sql = "UPDATE `library_usage`  SET `project_count`=project_count+1  WHERE `id`="
//									+ id;
//							DB.update(sql);
//						}
//					} else {
//						// System.out.println("SELECT * FROM library_versions
//						// where group_str=\'" + group
//						// + "\' and name_str=\'" + name + "\' and version=\'" +
//						// version + "\'");
//						rs = DB.query("SELECT * FROM `library_versions` where `group_str`=\'" + group
//								+ "\' and `name_str`=\'" + name + "\' and `version`=\'" + version + "\'");
//						rs.last();
//						int row = rs.getRow();
//						if (row > 1) {
//							System.out.println("select from library_versions : > 1");
//							String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
//									+ i + "," + a + ",\'" + group + "\',\'" + name + "\',\'" + version
//									+ "\',\'select from library_versions : > 1\')";
//							DB.update(sql);
//							continue;
//						}
//						if (row <= 0) {
//							System.out.println("select from library_versions : <= 0");
//							String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
//									+ i + "," + a + ",\'" + group + "\',\'" + name + "\',\'" + version
//									+ "\',\'select from library_versions : <= 0\')";
//							DB.update(sql);
//							continue;
//						}
//						rs.beforeFirst();
//						while (rs.next()) {
//							int id = rs.getInt("id");
//							int category_id = rs.getInt("category_id");
//							String sql = "INSERT INTO library_usage(version_id,category_id,group_str,name_str,version,project_count) VALUES ("
//									+ id + "," + category_id + ",\'" + group + "\',\'" + name + "\',\'" + version
//									+ "\',1)";
//							DB.update(sql);
//						}
//					}
//
//				} catch (SQLException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
			}
		}
		System.out.println(libs.size());
//		System.out.println("projectCount  "+projectCount);
	}	
	
	public static void statistics() {
		String path = null;
		for (int i = 10001; i <= 20000; i++) {
			System.out.println("++++++++++++++++++++++++++" + i + ".txt");
			path = "F:/GP/result/result1-30000" + File.separator + i + ".txt";
			File file = new File(path);
			if (!file.exists()) {
				System.out.println("path : " + path + " not exists");
				System.out.println();
				continue;
			}

			String whole = "";
			try {
				Scanner in = new Scanner(new File(path));
				while (in.hasNextLine()) {
					String str = in.nextLine();
					whole += str;
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			JSONArray array = JSONArray.fromObject(whole);
			for (int a = 0; a < array.size(); a++) {
				JSONObject obj = array.getJSONObject(a);
				if (obj.has("git_addr"))
					continue;
				String group = obj.optString("groupId");
				String name = obj.optString("artifactId");
				String version = obj.optString("version");
				System.out.println("group : " + group);
				System.out.println("name : " + name);
				System.out.println("version : " + version);
				System.out.println("module : " + obj.optString("module"));
				if (version == null || version.equals("")) {
					System.out.println("version is null");
					String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
							+ i + "," + a + ",\'" + group + "\',\'" + name
							+ "\',\'O\',\'version == null || version=\')";
					DB.update(sql);
					continue;
				}
				if (group == null || group.equals("")) {
					System.out.println("group is null");
					String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
							+ i + "," + a + ",\'o\',\'" + name + "\',\'" + version + "\',\'group == null || group=\')";
					DB.update(sql);
					continue;
				}
				if (name == null || name.equals("")) {
					System.out.println("name is null");
					String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
							+ i + "," + a + ",\'" + group + "\',\'o\',\'" + version + "\',\'name == null || name=\')";
					DB.update(sql);
					continue;
				}
				if (group.contains("${") || name.contains("${") || version.contains("${")) {
					System.out.println("name is null");
					String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
							+ i + "," + a + ",\'" + group + "\',\'"+name+"\',\'" + version + "\',\'contains(${)\')";
					DB.update(sql);
					continue;
				}
				group = group.trim();
				name = name.trim();
				version = version.trim();

				try {
					ResultSet rs = DB.query("SELECT id FROM `library_usage` where `group_str`=\'" + group
							+ "\' and `name_str`=\'" + name + "\' and `version`=\'" + version + "\'");
					rs.last();
					if (rs.getRow() > 0) {
						rs.beforeFirst();
						while (rs.next()) {
							int id = rs.getInt("id");
							String sql = "UPDATE `library_usage`  SET `project_count`=project_count+1  WHERE `id`="
									+ id;
							DB.update(sql);
						}
					} else {
//						rs = DB.query("SELECT * FROM `library_versions` where `group_str`=\'" + group
//								+ "\' and `name_str`=\'" + name + "\' and `version`=\'" + version + "\'");
//						rs.last();
//						int row = rs.getRow();
//						if (row > 1) {
//							System.out.println("select from library_versions : > 1");
//							String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
//									+ i + "," + a + ",\'" + group + "\',\'" + name + "\',\'" + version
//									+ "\',\'select from library_versions : > 1\')";
//							DB.update(sql);
//							continue;
//						}
//						if (row <= 0) {
//							System.out.println("select from library_versions : <= 0");
//							String sql = "INSERT INTO project_information(txt_id,array_id,group_str,name_str,version,reason) VALUES ("
//									+ i + "," + a + ",\'" + group + "\',\'" + name + "\',\'" + version
//									+ "\',\'select from library_versions : <= 0\')";
//							DB.update(sql);
//							continue;
//						}
//						rs.beforeFirst();
//						while (rs.next()) {
//							int id = rs.getInt("id");
//							int category_id = rs.getInt("category_id");
//							String sql = "INSERT INTO library_usage(version_id,category_id,group_str,name_str,version,project_count) VALUES ("
//									+ id + "," + category_id + ",\'" + group + "\',\'" + name + "\',\'" + version
//									+ "\',1)";
//							DB.update(sql);
							String sql = "INSERT INTO library_usage(group_str,name_str,version,project_count) VALUES (\'" + group + "\',\'" + name + "\',\'" + version+ "\',1)";
							DB.update(sql);
//						}
					}

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}	

	public static void getLibrary() {
		String path = null;
		for (int i = 5555; i <= 20000; i++) {
			System.out.println("++++++++++++++++++++++++++" + i + ".txt");
			path = "F:/GP/result/result1-30000" + File.separator + i + ".txt";
			File file = new File(path);
			if (!file.exists()) {
				System.out.println("path : " + path + " not exists");
				System.out.println();
				continue;
			}
//			String whole = "";
//			try {
//				Scanner in = new Scanner(new File(path));
//				while (in.hasNextLine()) {
//					String str = in.nextLine();
//					whole += str;
//				}
//			} catch (FileNotFoundException e) {
//				e.printStackTrace();
//			}
			String whole = JsonFileUtil.readJsonFile(path);
			JSONArray array = JSONArray.fromObject(whole);
			for (int a = 0; a < array.size(); a++) {
				JSONObject obj = array.getJSONObject(a);
				if (obj.has("release_id"))
					continue;
				String group = obj.optString("groupId");
				String name = obj.optString("artifactId");
				System.out.println("group : " + group);
				System.out.println("name : " + name);
				if (group == null) {
					System.out.println("group is null");
					return;
				}
				if (name == null) {
					System.out.println("name is null");
					return;
				}
				group = group.trim();
				name = name.trim();
				if ((!group.contains("${")) && (!name.contains("${"))) {
					System.out.println("-----------------success : group : " + group + "  name : " + name);
					String url = "http://mvnrepository.com/artifact/" + group + "/" + name;
					try {
						ResultSet rs = DB.query("SELECT * FROM `library_url` where `url`=\'" + url + "\'");
						rs.last();
						if (rs.getRow() <= 0) {
							String sql = "INSERT INTO library_url(url) VALUES (\'" + url + "\')";
							DB.update(sql);
						}

					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			System.out.println();
		}
	}
}
