package cn.edu.fudan.se.cfg.rq3;

import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CopyUsedJar {
    static final String JAR_FILE_DIR = "D:/wangying/rq3/api_call_rq3_proj_filtered/";//源文件dir
    static final String LIB_DIR = "H:/wangying/lib_all/";//jar包dir
    //static final String LIB_UNZIP_DIR = "D:/wangying/rq3/lib_unzip/";//jar包解压dir
    static final String OUTPUT_DIR = "D:/wangying/rq3/rq3_lib_all/";//输出结果dir

    public static void main(String[] args) throws IOException {
        if (!new File(OUTPUT_DIR).exists()) {
            new File(OUTPUT_DIR).mkdirs();
        }
        File[] fileList = new File(JAR_FILE_DIR).listFiles();

        for (File jarMetaFile : fileList) {
            String content = FileUtil.read(jarMetaFile.getAbsolutePath());
            Gson gson = new Gson();
            Map<String, Map<String, Integer>> contentMap = new HashMap<>();
            contentMap = gson.fromJson(content, contentMap.getClass());
            //Map<String, Map<String, List<String>>> resultMap = new HashMap<>();
            //遍历project中的jar
            for (Map.Entry<String, Map<String, Integer>> jarEntry : contentMap.entrySet()) {
                String jarName = jarEntry.getKey();

                File jarFile = new File(OUTPUT_DIR + jarName);
                if (jarFile.exists()) {
                    continue;
                }

                copyFileUsingApacheCommonsIO(new File(LIB_DIR + jarName), new File(OUTPUT_DIR + jarName));


            }
        }
    }

    private static void copyFileUsingApacheCommonsIO(File source, File dest)
            throws IOException {
        FileUtils.copyFile(source, dest);
    }
}
