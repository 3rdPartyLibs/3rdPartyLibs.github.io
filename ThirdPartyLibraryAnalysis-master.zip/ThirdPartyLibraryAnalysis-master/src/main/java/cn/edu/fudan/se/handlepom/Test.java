package cn.edu.fudan.se.handlepom;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import org.codehaus.plexus.util.xml.pull.XmlPullParserException;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class Test {

	public static void main(String[] args) throws IOException, XmlPullParserException {
		// String pomPath = "E:/Workspace_eclipse/appserver12/pom.xml";
//		String pomPath = "C:/Users/yw/Downloads/pom.xml";
//		readPom("C:/Users/yw/Downloads",new JSONObject());
		// readData("F:/GP/result/1.txt");
//		for(int i =0;i<args.length;i++) {
//			System.out.println(args[i]);
//		}
//		 readProjectFile("project.txt");
		readProjectFile(args[0]);
	}

	public static void readPom(String projectPath, JSONObject project) {
//		String pomPath = projectPath + File.separator +"pom.xml";
		String pomPath = projectPath;
		int id = project.optInt("id");
		File file = new File(pomPath);
		if (!file.exists()) {
//			System.out.println("path : "+pomPath+" not exists");
			return;
		}
		else {
			System.out.println("id: "+id+"\npath : "+pomPath);
		}
//		JSONArray array = new JSONArray();
//		array.add(project);
//		int id = project.optInt("id");
//		MavenXpp3Reader reader = new MavenXpp3Reader();
//		// String pomPath = System.getProperty("user.dir") + File.separator +
//		// "pom.xml";
//
//		Model model = null;
//		try {
//			model = reader.read(new FileReader(pomPath));
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (XmlPullParserException e) {
//			// TODO Auto-generated catch block
//			System.out.println("error id : "+id);
//			e.printStackTrace();
//			return;
//		}
//
//		// String el = "\\$\\{[^\\}]+\\}";
//		// Pattern el = Pattern.compile("\\$\\{([^\\}]+)\\}");
//		Pattern el = Pattern.compile("\\$\\{(.*?)\\}");
//
//		if(model == null)
//			return;
//		Properties p = model.getProperties();
//		List<Dependency> dependencies = model.getDependencies();
//		for (int i = 0; i < dependencies.size(); i++) {
//			String groupId = dependencies.get(i).getGroupId();
//			String artifactId = dependencies.get(i).getArtifactId();
//			String version = dependencies.get(i).getVersion();
//
//			if (version != null) {
//				Matcher m = el.matcher(version);// el表达式
//				while (m.find()) {
//					if (p != null && p.getProperty(m.group(1)) != null)
//						version = version.replace(m.group(0), p.getProperty(m.group(1)));
//				}
//			}
//			JSONObject obj = new JSONObject();
//			obj.put("groupId", groupId);
//			obj.put("artifactId", artifactId);
//			obj.put("version", version);
//			obj.put("information", "dependency");
//			array.add(obj);
//			// System.out.println(groupId);
//			// System.out.println(artifactId);
//			// System.out.println(version);
//			//
//			// System.out.println();
//		}
//
//		if (model.getDependencyManagement() != null) {
//			dependencies = model.getDependencyManagement().getDependencies();
//			for (int i = 0; i < dependencies.size(); i++) {
//				String groupId = dependencies.get(i).getGroupId();
//				String artifactId = dependencies.get(i).getArtifactId();
//				String version = dependencies.get(i).getVersion();
//
//				if (version != null) {
//					Matcher m = el.matcher(version);// el表达式
//					while (m.find()) {
//						if (p != null && p.getProperty(m.group(1)) != null)
//							version = version.replace(m.group(0), p.getProperty(m.group(1)));
//					}
//				}
//				JSONObject obj = new JSONObject();
//				obj.put("groupId", groupId);
//				obj.put("artifactId", artifactId);
//				obj.put("version", version);
//				obj.put("information", "dependencyManagement");
//				array.add(obj);
//			}
//		}
//
//		if (model.getBuild() != null) {
//			List<Plugin> plugins = model.getBuild().getPlugins();
//			for (int i = 0; i < plugins.size(); i++) {
//				String groupId = plugins.get(i).getGroupId();
//				String artifactId = plugins.get(i).getArtifactId();
//				String version = plugins.get(i).getVersion();
//
//				if (version != null) {
//					Matcher m = el.matcher(version);// el表达式
//					while (m.find()) {
//						if (p != null && p.getProperty(m.group(1)) != null)
//							version = version.replace(m.group(0), p.getProperty(m.group(1)));
//					}
//				}
//
//				JSONObject obj = new JSONObject();
//				obj.put("groupId", groupId);
//				obj.put("artifactId", artifactId);
//				obj.put("version", version);
//				obj.put("information", "plugin");
//				array.add(obj);
//			}
//		}
//
//		if (model.getBuild() != null && model.getBuild().getPluginManagement() != null) {
//			List<Plugin> plugins = model.getBuild().getPluginManagement().getPlugins();
//			for (int i = 0; i < plugins.size(); i++) {
//				String groupId = plugins.get(i).getGroupId();
//				String artifactId = plugins.get(i).getArtifactId();
//				String version = plugins.get(i).getVersion();
//
//				if (version != null) {
//					Matcher m = el.matcher(version);// el表达式
//					while (m.find()) {
//						if (p != null && p.getProperty(m.group(1)) != null)
//							version = version.replace(m.group(0), p.getProperty(m.group(1)));
//					}
//				}
//
//				JSONObject obj = new JSONObject();
//				obj.put("groupId", groupId);
//				obj.put("artifactId", artifactId);
//				obj.put("version", version);
//				obj.put("information", "pluginManagement");
//				array.add(obj);
//			}
//		}		
//		save("result/"+id+".txt", array);
	}

	public static void save(String savePath, JSONArray array) {
		try {
			FileWriter f = new FileWriter(savePath);
			f.write(array.toString());// 写入
			f.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void readData(String dataPath) {
		String whole = "";
		try {
			Scanner in = new Scanner(new File(dataPath));
			while (in.hasNextLine()) {
				String str = in.nextLine();
				whole += str;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		JSONArray array = JSONArray.fromObject(whole);
		for (int i = 0; i < array.size(); i++) {
			JSONObject obj = array.getJSONObject(i);
			System.out.println(obj.optString("groupId"));
			System.out.println(obj.optString("artifactId"));
			System.out.println(obj.optString("version"));
			System.out.println();
		}
	}

	public static void readProjectFile(String file) {
		String whole = "";
		try {
			Scanner in = new Scanner(new File(file));
			while (in.hasNextLine()) {
				String str = in.nextLine();
				whole += str;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		JSONArray array = JSONArray.fromObject(whole);
		for (int i = 0; i < array.size(); i++) {
			JSONObject obj = array.getJSONObject(i);
			String localPath = obj.optString("local_addr");
			int id = obj.optInt("id");			
//			if(id == 30001) {
				localPath = localPath.replace("repositories","repository1");
				obj.put("local_addr", localPath);	
//				System.out.println("localPath : "+localPath);
//				System.out.println("id : "+id);
				readPom(localPath,obj);
//				System.out.println();
//			}		
		}
	}

}
