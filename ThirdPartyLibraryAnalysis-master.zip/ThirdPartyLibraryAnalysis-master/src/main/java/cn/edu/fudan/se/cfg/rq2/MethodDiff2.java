package cn.edu.fudan.se.cfg.rq2;

import cn.edu.fudan.se.cfg.*;
import cn.edu.fudan.se.cfg.rq2.bean.MethodList;
import cn.edu.fudan.se.cfg.rq2.utils.MetaMethodUtil;
import cn.edu.fudan.se.cfg.rq2.utils.SootUtils;
import cn.edu.fudan.se.util.FileUtil;
import cn.edu.fudan.se.util.JavaMethodUtil;
import com.google.gson.GsonBuilder;
import org.apache.commons.io.FileUtils;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import soot.*;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.options.Options;
import soot.util.dot.DotGraph;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class MethodDiff2 {

    static final String DECOMPILE_OUTPUT_PATH = "d:/cs/jar/decompile_output/";//反编译路径
    //static final String JAR_PATH = "H:\\wangying\\lib_all\\";//jar包所在的路径
    static final String JAR_PATH = "D:\\cs\\jar\\jar\\";//jar包所在的路径
    //static final String META_PATH = "D:\\cs\\jar\\final_output\\";//所有meta文件所在的目录路径
    static final String META_PATH = "D:\\cs\\jar\\test\\";//所有meta文件所在的目录路径
    static final String UNZIP_PATH = "D:\\cs\\jar\\unzip\\";//解压jar包的目录路径
    static final String RESULT_PATH = "D:\\cs\\jar\\result\\";//输出结果目录
//    static final String DECOMPILE_OUTPUT_PATH = "c:/cs/jar/decompile_output/";//反编译路径
//    static final String JAR_PATH = "C:\\cs\\jar\\jar2\\";//jar包所在的路径
//    static final String META_PATH = "C:\\cs\\jar\\meta2";//所有meta文件所在的目录路径
//    static final String UNZIP_PATH = "C:\\cs\\jar\\unzip\\";//解压jar包的目录路径
//    static final String RESULT_PATH = "C:\\cs\\jar\\result\\";//输出结果目录


    /**
     * 比对两个jar包的指定方法
     * <p>
     * 1. 解析meta中的方法列表
     * 2. 对于方法列表中的每个方法：
     * (1)调用soot得到该方法在两个jar包中调用的子方法列表
     * (2)对两个子方法列表进行比对，首先对方法列表按首字母排序，对每个子方法：
     * (a)比较方法列表的长度，如果不同，则说明肯定发生变化
     * (b)如果方法列表相同，则比较每个方法的【方法名】、【返回值】、【参数列表】、【方法体】，如果出现不同，则肯定发生变化
     *
     * @param args
     * @throws NoSuchFieldException
     * @throws IllegalAccessException
     */


    public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException, IOException {

        File file = new File(META_PATH);
        File[] metaList = file.listFiles();

        for (File metaFile : metaList) {
            //对于每一个meta文件

            //如果在输出结果目录存在该文件，说明已经解析过，跳过
            System.out.println("===========");
            System.out.println(metaFile.getName());
            File resultFile1 = new File(RESULT_PATH + "true1" + metaFile.getName());
            File resultFile2 = new File(RESULT_PATH + "false-1" + metaFile.getName());
            if (resultFile1.exists() || resultFile2.exists()) {
                continue;
            }
            //读取meta文件，得到prev和curr两个方法列表
            MethodList methodList = MetaMethodUtil.readMethodFromMeta(metaFile.getAbsolutePath());
            List<String> prevMethodStringList = methodList.getPrevList();
            List<String> currMethodStringList = methodList.getCurrList();
            String prevJar = methodList.getPrevJar();
            String currJar = methodList.getCurrJar();

            //生成需要检查的方法列表
            NeedMethods needMethods = initFinalList(prevMethodStringList, currMethodStringList);
            String preJarPath = JAR_PATH + prevJar;
            String currJarPath = JAR_PATH + currJar;
            /**
             *
             * 1.检查needMethods中 uniqueList中的每个方法在prevJar中是否存在，只要有一个方法不存在就返回false
             * 2.如果uniqueList中的每个方法都在prevJar中存在，则从头开始进行方法比较
             */

            List<String> needMethodList = new ArrayList<>();
            needMethodList.addAll(needMethods.getUniqueList());
            needMethodList.addAll(needMethods.getCommonList());
            int size = needMethodList.size();
            if (size == 0) {
                FileUtil.writeFlie(RESULT_PATH + "false-1" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(false, -1)));
                continue;
            }
            //解压两个版本的jar包

            String preUnzipPath = unzipJar(preJarPath, prevJar);
            String currUnzipPath = unzipJar(currJarPath, currJar);
            boolean hasOutput = false;
            for (int index = 0; index < size; index++) {
                String currJarMethod = needMethodList.get(index);
                System.out.println(prevJar + currJarMethod);
                System.out.println(currJar + currJarMethod);
                //preMethods 和 currMethods 表示将Method String 转化为SootMethod的两个方法
                List<SootMethod> preMethods = SootUtils.convertStringToSootMethod(args, prevJar, preUnzipPath, currJarMethod, JAR_PATH);
                List<SootMethod> currMethods = SootUtils.convertStringToSootMethod(args, currJar, currUnzipPath, currJarMethod, JAR_PATH);

                int preSize = preMethods.size();
                int currSize = currMethods.size();

                if (preSize + currSize == 0) {
                    //两个都没找到对应方法，忽略
                    continue;
                } else if (preSize + currSize == 1) {
                    //一个找到一个没找到，需要发生替换
                    hasOutput = true;
                    FileUtil.writeFlie(RESULT_PATH + "true1" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(true, 1)));
                    break;
                }

                List<String> preInvokeMethodList = SootUtils.getInvokeMethodList(args, prevJar, preUnzipPath, currJarMethod, JAR_PATH, preMethods);
                List<String> currInvokeMethodList = SootUtils.getInvokeMethodList(args, currJar, currUnzipPath, currJarMethod, JAR_PATH, currMethods);

                if (preInvokeMethodList.size() != currInvokeMethodList.size()) {
                    //如果发生变化
                    hasOutput = true;
                    FileUtil.writeFlie(RESULT_PATH + "true1" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(true, 1)));
                    break;
                }
                boolean same = compareMethodList(preInvokeMethodList, currInvokeMethodList, args, prevJar, preUnzipPath, currJar, currUnzipPath, JAR_PATH);

                if (!same) {
                    //如果发生变化
                    hasOutput = true;
                    FileUtil.writeFlie(RESULT_PATH + "true1" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(true, 1)));
                    break;
                }
            }
            if (!hasOutput) {
                FileUtil.writeFlie(RESULT_PATH + "false-1" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(false, -1)));
            }

            removeUnzip(preUnzipPath);
            removeUnzip(currUnzipPath);

        }

    }

    private static void removeUnzip(String preUnzipPath) throws IOException {
        FileUtils.deleteDirectory(new File(preUnzipPath));
    }

    private static boolean compareMethodList(List<String> preMethodList, List<String> currMethodList, String[] args, String prevJar, String preUnzipPath, String currJar, String currUnzipPath, String jarPath) {
        int size = preMethodList.size();
        for (int index = 0; index < size; index++) {
            String prevMethod = preMethodList.get(index);
            String currMethod = currMethodList.get(index);

            SootMethod preSootMethod = SootUtils.convertStringToSootMethod(args, prevJar, preUnzipPath, prevMethod, JAR_PATH).get(0);
            SootMethod currSootMethod = SootUtils.convertStringToSootMethod(args, currJar, currUnzipPath, currMethod, JAR_PATH).get(0);
            boolean isSame = SootUtils.compareSootMethod(preSootMethod, currSootMethod);
            //如果比到不相同，直接返回
            if (!isSame) {
                return false;
            }

        }
        return true;
    }

    /**
     * 生成需要调查的方法
     *
     * @param prevMethodList
     * @param currMethodList
     * @return
     */
    private static NeedMethods initFinalList(List<String> prevMethodList, List<String> currMethodList) {
        NeedMethods needMethods = new NeedMethods();

        //加入条件：
        //curr中的方法，若在prev中存在，添加到commonList
        //若不在prev中存在，添加到uniqueList
        for (String currMethod : currMethodList) {
            if (prevMethodList.contains(currMethod)) {
                needMethods.addCommonMethod(currMethod);
            } else {
                needMethods.addUniqueMethod(currMethod);
            }
        }
        return needMethods;
    }

    private static String unzipJar(String preJarPath, String jarName) {
        String newPath = UNZIP_PATH + jarName.substring(0, jarName.length() - 4) + "_unzip";
        File ff = new File(newPath);
        if (!ff.exists()) {
            ZipUtil.zip(preJarPath, newPath);
        }
        return newPath;
    }

}
