package cn.edu.fudan.se.cfg.rq2.bean;

import java.util.List;

public class Meta {
    String curr_jar;
    String prev_jar;

    List<String> curr_api_call_list;
    List<String> prev_api_call_list;

    public String getCurr_jar() {
        return curr_jar;
    }

    public void setCurr_jar(String curr_jar) {
        this.curr_jar = curr_jar;
    }

    public String getPrev_jar() {
        return prev_jar;
    }

    public void setPrev_jar(String prev_jar) {
        this.prev_jar = prev_jar;
    }

    public List<String> getCurr_api_call_list() {
        return curr_api_call_list;
    }

    public void setCurr_api_call_list(List<String> curr_api_call_list) {
        this.curr_api_call_list = curr_api_call_list;
    }

    public List<String> getPrev_api_call_list() {
        return prev_api_call_list;
    }

    public void setPrev_api_call_list(List<String> prev_api_call_list) {
        this.prev_api_call_list = prev_api_call_list;
    }

    public Meta() {

    }

    public Meta(String curr_jar, String prev_jar, List<String> curr_api_call_list, List<String> prev_api_call_list) {

        this.curr_jar = curr_jar;
        this.prev_jar = prev_jar;
        this.curr_api_call_list = curr_api_call_list;
        this.prev_api_call_list = prev_api_call_list;
    }
}
