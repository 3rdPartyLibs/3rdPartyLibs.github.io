package cn.edu.fudan.se.util;

import cn.edu.fudan.se.cfg.RunShell;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 对java方法的一些处理
 */
public class JavaMethodUtil {

    private static final String API_DOC_PATH = "D:\\doc\\jdk-8u181-docs-all\\docs\\api\\";
    private static final String JAR_TOOL_PATH = "C:\\jd-cli.jar";

    /**
     * 是否是jdk内的方法
     * 判断是否存在该类的html文件，如果存在说明是jdk内的方法，否则不是
     *
     * @param className eg:java.lang.StringBuilder
     * @return
     */
    public static boolean isJDKMethod(String className) {

        //把 java.lang.StringBuilder 转变为 java/lang/StringBuilder
        className = className.replaceAll("\\.", "/");
        String fileName = API_DOC_PATH + className + ".html";

        File file = new File(fileName);
        return file.exists();
    }

    public static InputStream readFileInputStream(String fileName) {
        File file = new File(fileName);
        InputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            return fileInputStream;
        }
    }

    /**
     * @param jarPath
     * @param outPath
     * @return 输出路径
     */
    public static String decompileJar(String jarPath, String outPath) {
        File file = new File(jarPath);
        String decompilePath = outPath + file.getName().substring(0, file.getName().length() - 4) + "_decompile/";
        File testFile = new File(decompilePath);//testFile用来查看是否已经反编译
        if (testFile.isDirectory() && testFile.exists()) {
            //如果是个目录且存在
            return decompilePath;
        }
/*        File[] files = f.listFiles();
        List<String> shs = new ArrayList<>();*/
        String sh = "java -jar " + JAR_TOOL_PATH + " --outputDir ";
        if (file.getAbsolutePath().endsWith(".jar")) {
            sh += outPath + "/" + file.getName().substring(0, file.getName().length() - 4) + "_decompile ";
            sh += file.getPath().replace('\\', '/');
           // System.out.println(sh);
            System.out.println(sh);
            RunShell.execToString(sh);
        }
        return decompilePath;
    }

    public static CompilationUnit getCompilationUnit(String fileName) {
        try {
            return getCompilationUnit(readFileInputStream(fileName));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    private static CompilationUnit getCompilationUnit(InputStream is) throws Exception {

        ASTParser astParser = ASTParser.newParser(AST.JLS8);
        astParser.setKind(ASTParser.K_COMPILATION_UNIT);
        BufferedInputStream bufferedInputStream = new BufferedInputStream(is);
        byte[] input = new byte[bufferedInputStream.available()];
        bufferedInputStream.read(input);
        bufferedInputStream.close();
        Map options = JavaCore.getOptions();
        options.put(JavaCore.COMPILER_COMPLIANCE, JavaCore.VERSION_1_8);
        options.put(JavaCore.COMPILER_CODEGEN_TARGET_PLATFORM, JavaCore.VERSION_1_8);
        options.put(JavaCore.COMPILER_SOURCE, JavaCore.VERSION_1_8);
        options.put(JavaCore.COMPILER_DOC_COMMENT_SUPPORT, JavaCore.ENABLED);

//        astParser.setEnvironment(null, null, null, true);
//        astParser.setUnitName("ClusterAction2");//需要与代码文件的名称一致
//        astParser.setResolveBindings(true);
//        astParser.setBindingsRecovery(true);

        astParser.setCompilerOptions(options);
        astParser.setSource(new String(input).toCharArray());
        CompilationUnit result = (CompilationUnit) (astParser.createAST(null));
        return result;
    }

    /**
     * 得到方法名
     *
     * @param method com.xxx.xxx.yyy(aaa,bbb) or com.xxx.xxx$xxx.yyy(aaa,bbb,ccc)
     * @return
     */
    public static String getMethodName(String method) {
        String preMethod = method.split("\\(")[0];
        int lastDotIndex = preMethod.lastIndexOf(".");
        return preMethod.substring(lastDotIndex + 1);

    }


    /**
     * 判断是否是构造函数
     *
     * @param method com.xxx.xxx.method(java.lang.String) or com.xxx.xxx&yyy.method(java.lang.String)
     * @return
     */
    public static boolean isConstructor(String method) {
        String preMethod = method.split("\\(")[0];//com.xxx.xxx.method or com.xxx.xxx&yyy.method
        String[] preMethods = preMethod.split("\\.");
        int size = preMethods.length;

        String methodName = preMethods[size - 1];
        String className = preMethods[size - 2];
        return methodName.equals(className);
    }

    /**
     * 将构造函数转化为 xxx.xxx.<init>(java.lang.String)格式
     *
     * @param method
     */
    public static String formatConstructor(String method) {
        String preMethod = method.split("\\(")[0];
        String postMethod = "(" + method.split("\\(")[1];
        int lastDotIndex = preMethod.lastIndexOf(".");
        return method.substring(0, lastDotIndex+1) + "<init>" + postMethod;
    }
}
