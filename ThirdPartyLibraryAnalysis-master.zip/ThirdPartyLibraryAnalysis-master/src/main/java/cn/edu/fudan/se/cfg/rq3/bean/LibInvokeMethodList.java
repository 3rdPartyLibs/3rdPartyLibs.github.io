package cn.edu.fudan.se.cfg.rq3.bean;

import java.util.Map;

public class LibInvokeMethodList {

    Map<String,String > stringStringMap;

}
