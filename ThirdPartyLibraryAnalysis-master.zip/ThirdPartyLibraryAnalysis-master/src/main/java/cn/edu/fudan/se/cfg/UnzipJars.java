package cn.edu.fudan.se.cfg;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by huangkaifeng on 2018/10/29.
 */
public class UnzipJars {

    public static void main(String args[]){
        String inputPath = args[0];
        String output = args[1];
        int num = Integer.valueOf(args[2]);
        int num2 = Integer.valueOf(args[3]);
        run(inputPath,output,num,num2);

    }
    public static void run(String inputPath,String outputPath,int a,int b) {
        File f = new File(inputPath);
        File[] files = f.listFiles();
//        List<String> unzipPath = new ArrayList<>();
//        List<String> jarPath = new ArrayList<>();
        int cnt =0;
        for (File tmp : files) {
            if (tmp.getAbsolutePath().endsWith(".jar")) {
                String jarName = tmp.getName();
                String newPath = outputPath+"/"+ jarName.substring(0, jarName.length() - 4) + "_unzip";
                File ff = new File(newPath);
                if (!ff.exists()&& cnt>=a && cnt<b) {
                    System.out.println(cnt+" "+jarName);
                    ZipUtil.zip(tmp.getAbsolutePath(), newPath);
                }
//                unzipPath.add(newPath);
//                jarPath.add(tmp.getAbsolutePath());
                //37321 bookkeeper-server-4.6.2-tests.jar
                cnt+=1;
            }
//            break;
        }
    }
}
