package cn.edu.fudan.se.cfg.rq2.utils;

import cn.edu.fudan.se.util.JavaMethodUtil;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import java.util.List;

public class JDTUtils {
    public static final String DECOMPILE_OUTPUT_PATH = "d:/cs/jar/decompile_output/";//反编译路径

    //反编译
    private static String decompileJar(String filePath) {
        String preJarOutputPath = JavaMethodUtil.decompileJar(filePath, DECOMPILE_OUTPUT_PATH);
        return preJarOutputPath;
    }

    public static String decompileJar(String filePath,String outputPath){
        String preJarOutputPath = JavaMethodUtil.decompileJar(filePath, outputPath);
        return preJarOutputPath;
    }

    //java文件生成BodyDeclaration列表
    public static List<BodyDeclaration> getCompilationUnit(String javaFilePath) {
        CompilationUnit compilationUnit = JavaMethodUtil.getCompilationUnit(javaFilePath);
        if (compilationUnit.types().get(0) instanceof TypeDeclaration) {
            return ((TypeDeclaration) compilationUnit.types().get(0)).bodyDeclarations();
        }
        return null;
    }

    public static List<BodyDeclaration> getCompilationUnitByJar(String jar, String filePath) {
        String jarOutput = decompileJar(jar);
        return getCompilationUnit(jarOutput + "/" + filePath);
    }

    /**
     * 方法名转java文件的路径
     * <p>
     * com.basti.className.method(xxx,yyy)
     * com.basti.className$innerClassName.method(xxx,yyy)
     *
     * @param invokeMethod
     * @return
     */
    public static String packageToJavaPath(String invokeMethod) {
        int index = invokeMethod.indexOf("(");
        String methodName = invokeMethod.substring(0, index);//com.basti.className.method or com.basti.className$innerClassName.method
        int lastDotIndex = methodName.lastIndexOf(".");
        String className = methodName.substring(0, lastDotIndex);
        String javaPath = className.replaceAll("\\.", "/") + ".java";

        return javaPath;
    }
}
