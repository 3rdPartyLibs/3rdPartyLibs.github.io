package cn.edu.fudan.se.cfg.rq1;

import soot.Scene;
import soot.SootClass;
import soot.options.Options;
import soot.util.HashChain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestSoot {

    public static void main(String[] args) {

        String classesPath = "D:\\cs\\jar\\jar\\TestJar31.jar";

        List<String> argsList = new ArrayList<>();
        //
        argsList.addAll(Arrays.asList(new String[]{"-allow-phantom-refs", "-w",
                // "-no-bodies-for-excluded",
                "-cp", classesPath, "-process-dir",
                classesPath}));
        String[] arg = argsList.toArray(new String[0]);
        Options.v().parse(arg);
        Scene.v().loadClassAndSupport("com.basti.Test");
        SootClass sootClass = Scene.v().getSootClass("com.basti.Test");
        HashChain<SootClass> sootClasses = (HashChain<SootClass>) Scene.v().getApplicationClasses();
        int a = 1;
    }

}
