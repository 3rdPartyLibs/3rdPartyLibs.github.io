package cn.edu.fudan.se.handlepom;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.maven.model.Dependency;
import org.apache.maven.model.Model;
import org.apache.maven.model.Profile;

import cn.edu.fudan.se.git.JgitRepository;

public class ChangedPomModel extends PomModel {

	private JgitRepository repo;
	private String commitId;	
//	private String fileModule = "";
//	private String[] prefix;
//	private String rootPrefix = "";
//	private int level = 0;
	
	
	public ChangedPomModel(String path,JgitRepository repo,String commitId,String resultPath,String pomFilePath,String unsolvedPomFilePath,String serverIp) {
		super(resultPath,pomFilePath,unsolvedPomFilePath,serverIp);
		this.projectPath = path;
		this.repo = repo;
		this.commitId = commitId;
	}
	
	public static String parsePath(String path) {
		if(!path.contains("../")) {
			return path;
		}
		int index = path.indexOf("../");
		while(index >= 0) {
			String prefix = path.substring(0,index);
			if(prefix.endsWith("/"))
				prefix = prefix.substring(0,prefix.length()-1);
			String postfix = path.substring(index + 3);
			index = prefix.lastIndexOf("/");
			if(index >= 0) {
				prefix = prefix.substring(0, index + 1);
				path = prefix + postfix;
			}
			else
				return postfix;
			index = path.indexOf("../");
		}
		return path;
	}
	
	public void handlePom(String fileName) {
		fileName = fileName.replace("\\", "/");
		System.out.println(fileName);
		int index = fileName.lastIndexOf("/");
		if(index >= 0)
			this.module = fileName.substring(0,index);
//		System.out.println("this.module: "+this.module);
		
//		InputStream is = this.repo.extract("actionbarsherlock/library/../pom.xml", this.commitId);
//		System.out.println(is);
		InputStream is = this.repo.extract(fileName, this.commitId);
		Model tempModel = PomFileReader.parsePomFileToModel(is);
//		try {
		if(tempModel != null)
			readModel(tempModel,fileName,false,false);
		while(!getVersionFromPomLibOrParent(tempModel)) {						
		}
		addToLibVerPairs(this.libVerPairs,this.allLibVerPairs);
//		}
//		catch (OutOfMemoryError e) {
//			// TODO Auto-generated catch block
////			e.printStackTrace();
//			System.out.println("OutOfMemoryError");
//		} 
	}
	
	public boolean isParent(String pomPath,String groupId,String artifactId,String version) {	
//		String completePath = pomPath;
		InputStream is = this.repo.extract(pomPath, this.commitId);
		Model model = PomFileReader.parsePomFileToModel(is);
//		Model model = PomFileReader.parsePomFileToModel(completePath);	
		if(model == null)
			return false;
		
		String parentGroupId = model.getGroupId();
		String parentArtifactId = model.getArtifactId();
		String parentVersion = model.getVersion();
//		System.out.println(parentGroupId +" "+parentArtifactId+" "+parentVersion);
//		System.out.println(groupId +" "+artifactId+" "+version);
		if(parentGroupId != null && groupId != null && !parentGroupId.equals(groupId))
			return false;
		if(parentArtifactId != null && artifactId != null && !parentArtifactId.equals(artifactId))
			return false;
		if(parentVersion != null && version != null && !parentVersion.equals(version) && !version.equals("@project.version@"))
//		if(parentVersion != null && version != null && !parentVersion.equals(version))
			return false;
		return true;
	}	
	
	@Override
	public void readModel(Model model,String path,boolean isPomLib,boolean isParent) {			
		if(model.getProperties() != null)
			putAllToProperties(model.getProperties());
//			this.properties.putAll(model.getProperties());
		// repositories in profiles
		if(model.getProfiles() != null) {
  			List<Profile> profiles = model.getProfiles();
  			List<Properties> propertiesInOneFile = new ArrayList<>();
  			propertiesInOneFile.add(model.getProperties());
  			for(Profile pro : profiles) {  				
  				Properties profileProperties = pro.getProperties();
  				if(profileProperties != null) { 					
  					propertiesInOneFile.add(profileProperties); 
  				}
//  				handleRepositories(pro.getRepositories(),model);
  			} 		
  			this.propertiesInProfile.add(propertiesInOneFile);
  		}		
		// repositories
		handleRepositories(model.getRepositories(),model);
		if(model.getProfiles() != null) {
			List<Profile> profiles = model.getProfiles();
  			for(Profile pro : profiles) {  				  				
  				handleRepositories(pro.getRepositories(),model);
  			} 		 			
  		}	
		
		//处理parent
		if(model.getParent() != null) {	
//			System.out.println("path : "+path);						
			String parentGroupId = model.getParent().getGroupId();
			String parentArtifactId = model.getParent().getArtifactId();
			String parentVersion = model.getParent().getVersion();
			
			String parentPath = model.getParent().getRelativePath().replace("\\", "/");
			if(parentPath.equals(""))			
				handlePomType(parentGroupId,parentArtifactId,parentVersion,true,true);
			else {
				if(!(parentPath.endsWith("pom.xml") || parentPath.endsWith(".xml"))) {
//				if(!parentPath.endsWith("pom.xml")) {
					if(!parentPath.endsWith("/"))
						parentPath+="/";
					parentPath+="pom.xml";
				}				

				if(parentPath.startsWith("/"))
					parentPath = parentPath.substring(1);
				String prefix = path;
				
				if(prefix.endsWith(".xml")) {
					int lastPathSeparatorIndex = prefix.lastIndexOf("/");
					if(lastPathSeparatorIndex<0) {
						prefix = "";
					}
					else 
						prefix = prefix.substring(0, lastPathSeparatorIndex);
//						prefix = prefix.substring(0, prefix.length()-7);
					if(prefix.endsWith("/")||prefix.endsWith("\\"))
						prefix = prefix.substring(0, prefix.length()-1);
//					System.out.println(prefix);
					String parentWholePath = prefix+"/"+parentPath;	
					if(prefix.equals("")) {
						parentWholePath = parentPath;	
					}
					parentWholePath = parsePath(parentWholePath);
//					System.out.println("parent: "+this.projectPath+"/"+parentWholePath);
					System.out.println("++++ parent: "+parentWholePath);
					InputStream is = this.repo.extract(parentWholePath, this.commitId);
//					System.out.println(is);
					if(is != null && isParent(parentWholePath,parentGroupId,parentArtifactId,parentVersion)) {
//						System.out.println("================== enter");
//					if(new File(this.projectPath+"/"+parentWholePath).exists() 
//							&& isParent(this.projectPath+"/"+parentWholePath,parentGroupId,parentArtifactId,parentVersion)) {							
//						Model tempModel = PomFileReader.parsePomFileToModel(this.projectPath+"/"+parentWholePath);
						Model tempModel = PomFileReader.parsePomFileToModel(is);
						if(tempModel != null) {						
							readModel(tempModel,parentWholePath,false,true);		
						}
					}						
					else
						handlePomType(parentGroupId,parentArtifactId,parentVersion,true,true);				
				}
				else if(prefix.endsWith(".pom")) {
					handlePomType(parentGroupId,parentArtifactId,parentVersion,true,true);						
				}
			}
		}
        
//        if(this.propertiesInProfile.size() == 0) {
//        	this.propertiesList = new ArrayList<>();
//        	this.propertiesList.add(this.properties);
//        }
//        if(this.propertiesInProfile.size() > this.currPropertiesListLevel) {
//        	this.propertiesList = getPropertiesWithAllProfiles();
//        	this.currPropertiesListLevel = this.propertiesInProfile.size();
//        }
		
		if(this.propertiesInProfile.size() == 0) {
        	List<Properties> firstLevel = new ArrayList<>();
        	firstLevel.add(this.properties);
        	this.propertiesInProfile.add(firstLevel);
        }
		if(this.propertiesInProfile.size() > 1) {
        	getPropertiesWithAllProfiles();
        }
		
		//处理profile
  		if(model.getProfiles() != null) {
  			List<Profile> profiles = model.getProfiles();
  			for(Profile pro : profiles) {
  				handleProfile(pro,model, isPomLib, isParent);
  			}
  		}		
  		
		List<Dependency> dependencies = model.getDependencies();
		parseDependencyFromList(dependencies,false,model,isPomLib,isParent); 
		if (model.getDependencyManagement() != null) {
			dependencies = model.getDependencyManagement().getDependencies();
			parseDependencyFromList(dependencies,true,model,isPomLib,isParent);
		}	
	}
	
//	public static void main(String[] args) {
//		System.out.println(ChangedPomModel.parsePath("123/../"));
//	}
}
