package cn.edu.fudan.se.cfg.gradle.parse;

import cn.edu.fudan.se.cfg.gradle.parse.bean.LibObj;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.util.*;

/**
 * 将Maven中已经有的jar包在Gradle项目中去除
 */
public class MergeGradleAndMavenJar {
    private static final String MAVEN_JAR_FILE_NAME = "C:/cs/pyspace/wy/Crawler/12.12.txt";
    private static final String Gradle_JAR_FILE_NAME = "F:/mergeLib.json";
    private static Map<String, LibObj> gradleJarMap = new HashMap<>();

    public static void main(String[] args) {
        String mavenContent = FileUtil.read(MAVEN_JAR_FILE_NAME);
        String gradleContent = FileUtil.read(Gradle_JAR_FILE_NAME);
        List<LibObj> mavenLibObjList = new Gson().fromJson(mavenContent, new TypeToken<List<LibObj>>() {
        }.getType());
        List<LibObj> gradleLibObjList = new Gson().fromJson(gradleContent, new TypeToken<List<LibObj>>() {
        }.getType());

        /**
         * gradle Jar包的map形式
         */
        convertToMap(gradleLibObjList);

        //遍历筛选
        int count = 0;
        for (LibObj mavenLibObj : mavenLibObjList) {
            if (gradleJarMap.containsKey(mavenLibObj.getLib_name())) {
                //如果gradleMap中包含这个maven中的jar包，在gradle中去除这个jar包
                LibObj gradleLibObj = gradleJarMap.get(mavenLibObj.getLib_name());
                Set<String> mavenVersionSet = mavenLibObj.getVersions_array();
                Set<String> gradleVersionSet = gradleLibObj.getVersions_array();
                for (String mavenVersion : mavenVersionSet) {
                    boolean removeSuccess = gradleVersionSet.remove(mavenVersion);
                    if (removeSuccess) {
                        count++;
                        System.out.println(count+" "+gradleLibObj.getLib_name() + "  " + mavenVersion);
                    }
                }
                gradleLibObj.setRepo_array(mavenLibObj.getRepo_array());
            }
        }
        //得到gradleMap中间结果
        FileUtil.writeFlie("F:/gradle_maven_merge_temp.json", new GsonBuilder().setPrettyPrinting().create().toJson(gradleJarMap));

        //遍历Map
        List<LibObj> resultList = new ArrayList<>();
        Iterator iter = gradleJarMap.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            LibObj val = (LibObj) entry.getValue();
            if (val.getVersions_array().size() != 0) {
                resultList.add(val);
            }
        }
        FileUtil.writeFlie("F://gradle_maven_merge.json", new GsonBuilder().setPrettyPrinting().create().toJson(resultList));

    }

    private static void convertToMap(List<LibObj> gradleLibObj) {
        for (LibObj libObj : gradleLibObj) {
            gradleJarMap.put(libObj.getLib_name(), libObj);
        }
    }
}
