package cn.edu.fudan.se.util;

import java.io.*;

import cn.edu.fudan.se.cfg.ZipUtil;
import org.eclipse.jgit.errors.IncorrectObjectTypeException;
import org.eclipse.jgit.errors.MissingObjectException;
import org.eclipse.jgit.lib.Constants;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.treewalk.WorkingTreeOptions;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class FileUtil {
    public static byte[] toByteArray(InputStream input) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        copy(input, output);
        return output.toByteArray();
    }

    public static long copyLarge(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[4096];
        long count = 0L;
        int n = 0;
        while (-1 != (n = input.read(buffer))) {
            output.write(buffer, 0, n);
            count += n;
        }
        return count;
    }

    public static int copy(InputStream input, OutputStream output) throws IOException {
        long count = copyLarge(input, output);
        if (count > 2147483647L) {
            return -1;
        }
        return (int) count;
    }

    public static InputStream open(ObjectId blobId, Repository db) throws IOException, IncorrectObjectTypeException {
        if (blobId == null)
            return new ByteArrayInputStream(new byte[0]);

        try {
            WorkingTreeOptions workingTreeOptions = db.getConfig().get(WorkingTreeOptions.KEY);
            switch (workingTreeOptions.getAutoCRLF()) {
                case INPUT:
                    // When autocrlf == input the working tree could be either CRLF
                    // or LF, i.e. the comparison
                    // itself should ignore line endings.
                case FALSE:
                    return db.open(blobId, Constants.OBJ_BLOB).openStream();
                case TRUE:
                default:
                    return db.open(blobId, Constants.OBJ_BLOB).openStream();
//				return new AutoCRLFInputStream(db.open(blobId, Constants.OBJ_BLOB).openStream(), true);
            }
        } catch (MissingObjectException notFound) {
            return null;
        }
    }

    public static void appendFile(String path, String content) {
        FileWriter writer = null;
        try {
            // 打开一个写文件器，构造函数中的第二个参数true表示以追加形式写文件     
            writer = new FileWriter(path, true);
            writer.write(content + "\r\n");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 使用FileWriter类写文本文件
     */
    public static void writeFlie(String fileName, String content) {

        try {
            FileWriter writer = new FileWriter(fileName);
            writer.write(content);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 读文件
     *
     * @param path
     * @return
     */
    public static String read(String path) {
        File file = new File(path);
        BufferedReader reader = null;
        StringBuilder result = new StringBuilder();
        try {
            // System.out.println("以行为单位读取文件内容，一次读一整行：");
            reader = new BufferedReader(new FileReader(file));

            String tempString = "";
            int line = 1;
            // 一次读入一行，直到读入null为文件结束
            while ((tempString = reader.readLine()) != null) {
                // 显示行号
                result.append(tempString).append("\r\n");
                line++;
            }
            result = new StringBuilder(result.substring(0, result.length() - 2));
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                    return result.toString();
                } catch (IOException e1) {
                }
            }
        }

        return null;
    }


    public static String unzipJar(String unzipPath, String jarPath, String jarName) {
        String newPath = unzipPath + jarName.substring(0, jarName.length() - 4) + "_unzip";
        File ff = new File(newPath);
        if (!ff.exists()) {
            ZipUtil.zip(jarPath, newPath);
        }
        return newPath;
    }


}
