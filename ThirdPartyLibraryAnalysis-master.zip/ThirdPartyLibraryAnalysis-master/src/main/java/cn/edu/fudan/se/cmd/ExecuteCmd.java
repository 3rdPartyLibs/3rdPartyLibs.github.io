package cn.edu.fudan.se.cmd;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class ExecuteCmd {

	public static void main(String[] args) {
		checkout("E:/maven500/netty__fdse__netty","0f1a2ca5ae01edff1f5ef667122b43f581ef92f4");
		//e4531918a394ba87058d37c595e296e669f07a19 0f1a2ca5ae01edff1f5ef667122b43f581ef92f4
    }
	
	public static boolean checkout(String projPath,String commitId) {
		boolean success = false;
//		String cmdStr = "git -C " + gitPath + " checkout -f " + commitId;
		String cmdStr = "git --git-dir=" + projPath + "/.git --work-tree=" + projPath + " checkout -f " + commitId;
		System.out.println(cmdStr);
//		String cmdStr = "git --git-dir=F:/astrid/.git status";
        Runtime run = Runtime.getRuntime();
        try {
            Process process = run.exec(cmdStr);
            InputStream in = process.getInputStream();
            InputStreamReader reader = new InputStreamReader(in);
            BufferedReader br = new BufferedReader(reader);
            StringBuffer sb = new StringBuffer();
            String message;
            while((message = br.readLine()) != null) {
                sb.append(message+"\n");
            }
            System.out.println(sb);
            success = true;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return success;
	}
	
	
}
