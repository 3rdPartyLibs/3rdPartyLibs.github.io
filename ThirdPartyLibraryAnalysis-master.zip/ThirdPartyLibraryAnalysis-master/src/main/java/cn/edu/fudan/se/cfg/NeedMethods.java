package cn.edu.fudan.se.cfg;

import java.util.ArrayList;
import java.util.List;

public class NeedMethods {

    List<String> commonList;
    List<String> uniqueList;

    public NeedMethods() {
        commonList = new ArrayList<>();
        uniqueList = new ArrayList<>();
    }

    public List<String> getCommonList() {

        return commonList;
    }

    public void addCommonMethod(String method) {
        commonList.add(method);
    }

    public void addUniqueMethod(String method) {
        uniqueList.add(method);
    }

    public void setCommonList(List<String> commonList) {
        this.commonList = commonList;
    }

    public List<String> getUniqueList() {
        return uniqueList;
    }

    public void setUniqueList(List<String> uniqueList) {
        this.uniqueList = uniqueList;
    }

    public NeedMethods(List<String> commonList, List<String> uniqueList) {

        this.commonList = commonList;
        this.uniqueList = uniqueList;
    }
}
