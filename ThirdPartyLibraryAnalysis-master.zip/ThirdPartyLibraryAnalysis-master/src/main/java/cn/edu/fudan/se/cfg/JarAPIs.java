package cn.edu.fudan.se.cfg;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.github.javaparser.ast.CompilationUnit;

import cn.edu.fudan.se.api.JarAnalyzer;
import cn.edu.fudan.se.ast.AstParser;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
/**
 * 反编译的jar包目录 -> api的json list
 * 
 * @author huangkaifeng
 *
 */
public class JarAPIs {

	private static String output ;
	public static void main(String args[]) {
		
//		runBatch();
		runPair();
	}
	public static void runPair(){
		String decompiledLibPath = "E:/wangying/third_party_libs_decomplie";
		String outputPath = "E:/wangying/third_party_lib_apis";
		JarAPIs.output = outputPath;
		String libA = "accumulo-minicluster-1.6.6_decompile";
		String libB = "accumulo-minicluster-1.7.4_decompile";
		File libAF = new File(decompiledLibPath+"/"+libA);
		File libBF = new File(decompiledLibPath+"/"+libB);
		
		String dir = libAF.getAbsolutePath();
		List<File> files = new ArrayList<>();
		browse(dir, files);
		parseFiles(dir,dir,files);
		
		dir = libBF.getAbsolutePath();
		files = new ArrayList<>();
		browse(dir, files);
		parseFiles(dir,dir,files);
	}
	public static void runBatch(){
		String decompiledLibPath = "E:/wangying/third_party_libs_decomplie";
		String outputPath = "E:/wangying/third_party_lib_apis";
		JarAPIs.output = outputPath;
		File f = new File(decompiledLibPath);
		File[] libs = f.listFiles();
		for(File lib:libs){
			String dir = lib.getAbsolutePath();
			List<File> files = new ArrayList<>();
			browse(dir, files);
			parseFiles(dir,dir,files);
			break;
		}
	}

	public static void browse(String dir, List<File> fileList) {
		File root = new File(dir);
		File[] files = root.listFiles();
		for (File file : files) {
			if (file.isFile() && file.getName().endsWith(".java") && !file.getName().contains("$")) {
				fileList.add(file);
			}
			if (file.isDirectory()) {
				browse(file.getAbsolutePath(), fileList);
			}
		}
	}

	private static void parseFiles(String dir, String pathPrefix, List<File> fileList) {
		JarAnalyzer jaran = new JarAnalyzer();
		JSONArray jsonArray = new JSONArray();
		for (File file : fileList) {
			
			String absolutePath = file.getAbsolutePath();
			absolutePath = absolutePath.substring(0, absolutePath.length() - 5);//trim java
			
			if (absolutePath.replace("\\", "/").startsWith(pathPrefix.replace("\\", "/"))) {
//				System.out.println(absolutePath);
				String apiClass = absolutePath.substring(pathPrefix.length() + 1).replace("/", ".").replace("\\", ".");
				System.out.println(apiClass);
				try {
					CompilationUnit cu = AstParser.getCompilationUnit(file.getAbsolutePath().replace("\\", "/"));
					if(cu==null){
						continue;
					}
					Map<String, String> apis = jaran.getApiWithHashCode(cu , apiClass);
					JSONObject clazz = jaran.apiPersistenceWithHashCode(apiClass, apis);
//					System.out.println(clazz.toString(4));
					if (clazz != null) {
						jsonArray.add(clazz);
					}
				} catch (IOException e) {
					e.printStackTrace();
				} catch (OutOfMemoryError e) {
//					 e.printStackTrace();
				}

			}
//			break;
		}
		String jar = dir.substring(dir.lastIndexOf("\\")+1);
		writeInAll(jar,jsonArray.toString(4));
		
	}
	
	public static void writeInAll(String jarName, String content) {
		try {
			String path = JarAPIs.output +"/" +jarName+".json";
			FileOutputStream fos = new FileOutputStream(path);
			fos.write(content.getBytes());
			fos.flush();
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
