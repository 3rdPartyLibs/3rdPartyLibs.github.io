package cn.edu.fudan.se.util;
public class MyException extends Exception {
  public MyException() {

  }
  public MyException(String s){
       super(s);
  }

}
//System.out.println(api);
//try {
//	throw new MyException("MethodDeclaration :" + count );
//	
//} catch (MyException e) {
//	// TODO Auto-generated catch block
//	e.printStackTrace();
//	System.exit(0);
//
//}