package cn.edu.fudan.se.cfg;

import cn.edu.fudan.se.util.FileUtil;
import cn.edu.fudan.se.util.JavaMethodUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import soot.*;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.options.Options;
import soot.util.dot.DotGraph;
import soot.util.dot.DotGraphNode;

import java.io.File;
import java.lang.reflect.Field;
import java.util.*;

public class MethodDiff {

//    static final String DECOMPILE_OUTPUT_PATH = "d:/cs/jar/decompile_output/";//反编译路径
//    static final String JAR_PATH = "I:\\wangying\\lib_all\\";//jar包所在的路径
//    static final String META_PATH = "D:\\cs\\jar\\final_output\\";//所有meta文件所在的目录路径
//    static final String UNZIP_PATH = "D:\\cs\\jar\\unzip\\";//解压jar包的目录路径
//    static final String RESULT_PATH = "D:\\cs\\jar\\result\\";//输出结果目录
    static final String DECOMPILE_OUTPUT_PATH = "c:/cs/jar/decompile_output/";//反编译路径
    static final String JAR_PATH = "C:\\cs\\jar\\jar2\\";//jar包所在的路径
    static final String META_PATH = "C:\\cs\\jar\\meta2";//所有meta文件所在的目录路径
    static final String UNZIP_PATH = "C:\\cs\\jar\\unzip\\";//解压jar包的目录路径
    static final String RESULT_PATH = "C:\\cs\\jar\\result\\";//输出结果目录

    public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException {

        File file = new File(META_PATH);
        File[] metaList = file.listFiles();

        for (File metaFile : metaList) {
            //对于每一个meta文件

            //如果在输出结果目录存在该文件，说明已经解析过，跳过
            System.out.println("===========");
            System.out.println(metaFile.getName());
            File resultFile1 = new File(RESULT_PATH + "true1" + metaFile.getName());
            File resultFile2 = new File(RESULT_PATH + "false-1" + metaFile.getName());
            if (resultFile1.exists() || resultFile2.exists()) {
                continue;
            }
            //解析一个meta文件
            JSONObject jo = SootFileUtils.fromJsonText(metaFile.getAbsolutePath());
            String prevJar = jo.getString("prev_jar");
            String currJar = jo.getString("curr_jar");
            if (prevJar.contains("jooq")) {
                continue;
            }
            JSONArray jaPrevArray = (JSONArray) jo.get("prev_api_call_list");
            JSONArray jaCurrArray = (JSONArray) jo.get("curr_api_call_list");

            List<String> prevMethodStringList = new Gson().fromJson(jaPrevArray.toString(), new TypeToken<List<String>>() {
            }.getType());
            List<String> currMethodStringList = new Gson().fromJson(jaCurrArray.toString(), new TypeToken<List<String>>() {
            }.getType());

            //生成需要调查的方法列表
            NeedMethods needMethods = initFinalList(prevMethodStringList, currMethodStringList);
            String preJarPath = JAR_PATH + prevJar;
            String currJarPath = JAR_PATH + currJar;
            /* *//**
             *
             * 1.检查needMethods中 uniqueList中的每个方法在prevJar中是否存在，只要有一个方法不存在就返回false
             * 2.如果uniqueList中的每个方法都在prevJar中存在，则从头开始进行方法比较
             *//*


            List<String> uniqueMethodList = needMethods.getUniqueList();
            if (uniqueMethodList.size() != 0) {
                String preJarOutputPath = JavaMethodUtil.decompileJar(preJarPath, DECOMPILE_OUTPUT_PATH);
                for (String methodString : uniqueMethodList) {
                    //在prevJar中寻找method是否存在

                    boolean isExist = findMethodExist(methodString, preJarOutputPath);
                    if (!isExist) {
                        //不存在，直接更新
                        FileUtil.writeFlie(RESULT_PATH + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(true, 0)));
                        continue;
                    }
                }
            }*/
            List<String> needMethodList = new ArrayList<>();
            needMethodList.addAll(needMethods.getUniqueList());
            needMethodList.addAll(needMethods.getCommonList());
            int size = needMethodList.size();
            if (size == 0) {
                FileUtil.writeFlie(RESULT_PATH + "false-1" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(false, -1)));
                continue;
            }
            //解压两个版本的jar包

            String preUnzipPath = unzipJar(preJarPath, prevJar);
            String currUnzipPath = unzipJar(currJarPath, prevJar);
            boolean hasOutput = false;
            for (int index = 0; index < size; index++) {
                String currJarMethod = needMethodList.get(index);
                List<Method> preMethodList = invokeSoot(args, prevJar, preUnzipPath, currJarMethod, JAR_PATH);
                List<Method> currMethodList = invokeSoot(args, currJar, currUnzipPath, currJarMethod, JAR_PATH);
                System.out.println(String.valueOf(preMethodList.size()) + " " + String.valueOf(currMethodList.size()));
                if (currMethodList.size() != preMethodList.size()) {
                    //如果发生变化
                    hasOutput = true;
                    FileUtil.writeFlie(RESULT_PATH + "true1" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(true, 1)));
                    break;
                }

                boolean same = sameTwoVersionsMethodList(preMethodList, currMethodList, preJarPath, currJarPath);
                //System.out.println(different);
                if (!same) {
                    //如果发生变化
                    hasOutput = true;
                    FileUtil.writeFlie(RESULT_PATH + "true1" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(true, 1)));
                    break;
                }
            }
            if (!hasOutput) {
                FileUtil.writeFlie(RESULT_PATH + "false-1" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(false, -1)));
            }

        }

    }

    /**
     * 检查指定方法是否在某个jar包中存在
     *
     * @param methodString
     * @param preJarOutputPath
     * @return
     */
    private static boolean findMethodExist(String methodString, String preJarOutputPath) {

        //首先将methodString转化成一个Method
        //eg1:org.junit.Assert.assertEquals(long, long)//普通方法
        //eg2:org.junit.Assert.Assert(long, long) //构造方法
        //method:java.lang.StringBuilder: void <init>()
        String className_methodName = methodString.split("\\(")[0];
        //className_methodName:org.junit.Assert.assertEquals
        String[] classMethodNames = className_methodName.split("\\.");
        //classMethodNames:["org","junit","Assert","assertEquals]
        int size = classMethodNames.length;
        String className = "";
        for (int index = 0; index < size - 1; index++) {
            className += classMethodNames[index];
            if (index != size - 2) {
                className += ".";
            }
        }
        String methodName = classMethodNames[size - 1] + "(" + methodString.split("\\(")[1];
        //构造函数单独处理
        Method method;
        if (classMethodNames[size - 1].equals(classMethodNames[size - 2])) {
            //className:org.openjdk.jmh.util.Optional
            //methodName:void <init>(java.lang.Object)
            method = Method.initMethod(className, methodName);
        } else {
            method = new Method(className, methodName);

        }
        String preJavaPath = preJarOutputPath + "/" + method.getClassName().replaceAll("\\.", "/") + ".java";
        if (!new File(preJavaPath).exists()) {
            //java文件不存在
            return false;
        }

        CompilationUnit preUnit = JavaMethodUtil.getCompilationUnit(preJavaPath);
        TypeDeclaration preType = (TypeDeclaration) preUnit.types().get(0);
        List<BodyDeclaration> preBodyDeclarationList = preType.bodyDeclarations();
        for (BodyDeclaration bodyDeclaration : preBodyDeclarationList) {
            if (bodyDeclaration instanceof MethodDeclaration) {
                Method tempMethod = new Method((MethodDeclaration) bodyDeclaration);
                //判别是否是m1对应的方法
                if (method.isSameWithMethodDeclaration(tempMethod)) {
                    //tempMethod就是找到的方法
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 生成需要调查的方法
     *
     * @param prevMethodList
     * @param currMethodList
     * @return
     */
    private static NeedMethods initFinalList(List<String> prevMethodList, List<String> currMethodList) {
        NeedMethods needMethods = new NeedMethods();

        //加入条件：
        //curr中的方法，若在prev中存在，添加到commonList
        //若不在prev中存在，添加到uniqueList
        for (String currMethod : currMethodList) {
            if (prevMethodList.contains(currMethod)) {
                needMethods.addCommonMethod(currMethod);
            } else {
                needMethods.addUniqueMethod(currMethod);
            }
        }
        return needMethods;
    }

    private static String unzipJar(String preJarPath, String jarName) {
        String newPath = UNZIP_PATH + jarName.substring(0, jarName.length() - 4) + "_unzip";
        File ff = new File(newPath);
        if (!ff.exists()) {
            ZipUtil.zip(preJarPath, newPath);
        }
        return newPath;
    }


    public static List<Method> invokeSoot(String args[], String jarName, String classesPath, String methodNameString, String outputPath) throws NoSuchFieldException, IllegalAccessException {
        CallGraphVisitor callGraphVisitor = new CallGraphVisitor(outputPath + "/" + jarName + ".dot");
        List<String> classNames = new ArrayList<>();
        Map<String, List<String>> mmap = SootFileUtils.getClassNameAndMethodNames(methodNameString, classNames);
        G.reset();
        List<String> argsList = new ArrayList<>(Arrays.asList(args));
        //
        argsList.addAll(Arrays.asList(new String[]{"-allow-phantom-refs", "-w",
                // "-no-bodies-for-excluded",
                "-cp", classesPath, "-process-dir",
                classesPath}));

        args = argsList.toArray(new String[0]);
        Options.v().parse(args);
        Options.v().set_src_prec(Options.src_prec_java);
//        Options.v().set_process_dir(Collections.singletonList(processDir));
        Options.v().set_whole_program(true);
        Options.v().set_allow_phantom_refs(true);

//        Options.v().set_verbose(true);
        Options.v().set_output_format(Options.output_format_none);
        Options.v().setPhaseOption("cg.spark", "on");
        Options.v().set_no_bodies_for_excluded(true);
//        Options.v().set_app(true);
        enableSpark();
        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
//        String mainClass = "Test1";
//        SootClass c = loadClass("org.openjdk.jmh.runner.options.ChainedOptionsBuilder",false);
        List<SootMethod> entryPoints = SootUtil.loadEntryPoints(classNames, mmap);
        Scene.v().setEntryPoints(entryPoints);
//        enableSpark();
        PackManager.v().runPacks();
        CallGraph callGraph = Scene.v().getCallGraph();
        for (SootMethod entryPoint : entryPoints) {
            callGraphVisitor.visit(callGraph, entryPoint);
        }
        Body body = entryPoints.get(0).getActiveBody();
        DotGraph dotGraph = callGraphVisitor.getDot();
        /**
         * 反射获取dotGraph中的nodes变量
         */
        Class<DotGraph> dotGraphClass = (Class<DotGraph>) dotGraph.getClass();
        Field nodesField = dotGraphClass.getDeclaredField("nodes");
        nodesField.setAccessible(true);
        HashMap<String, DotGraphNode> nodes = (HashMap<String, DotGraphNode>) nodesField.get(dotGraph);
        List<Method> calledMethodList = new ArrayList<>();
        /**
         * nodes中存储着方法名，对方方法名进行遍历
         * calledMethodList中存储着在下一阶段我们需要比对的方法
         */
        for (Map.Entry<String, DotGraphNode> entry : nodes.entrySet()) {
            //eg1:<org.openjdk.jmh.util.Utils: void check(java.lang.Class,java.lang.String)>
            //eg2:<java.lang.StringBuilder: void <init>()>
            String method = entry.getKey();
            int length = method.length();
            method = method.substring(1, length - 1);
            //method:java.lang.StringBuilder: void <init>()
            String className = method.split(": ")[0];
            String methodName = method.split(": ")[1];
            boolean isJDKMethod = JavaMethodUtil.isJDKMethod(className);
            if (!isJDKMethod) {
                //构造函数单独处理
                if (methodName.contains(" <init>")) {
                    //className:org.openjdk.jmh.util.Optional
                    //methodName:void <init>(java.lang.Object)
                    calledMethodList.add(Method.initMethod(className, methodName));
                } else if (methodName.contains(" <clinit>")) {
                    continue;
                } else {
                    calledMethodList.add(new Method(className, methodName));
                }
            }
        }

        //对calledMethodList进行排序，简化下阶段的比对
        Collections.sort(calledMethodList, new Comparator<Method>() {

            @Override
            public int compare(Method m1, Method m2) {
                return (m1.getClassName() + m1.getMethodName()).compareTo(m2.getClassName() + m2.getMethodName());
            }
        });

        /**
         * 遍历calledMethodList,对每个方法通过查询反编译代码的方法获取其方法body和hash
         */

        return calledMethodList;

        // SootFileUtils.toFile(outputPath.substring(0, outputPath.length() - 4) + "/" + jarName + "_dot.dot", callGraphVisitor.getDot());
    }

    /**
     * 比对两个版本的方法是否相同
     * <p>
     * 比较方法：
     * 1. 首先比较方法列表的数量，数量不同，说明v1 v2发生了变化
     * 2. 如果数量相同，比较方法列表每一个item的内容，如果不同，说明v1 v2发生了变化
     * 3. 如果每个item内容（方法名）都相同，则需要比较对应方法的hash值
     *
     * @param preMethodList
     * @param currMethodList
     * @param preJarPath
     * @param currJarPath
     * @return
     */
    private static boolean sameTwoVersionsMethodList(List<Method> preMethodList, List<Method> currMethodList, String preJarPath, String currJarPath) {

        boolean same = true;

        //1
        int preSize = preMethodList.size();
        int currSize = currMethodList.size();
        if (preSize != currSize) {
            return false;
        }

        //2
        for (int index = 0; index < preSize; index++) {
            if (!preMethodList.get(index).equals(currMethodList.get(index))) {
                return false;
            }
        }

        //3.1 首先反编译
        String preJarOutputPath = JavaMethodUtil.decompileJar(preJarPath, DECOMPILE_OUTPUT_PATH);
        String currJarOutputPath = JavaMethodUtil.decompileJar(currJarPath, DECOMPILE_OUTPUT_PATH);

        //3.2 反编译后得到java文件，将java文件读入inputstream，交给CompilationUnit分析
        List<Method> preMethodHashList = new ArrayList<>();
        List<Method> currMethodHashList = new ArrayList<>();
        for (int index = 0; index < preSize; index++) {
            Method m1 = preMethodList.get(index);
            Method m2 = currMethodList.get(index);
            //对于一个Method
            //eg1:<org.openjdk.jmh.util.Utils: void check(java.lang.Class,java.lang.String)>
            //eg2:<java.lang.StringBuilder: void <init>()>
            //className: org.openjdk.jmh.util.Utils
            //methodName: void check(java.lang.Class,java.lang.String)
            String preJavaPath = preJarOutputPath + "/" + m1.getClassName().replaceAll("\\.", "/") + ".java";
            String currJavaPath = currJarOutputPath + "/" + m1.getClassName().replaceAll("\\.", "/") + ".java";

            if (!new File(preJavaPath).exists()) {
                return false;
            }
            System.out.println(preJavaPath);
            System.out.println(currJavaPath);
            CompilationUnit preUnit = JavaMethodUtil.getCompilationUnit(preJavaPath);
            CompilationUnit currUnit = JavaMethodUtil.getCompilationUnit(currJavaPath);

            //接下来从两个unit中找到我们需要比对的方法，
            TypeDeclaration preType = (TypeDeclaration) preUnit.types().get(0);
            TypeDeclaration currType = (TypeDeclaration) currUnit.types().get(0);
            List<BodyDeclaration> preBodyDeclarationList = preType.bodyDeclarations();
            List<BodyDeclaration> currBodyDeclarationList = currType.bodyDeclarations();
            initMethodList(preMethodHashList, m1, preBodyDeclarationList);
            initMethodList(currMethodHashList, m2, currBodyDeclarationList);

            if (preMethodHashList.contains(null) || currMethodHashList.contains(null)) {
                return false;
            }

        }
        //两个jar包的某个方法所有相关方法都已存在preMethodHashList和currMethodList中，比较像对应方法的hash值
        int size = preMethodHashList.size();
        for (int index = 0; index < size; index++) {
            Method preMethod = preMethodHashList.get(index);
            Method currMethod = currMethodHashList.get(index);

            if (preMethod == null || currMethod == null) {
                return false;
            }

            if (preMethod.getBodyHashCode() != currMethod.getBodyHashCode()) {
                return false;
            }
        }
        return true;
    }

    private static void initMethodList(List<Method> preMethodHashList, Method m1, List<BodyDeclaration> preBodyDeclarationList) {
        boolean preFlag = false;//用flag标志是否找到该方法
        int i = 0;
        for (BodyDeclaration bodyDeclaration : preBodyDeclarationList) {
            if (bodyDeclaration instanceof MethodDeclaration) {
                Method tempMethod = new Method((MethodDeclaration) bodyDeclaration);
                if (i==24) {
                    int a = 1;
                }
                //判别是否是m1对应的方法
                if (m1.isSameWithMethodDeclaration(tempMethod)) {
                    //tempMethod就是找到的方法
                    preMethodHashList.add(tempMethod);
                    preFlag = true;
                    break;
                }
            }
            i++;
        }
        //如果没有找到该方法，添加一个null占位
        if (!preFlag) {
            preMethodHashList.add(null);
            System.out.println("Lost Method:==");
            System.out.println(m1.getMethodName());
            System.out.println("End==");
        }
    }

    private static void enableSpark() {
        HashMap opt = new HashMap();
        opt.put("verbose", "true");
        opt.put("propagator", "worklist");
        opt.put("simple-edges-bidirectional", "false");
        opt.put("on-fly-cg", "true");
        opt.put("apponly", "true");
        opt.put("set-impl", "double");
        opt.put("double-set-old", "hybrid");
        opt.put("double-set-new", "hybrid");
        SparkTransformer.v().transform("", opt);
    }

}
