package cn.edu.fudan.se.cfg;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;
import org.apache.commons.io.IOUtils;
import soot.util.dot.DotGraph;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by huangkaifeng on 2018/9/17.
 */
public class SootFileUtils {

    public static void toFile(String dotPath, DotGraph dg) {
        File file = new File(dotPath);
        OutputStream out;
        try {
            out = new FileOutputStream(file);
            dg.render(out, 0);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static JSONObject fromJsonText(String filePath) {
        String jsonTxt = null;
        try {
            InputStream is = new FileInputStream(filePath);
//                SootInvoker.class.getResourceAsStream(filePath);
            jsonTxt = IOUtils.toString(is);
        } catch (IOException e) {
            e.printStackTrace();
        }
        JSONObject json = (JSONObject) JSONSerializer.toJSON(jsonTxt);
        return json;
    }

    public static Map<String, List<String>> getClassNameAndMethodNames(JSONArray methodNames, List<String> classNames) {
        classNames.clear();
        Map<String, List<String>> mMap = new HashMap<>();
        for (Object jo : methodNames) {
            String s = (String) jo;
            int index2 = s.indexOf('(');
            String subS = s.substring(0, index2);
            int index = subS.lastIndexOf('.');
            String className = s.substring(0, index);
            String methodName = s.substring(0, index2);
            String params = s.substring(index2);
            if (!classNames.contains(className)) {
                classNames.add(className);
            }
            String keyMethodParams = methodName + "---" + params;
            if (mMap.containsKey(className)) {
                if (!mMap.get(className).contains(keyMethodParams)) {
                    mMap.get(className).add(keyMethodParams);
                }
            } else {
                List<String> a = new ArrayList<>();
                mMap.put(className, a);
                mMap.get(className).add(keyMethodParams);
            }

        }
        return mMap;

    }

    public static Map<String, List<String>> getClassNameAndMethodNames(String methodNameString, List<String> classNames) {
        classNames.clear();
        Map<String, List<String>> mMap = new HashMap<>();

        String s = methodNameString;
        int index2 = s.indexOf('(');
        String subS = s.substring(0, index2);
        int index = subS.lastIndexOf('.');
        String className = s.substring(0, index);
        String methodName = s.substring(0, index2);
        String params = s.substring(index2);
        initClassNames(classNames, className);

        for (String tempClassName : classNames) {
            String keyMethodParams = methodName + "---" + params;
            if (mMap.containsKey(tempClassName)) {
                if (!mMap.get(tempClassName).contains(keyMethodParams)) {
                    mMap.get(tempClassName).add(keyMethodParams);
                }
            } else {
                List<String> a = new ArrayList();
                mMap.put(tempClassName, a);
                mMap.get(tempClassName).add(keyMethodParams);
            }
        }


        return mMap;

    }

    private static void initClassNames(List<String> classNames, String className) {
        //将可能的类名加入classNames中
        classNames.add(className);
        while (true) {
            int index = className.lastIndexOf(".");
            if (index == -1) {
                break;
            }
            StringBuilder classNameSb = new StringBuilder(className);
            classNameSb.replace(index, index + 1, "$");
            classNames.add(classNameSb.toString());
            className = classNameSb.toString();
        }

    }

    public static List<String> toParamList(String params) {
        String sub = params.substring(1, params.length() - 1);
        List<String> paramsList = new ArrayList<>();
        if (sub.isEmpty()) {
            return paramsList;
        }
        String[] res = sub.split(",");
        for (String item : res) {
            if (item.endsWith("...")) {
                item = item.substring(0, item.length() - 3) + "[]";
            }
            item = item.trim();
            paramsList.add(item);
        }
        return paramsList;
    }
}
