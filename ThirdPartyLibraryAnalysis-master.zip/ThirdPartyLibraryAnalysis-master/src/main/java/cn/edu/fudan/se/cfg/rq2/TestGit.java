package cn.edu.fudan.se.cfg.rq2;

import cn.edu.fudan.se.cfg.rq2.bean.CommitInfo;
import cn.edu.fudan.se.cfg.rq2.utils.GitUtil;

import java.util.List;

public class TestGit {
    public static void main(String[] args) {
        GitUtil gitUtil = new GitUtil();
        gitUtil.buildRepository("I:\\projects\\0Chencc__fdse__CTFCrackTools\\.git", -1);
        gitUtil.walkRepository("I:\\projects\\0Chencc__fdse__CTFCrackTools");
        List<CommitInfo> commitInfoList = gitUtil.getIssueCommitIdList();
        int a = 1;
    }
}
