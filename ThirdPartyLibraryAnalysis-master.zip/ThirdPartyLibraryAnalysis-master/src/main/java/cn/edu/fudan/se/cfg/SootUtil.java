package cn.edu.fudan.se.cfg;

import soot.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by huangkaifeng on 2018/9/17.
 */
public class SootUtil {

    public static SootMethod getMethodByNameAndParams(SootClass sootClass, String methodName, List<String> params) {
        Iterator<SootMethod> iter = sootClass.methodIterator();
        while (iter.hasNext()) {
            SootMethod sootMethod = iter.next();

            String temp = sootMethod.getName();
            if (methodName.equals(temp)) {
                List paramTypes = sootMethod.getParameterTypes();
                if (paramTypes.size() == params.size()) {
                    boolean flag = false;
                    for (int i = 0; i < params.size(); i++) {
                        String item = params.get(i);
                        Type param = (Type) paramTypes.get(i);
                        String sType = param.toString();
//                        if(sType.startsWith("java.lang.")){
//                            sType = sType.substring(10);
//                        }
                        if (!sType.equals(item)) {
                            flag = true;
                            break;
                        }
                    }
                    if (!flag) {
                        return sootMethod;
                    }
                }
            }
        }
        //System.out.println("Method can't be found:" + methodName);
        return null;
    }

    public static List<SootMethod> loadEntryPoints(List<String> classNames, Map<String, List<String>> mmap) {
        List<SootMethod> entryPoints = new ArrayList();
        for (String clazzName : classNames) {
            List<String> methods = mmap.get(clazzName);
//            SootClass sootClass = Scene.v().forceResolve(clazzName, SootClass.BODIES);
            SootClass sootClass = Scene.v().loadClassAndSupport(clazzName);
            sootClass.setApplicationClass();
            Scene.v().loadNecessaryClasses();
            for (String methodKey : methods) {
                try {
                    String[] keys = methodKey.split("---");
                    String methodName = keys[0].substring(clazzName.length() + 1);
                    String params = keys[1];
                    List<String> paramList = SootFileUtils.toParamList(params);
                    String[] clazzNames = clazzName.split("\\.");
                    int size = clazzNames.length;
                    //构造函数
                    if (clazzNames[size - 1].equals(methodName)) {
                        methodName = "<init>";
                    }
                    SootMethod sootMethod = SootUtil.getMethodByNameAndParams(sootClass, methodName, paramList);
                    if (sootMethod != null) {
                        entryPoints.add(sootMethod);
                        return entryPoints;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }
        return entryPoints;
    }
}
