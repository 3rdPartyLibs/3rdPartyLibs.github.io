package cn.edu.fudan.se.cfg;

import soot.PackManager;
import soot.Scene;
import soot.SootClass;
import soot.SootMethod;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.options.Options;

import java.util.*;

/**
 * Created by huangkaifeng on 2018/9/13.
 */
public class SootInvoker2 {
    public static String processDir = "C:\\Users\\huangkaifeng\\Desktop\\RQ2\\jmh-core-1.17.4_unzip";

    public static void main(String args[]){
        System.out.println("start ...");
        soot.G.reset();
        List<String> argsList = new ArrayList<>(Arrays.asList(args));
        argsList.addAll(Arrays.asList(new String[] { "-allow-phantom-refs", "-w",
                // "-no-bodies-for-excluded",
                "-cp", processDir, "-process-dir",
                processDir }));
        args = argsList.toArray(new String[0]);
        Options.v().parse(args);
        Options.v().set_src_prec(Options.src_prec_java);
//        Options.v().set_process_dir(Collections.singletonList(processDir));
        Options.v().set_whole_program(true);
        Options.v().set_allow_phantom_refs(true);
        Options.v().set_output_format(Options.output_format_none);
        Options.v().setPhaseOption("cg.spark", "on");
        Options.v().set_no_bodies_for_excluded(true);
//        Options.v().set_app(true);
        enableSpark();
        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
        SootClass c = loadClass("org.openjdk.jmh.runner.options.ChainedOptionsBuilder",false);
//        SootMethod entryPoint = app.getEntryPointCreator().createDummyMain();
//        Options.v().set_main_class(entryPoint.getSignature());
//        Scene.v().setEntryPoints(Collections.singletonList(entryPoint));
//        System.out.println(entryPoint.getActiveBody());
//        loadClass("Container",false);
//        SootClass c = loadClass(mainClass,true);

        PackManager.v().runPacks();
        CallGraph callGraph = Scene.v().getCallGraph();
    }
    private static SootClass loadClass(String name, boolean main) {
        SootClass c = Scene.v().loadClassAndSupport(name);
        c.setApplicationClass();
        if (main)
            Scene.v().setMainClass(c);
        return c;
    }


    private static void enableSpark(){
        HashMap opt = new HashMap();
        opt.put("verbose","true");
        opt.put("propagator","worklist");
        opt.put("simple-edges-bidirectional","false");
        opt.put("on-fly-cg","true");
        opt.put("apponly", "true");
        opt.put("set-impl","double");
        opt.put("double-set-old","hybrid");
        opt.put("double-set-new","hybrid");
        SparkTransformer.v().transform("",opt);
    }
}

