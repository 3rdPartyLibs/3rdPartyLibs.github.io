package cn.edu.fudan.se.cfg.rq1.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * 排序结果
 */
public class SortResult {

    int start;
    int end;
    int size;

    List<DependencyLib> dependencyLibs;

    public SortResult() {
    }

    public SortResult(int start, int end) {
        this.start = start;
        this.end = end;
        dependencyLibs = new ArrayList<>();
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getStart() {

        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getEnd() {
        return end;
    }

    public void setEnd(int end) {
        this.end = end;
    }

    public List<DependencyLib> getDependencyLibs() {
        return dependencyLibs;
    }

    public void setDependencyLibs(List<DependencyLib> dependencyLibs) {
        this.dependencyLibs = dependencyLibs;
    }
}
