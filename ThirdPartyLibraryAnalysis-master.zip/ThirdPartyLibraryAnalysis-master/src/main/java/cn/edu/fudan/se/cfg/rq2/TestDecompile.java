package cn.edu.fudan.se.cfg.rq2;

import cn.edu.fudan.se.util.JavaMethodUtil;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import java.util.List;

import static cn.edu.fudan.se.cfg.rq2.MethodDiff2.DECOMPILE_OUTPUT_PATH;

public class TestDecompile {
    public static void main(String[] args) {
        //3.1 首先反编译
        String preJarPath = "D:\\cs\\jar\\jar\\TestJar14.jar";
        String currJarPath = "D:\\cs\\jar\\jar\\TestJar14.jar";
        ///String currJarPath = "";

        String preJarOutputPath = JavaMethodUtil.decompileJar(preJarPath, DECOMPILE_OUTPUT_PATH);
        String currJarOutputPath = JavaMethodUtil.decompileJar(currJarPath, DECOMPILE_OUTPUT_PATH);
        //String currJarOutputPath = JavaMethodUtil.decompileJar(currJarPath, DECOMPILE_OUTPUT_PATH);

        String preJavaPath = preJarOutputPath + "/" + "com/basti/Food.java";
        String currJavaPath = preJarOutputPath + "/" + "com/basti/Food.java";
        CompilationUnit preUnit = JavaMethodUtil.getCompilationUnit(preJavaPath);
        CompilationUnit currUnit = JavaMethodUtil.getCompilationUnit(currJavaPath);
        TypeDeclaration preType = (TypeDeclaration) preUnit.types().get(0);
        TypeDeclaration currType = (TypeDeclaration) currUnit.types().get(0);
        List<BodyDeclaration> preBodyDeclarationList = preType.bodyDeclarations();
        List<BodyDeclaration> currBodyDeclarationList = currType.bodyDeclarations();
        int a = 1;
    }
}
