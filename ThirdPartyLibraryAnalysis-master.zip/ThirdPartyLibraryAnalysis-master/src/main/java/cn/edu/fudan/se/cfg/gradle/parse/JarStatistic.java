package cn.edu.fudan.se.cfg.gradle.parse;

import cn.edu.fudan.se.cfg.gradle.parse.bean.LibObj;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.util.*;

public class JarStatistic {
    //统计一共有多少个jar需要爬取
    //static final String LIB_FILE_NAME = "F:/gradle_maven_merge.json";
    static final String LIB_FILE_NAME = "F:/mergeLib.json";
    static final String LIB_ALL_FILE_NAME = "F:/lib_all.json";

    public static void main(String[] args) {
        String content = FileUtil.read(LIB_FILE_NAME);
        List<LibObj> libObjList = new Gson().fromJson(content, new TypeToken<List<LibObj>>() {
        }.getType());

        //15w个jar包list
        String libAllContent = FileUtil.read(LIB_ALL_FILE_NAME);
        List<String> libAllList = new Gson().fromJson(libAllContent, new TypeToken<List<String>>() {
        }.getType());

        Map<String, LibObj> libMap = new HashMap<>();
        LibObj newLibObj;
        int groupIdCount = 0;
        int totalJarCount = 0;
        for (LibObj libObj : libObjList) {
            String lib_name = libObj.getLib_name();
            String[] tempName = lib_name.split(" ");
            if (tempName.length < 2) {
                continue;
            }
            String groupId = tempName[0];
            String artifactId = tempName[1];
            Set<String> versionSet = libObj.getVersions_array();
            groupIdCount++;
            for (String version : versionSet) {
                String tempVersion = version.replace(" ", ".");
                String key1 = artifactId + "-" + tempVersion;
                String key2 = groupId.replaceAll("\\.", "-") + "-" + artifactId + "-" + tempVersion;
                if (libAllList.contains(key1)) {
                    System.out.println(key1);
                    continue;
                }
                if (libAllList.contains(key2)) {
                    System.out.println(key2);
                    continue;
                }

                if (!libMap.containsKey(lib_name)) {
                    newLibObj = new LibObj(lib_name);
                    newLibObj.setRepo_array(libObj.getRepo_array());
                    newLibObj.getVersions_array().add(version);
                    libMap.put(lib_name, newLibObj);
                } else {
                    libMap.get(lib_name).getVersions_array().add(version);
                }
                totalJarCount++;
            }
        }
        System.out.println(String.valueOf(groupIdCount) + " " + String.valueOf(totalJarCount));

        FileUtil.writeFlie("F:/needDownloadGradleJar_temp.json", new GsonBuilder().setPrettyPrinting().create().toJson(libMap));

        List<LibObj> resultList = new ArrayList<>();
        Iterator iter = libMap.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            LibObj val = (LibObj) entry.getValue();
            resultList.add(val);
        }
        FileUtil.writeFlie("F://needDownloadGradleJar.json", new GsonBuilder().setPrettyPrinting().create().toJson(resultList));
    }
}
