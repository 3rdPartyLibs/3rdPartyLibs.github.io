package cn.edu.fudan.se.cfg.rq2.utils;

import cn.edu.fudan.se.util.JavaMethodUtil;
import org.eclipse.jdt.core.dom.*;
import soot.SootMethod;

import java.util.*;

public class JavaCallGraphJDTAdapter {

    public MethodDeclaration getJDTMethodByString(String method, String jarPath) {
        List<BodyDeclaration> bodyDeclarationList = JDTUtils.getCompilationUnitByJar(jarPath, method.replaceAll("\\.", "/"));
        MethodDeclaration bodyBodyDeclaration = searchMethod(method, bodyDeclarationList);

        return bodyBodyDeclaration;
    }

    public static MethodDeclaration searchMethod(String method, List<BodyDeclaration> bodyDeclarationList) {

        //比较方法名、返回值、参数列表，如果比较成功则返回，否则返回null
        for (BodyDeclaration bodyDeclaration : bodyDeclarationList) {
            if (bodyDeclaration instanceof MethodDeclaration) {
                //如果不是构造函数，需要比较名字
                if (!method.contains("<init>") || !((MethodDeclaration) bodyDeclaration).isConstructor()) {
                    String jdtMethodName = ((MethodDeclaration) bodyDeclaration).getName().toString();
                    if (!JavaMethodUtil.getMethodName(method).equals(jdtMethodName)) {
                        continue;
                    }
                }
                Map<String, String> typeMap = handleTypeParameters(bodyDeclaration);
                /*String sootReturnTypeStr = sootMethod.getReturnType().toString();
                Type jdtReturnType = ((MethodDeclaration) bodyDeclaration).getReturnType2();
                String jdtReturnTypeStr = handleJDTType(jdtReturnType, typeMap);
                boolean returnTypeEquals = typeEquals(sootReturnTypeStr, jdtReturnTypeStr);
                if (!returnTypeEquals) {
                    continue;
                }*/

                //List<soot.Type> sootParams = sootMethod.getParameterTypes();
                List<String> callGraphParams = generateCallGraphParams(method);
                List<Type> jdtParams = ((MethodDeclaration) bodyDeclaration).parameters();
                boolean paramsSame = paramListEquals(callGraphParams, jdtParams, typeMap);
                if (paramsSame) {
                    return (MethodDeclaration) bodyDeclaration;
                }
            }
        }
        return null;
    }

    private static List<String> generateCallGraphParams(String method) {

        int startIndex = method.indexOf("(");
        int endIndex = method.indexOf(")");
        String paramsString = method.substring(startIndex + 1, endIndex);
        String[] params = paramsString.split(",");
        if (params[0].equals("")){
            return Arrays.asList(new String[0]);
        }
        return Arrays.asList(params);
    }


    //处理泛型参数
    private static Map<String, String> handleTypeParameters(BodyDeclaration bodyDeclaration) {
        Map<String, String> typeMap = new HashMap<>();
        List<TypeParameter> typeParameters = ((MethodDeclaration) bodyDeclaration).typeParameters();
        TypeDeclaration parent = (TypeDeclaration) bodyDeclaration.getParent();
        //parent.typeParameters();
        //typeParameters.addAll(((TypeDeclaration) bodyDeclaration.getParent()).typeParameters());
        List<TypeParameter> parentTypeParameters = parent.typeParameters();
        parentTypeParameters.addAll(typeParameters);
        for (TypeParameter typeParameter : parentTypeParameters) {
            String[] types = typeParameter.toString().trim().split(" ");
            if (types.length == 3) {
                typeMap.put(types[0], types[2]);
            }
        }
        return typeMap;
    }

    /**
     * 对JDT的类型做一些特殊处理
     *
     * @param jdtReturnType
     * @param typeMap
     * @return
     */
    private static String handleJDTType(ASTNode jdtReturnType, Map<String, String> typeMap) {
        String jdtReturnTypeStr = jdtReturnType == null ? "void" : jdtReturnType.toString();

        if (typeMap.containsKey(jdtReturnTypeStr)) {
            jdtReturnTypeStr = typeMap.get(jdtReturnTypeStr);
        }
        return jdtReturnTypeStr;
    }

    //参数列表是否相同
    private static boolean paramListEquals(List<String> callGraphParamList, List<Type> jdtParams, Map<String, String> typeMap) {
        int sootSize = callGraphParamList.size();
        int jdtSize = jdtParams.size();
        if (sootSize != jdtSize) {
            return false;
        }

        for (int index = 0; index < sootSize; index++) {
            String javaCgType = callGraphParamList.get(index);
            ASTNode jdtType = jdtParams.get(index);
            String jdtTypeStr = handleJDTType(jdtType, typeMap);
            boolean same = typeEquals(javaCgType, jdtTypeStr.split(" ")[0]);
            if (!same) {
                return false;
            }
        }
        return true;
    }

    //类型是否相同
    private static boolean typeEquals(String sootType, String jdtType) {
        //sootType : java.lang.String
        //jdtType : String || java.lang.String ||String ...||Map<String,String>
        if (jdtType.contains("...")) {
            jdtType = jdtType.replace("...", "[]").trim();
        }
        if (jdtType.contains("<")) {
            int startIndex = jdtType.indexOf("<");
            //int endIndex = jdtType.indexOf(">");
            jdtType = jdtType.substring(0, startIndex);
        }
        String[] sootReturnTypes = sootType.split("\\.");
        int sootReturnTypeSize = sootReturnTypes.length;
        if (!sootType.equals(jdtType) && !sootReturnTypes[sootReturnTypeSize - 1].equals(jdtType)) {
            return false;
        }
        return true;
    }

}
