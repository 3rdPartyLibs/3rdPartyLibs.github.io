package cn.edu.fudan.se.cfg.rq3;

import cn.edu.fudan.se.cfg.rq2.utils.SootUtils;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import gr.gousiosg.javacg.stat.InvokeUtils4;
import soot.SootMethod;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class API2List {
    static final String JAR_FILE_DIR = "D:/wangying/rq3/api_call_rq3_proj_filtered2/";//源文件dir
    static final String LIB_DIR = "H:/wangying/lib_all/";//jar包dir
    static final String LIB_UNZIP_DIR = "D:/wangying/rq3/lib_unzip/";//jar包解压dir
    static final String OUTPUT_DIR = "D:/wangying/rq3/lib_api_callgraph_output2/";//输出结果dir

//    static final String JAR_FILE_DIR = "D:/wangying/rq3/test_api_call_rq3_proj_filtered/";//源文件dir
//    static final String LIB_DIR = "D:/wangying/rq3/test_lib_all/";//jar包dir
//    static final String LIB_UNZIP_DIR = "D:/wangying/rq3/test_lib_unzip/";//jar包解压dir
//    static final String OUTPUT_DIR = "D:/wangying/rq3/test_lib_api_callgraph_output/";//输出结果dir

    public static void main(String[] args) {
        File[] fileList = new File(JAR_FILE_DIR).listFiles();

        for (File jarMetaFile : fileList) {
            String content = FileUtil.read(jarMetaFile.getAbsolutePath());
            Gson gson = new Gson();
            Map<String, Map<String, Integer>> contentMap = new HashMap<>();
            contentMap = gson.fromJson(content, contentMap.getClass());
            Map<String, Map<String, Map<String,List<String>>>> resultMap = new HashMap<>();
            //遍历project中的jar
            for (Map.Entry<String, Map<String, Integer>> jarEntry : contentMap.entrySet()) {

                String jarName = jarEntry.getKey();
                Map<String, Integer> methodFieldMap = jarEntry.getValue();
                //String jarUnzipPath = FileUtil.unzipJar(LIB_UNZIP_DIR, LIB_DIR + jarName, jarName);
                for (Map.Entry<String, Integer> methodFieldEntry : methodFieldMap.entrySet()) {
                    String methodFieldName = methodFieldEntry.getKey();
                    try {
                        Map<String, List<String>> invokeMap = InvokeUtils4.getInvokeMethodByMethodName(jarName, LIB_DIR + jarName, methodFieldName);
                        if (!resultMap.containsKey(jarName)) {
                            resultMap.put(jarName, new HashMap<>());
                        }
                        resultMap.get(jarName).put(methodFieldName, invokeMap);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            FileUtil.writeFlie(OUTPUT_DIR + jarMetaFile.getName(), new Gson().toJson(resultMap));
        }
    }

    /**
     * @param methodFieldName 需要调查的方法名
     * @param jarName         jar包名字 xxx.jar
     * @param unzipPath       jar包解压包路径 xxx/xxx/xxx_unzip
     */
    private static List<String> apiToList(String methodFieldName, String jarName, String unzipPath) throws Exception {
        if (methodFieldName.contains("(")) {
            //包含括号的视为方法
            List<SootMethod> preMethods = SootUtils.convertStringToSootMethod(new String[0], jarName, unzipPath, methodFieldName, "");
            if (preMethods == null || preMethods.size() == 0) {
                throw new Exception(jarName + " " + methodFieldName + " not found!");
            }
            return SootUtils.getInvokeMethodList(new String[0], "", unzipPath, methodFieldName, "", preMethods);
        }
        return null;
    }
}
