package cn.edu.fudan.se.cfg.rq1;

import java.util.ArrayList;
import java.util.List;

public class TestSubString {
    public static void main(String[] args) {
        List<String> a = new ArrayList<>();
        a.add("abc");
        a.add("bcd");
        a.add("cde");
        a.add("def");

        for (String s : a){
            s = "a";
        }

        for (String s:a){
            System.out.println(s);
        }
    }
}
