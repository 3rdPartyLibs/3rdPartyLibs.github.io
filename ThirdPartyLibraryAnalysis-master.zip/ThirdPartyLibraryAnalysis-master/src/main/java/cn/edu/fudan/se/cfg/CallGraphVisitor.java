package cn.edu.fudan.se.cfg;

import soot.MethodOrMethodContext;
import soot.SootMethod;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Targets;
import soot.util.dot.DotGraph;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by huangkaifeng on 2018/9/17.
 */
public class CallGraphVisitor {

    public CallGraphVisitor(String dotPath){
        this.dot = new DotGraph(dotPath);
        this.visited = new HashMap<>();
    }

    private Map<String,Boolean> visited;
    private DotGraph dot;


    public DotGraph getDot() {
        return dot;
    }

    public void visit(CallGraph cg, SootMethod method) {
        String identifier = method.getSignature();
        visited.put(method.getSignature(), true);
        dot.drawNode(identifier);
        // iterate over unvisited parents
        Iterator<MethodOrMethodContext> ptargets = new Targets(cg.edgesInto(method));
        if (ptargets != null) {
            while (ptargets.hasNext()) {
                SootMethod parent = (SootMethod) ptargets.next();
                if (!visited.containsKey(parent.getSignature())) visit(cg, parent);
            }
        }
        // iterate over unvisited children
        Iterator<MethodOrMethodContext> ctargets = new Targets(cg.edgesOutOf(method));
        if (ctargets != null) {
            while (ctargets.hasNext()) {
                SootMethod child = (SootMethod) ctargets.next();
                dot.drawEdge(identifier, child.getSignature());
                System.out.println(method + " may call " + child);
                if (!visited.containsKey(child.getSignature())) visit(cg, child);
            }
        }
    }
}
