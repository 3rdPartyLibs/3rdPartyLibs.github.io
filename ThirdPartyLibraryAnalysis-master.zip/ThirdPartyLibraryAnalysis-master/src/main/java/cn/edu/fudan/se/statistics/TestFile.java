package cn.edu.fudan.se.statistics;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.edu.fudan.se.cmd.ExecuteCmd;
import cn.edu.fudan.se.util.FastJsonUtil;
import cn.edu.fudan.se.util.FileUtil;
import cn.edu.fudan.se.util.JsonFileUtil;

public class TestFile {
	
	public static void getFileList(List<File> fileList,String dir){
    	File or = new File(dir);
		File[] files = or.listFiles();
		if (files != null) {
			for (File file : files) {
				if (file.isFile() && file.getName().endsWith(".java")) {
					fileList.add(file);
				}else if (file.isDirectory()) {
					getFileList(fileList,file.getAbsolutePath());
				}
			}
		}
    }

	public static void getFilePath() {
		Map<Integer,Map> result = new HashMap<>();
		String content = JsonFileUtil.readJsonFile("proj_in_usage.txt");
		JSONArray array = JSONArray.parseArray(content);
		System.out.println(array.size());
//		for(int i =0;i<array.size();i++) {
//			JSONObject obj = array.getJSONObject(i);
//			int projectId = obj.getInteger("id");
//			String localAddr = obj.getString("local_addr");
//			if(localAddr.startsWith("F:/wangying/projects_last_unzips/"))
//				localAddr = "C:/"+localAddr.replace("F:/wangying/projects_last_unzips/","");
//			
////			localAddr = PROJECT_DIR + localAddr.replace("F:/wangying/projects_last_unzips/","").replace("C:/","").replace("D:/","").replace("E:/","").replace("F:/","");
//		
//			
//			if(new File(localAddr).exists()) {
//				System.out.println(projectId + " " + localAddr);
//				Map<Integer,String> map = new HashMap<>();
//				List<File> fileList = new ArrayList<File>();
//				getFileList(fileList, localAddr +"/");
//				System.out.println(fileList.size());
//				
//				for (int f = 0; f < fileList.size(); f++) {					
//					String path = fileList.get(f).getAbsolutePath().replace("C:\\", "").replace("D:\\", "")
//							.replace("E:\\", "").replace("F:\\", "").replace("gradle_maven200_500\\", "").replace("gradle_maven500\\", "").replace("maven200_500\\", "").replace("maven500\\", "").replace("gradle200_500\\", "").replace("gradle500\\", "");
//					System.out.println(f + " " + path);
//					map.put(f, path);
//				}
//				if(map.size() > 0)
//					result.put(projectId, map);
//			}				
//		}
//		Object obj = JSONObject.toJSON(result);
//		FastJsonUtil.writeJsonString("C:/RQ1/filepath.json", obj.toString());
	}
	
	public static void readFilePath() {
		String content = JsonFileUtil.readJsonFile("F:/RQ1/filepath.json");
		Map<Integer,Map<Integer,String>> projs = (Map<Integer, Map<Integer,String>>) JSONObject.parse(content);
		System.out.println(projs.size());
//		for(Map.Entry<Integer, Map<Integer,String>> entry: projs.entrySet()) {
//			int projectId = entry.getKey();
//			if(new File("H:/RQ1/file_path/" + projectId + ".json").exists())
//				continue;
//			Map<Integer,String> map = entry.getValue();
//			Map<String,String> newMap = new HashMap<>();
//			for(Map.Entry<Integer, String> value:map.entrySet()) {
////				System.out.println(entry.getKey() + " " + entry.getValue());
//				newMap.put(""+value.getKey(), value.getValue());
//			}
////			System.out.println(newMap.size());
//			Object obj = JSONObject.toJSON(newMap);
////			System.out.println(obj.toString());
//			FastJsonUtil.writeJsonString("H:/RQ1/file_path/" + projectId + ".json", obj.toString());
//		}
	}
	
	public static void getCommitFilePath(String PROJECT_LIB_OF_COMMIT,String projsPath) {
		String content = JsonFileUtil.readJsonFile(projsPath);
		Map<String,String> projs = (Map<String, String>) JSONObject.parse(content);
		System.out.println(projs.size());
		
		String[] files = new File(PROJECT_LIB_OF_COMMIT).list();
		for(String file:files) {
			int projectId = Integer.parseInt(file.replace(".txt", ""));
			if(projectId == 2594 || projectId == 5502)
				continue;
			String projectPath = "F:/" + projs.get(""+projectId);
			if (new File(projectPath).exists()) {
				System.out.println(projectId + " " + projectPath);
				String whole = JsonFileUtil.readJsonFile(PROJECT_LIB_OF_COMMIT + "/" + file);
				Map<String, Object> libs = JSONObject.parseObject(whole);
				System.out.println(libs.size());
				for (Map.Entry<String, Object> entry : libs.entrySet()) {
					String commitId = entry.getKey();
					if(new File("D:/data/file_path/RQ1/" + projectId + "_" + commitId + ".json").exists())
						continue;
					boolean success = ExecuteCmd.checkout(projectPath, commitId);
					if (success) {
						Map<String,String> map = new HashMap<>();
						List<File> fileList = new ArrayList<File>();
						getFileList(fileList, projectPath + "/");
//						System.out.println(fileList.size());

						for (int f = 0; f < fileList.size(); f ++) {
							String path = fileList.get(f).getAbsolutePath().replace("C:\\", "").replace("D:\\", "")
									.replace("E:\\", "").replace("F:\\", "").replace("gradle_maven200_500\\", "").replace("gradle_maven500\\", "").replace("maven200_500\\", "").replace("maven500\\", "").replace("gradle200_500\\", "").replace("gradle500\\", "");
							System.out.println(f + " " + path);
							map.put(f+"", path);
						}
						Object obj = JSONObject.toJSON(map);
						FastJsonUtil.writeJsonString("D:/data/file_path/RQ1/" + projectId + "_" + commitId + ".json", obj.toString());
					}
				}
			}
		}
	}
	
	public static void getUpdateProjects() {
		Map<Integer,String> projs = new HashMap<>();
		String content = JsonFileUtil.readJsonFile("proj_in_usage.txt");
		JSONArray array = JSONArray.parseArray(content);
		for(int i =0;i<array.size();i++) {
			JSONObject obj = array.getJSONObject(i);
			int projectId = obj.getInteger("id");
			String localAddr = obj.getString("local_addr");
			localAddr = localAddr.replace("F:/wangying/projects_last_unzips/","").replace("D:/", "").replace("E:/", "").replace("F:/", "");
			System.out.println(localAddr);
			projs.put(projectId, localAddr);
		}
//		
//		Object obj = JSONObject.toJSON(projs);
//		FastJsonUtil.writeJsonString("C:/RQ1/update_projs.json", obj.toString());
//		
//		String content = JsonFileUtil.readJsonFile("C:/RQ1/update_projs.json");
//		Map<Integer,String> projs = (Map<Integer, String>) JSONObject.parse(content);
		
		Map<Integer,String> newMap = new HashMap<>();
		String[] files = new File("E:/data/proj_update_lib").list();
		for(String file:files) {
			int project = Integer.parseInt(file.replace(".txt", ""));
			String path = projs.get(project);
			newMap.put(project, path);
		}
		System.out.println(newMap.size());
		System.out.println(newMap.containsKey(1492));
		System.out.println(newMap.containsKey(5422));
		
		Object obj = JSONObject.toJSON(newMap);
		FastJsonUtil.writeJsonString("C:/RQ1/update_projs.json", obj.toString());
	}
	
	public static void toJson(String path) {
		Map<String,String> newMap = new HashMap<>();
		String content = JsonFileUtil.readJsonFile(path);
		Map<Integer,String> json = (Map<Integer, String>) JSONObject.parse(content);
		System.out.println(json.size());
		for(Map.Entry<Integer, String> entry:json.entrySet()) {
//			System.out.println(entry.getKey() + " " + entry.getValue());
			newMap.put(""+entry.getKey(), entry.getValue());
		}
		System.out.println(newMap.size());
		Object obj = JSONObject.toJSON(newMap);
		System.out.println(obj.toString());
		FastJsonUtil.writeJsonString(path, obj.toString());
	}
	
	public static void main(String[] args) {
		getFilePath();
//		getUpdateProjects();
//		getCommitFilePath("D:/data/file_path/proj_update_lib","D:/data/file_path/update_projs.json");
//		readFilePath();
//		File[] files = new File("D:/data/RQ1").listFiles();
//		
//		for(File file:files) {
//			System.out.println(file.getAbsolutePath());
//			toJson(file.getAbsolutePath());
//		}
//		System.out.println(files.length);
//		readFilePath();
//		toJson("D:/data/RQ1/1554_aaeb252fcbb03caa7028747ccda12a71c6d9c722.json");
	}
}
