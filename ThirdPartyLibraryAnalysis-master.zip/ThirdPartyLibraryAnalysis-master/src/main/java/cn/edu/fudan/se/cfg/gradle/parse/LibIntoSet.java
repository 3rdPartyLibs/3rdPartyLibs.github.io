package cn.edu.fudan.se.cfg.gradle.parse;

import cn.edu.fudan.se.cfg.gradle.parse.bean.DependencyUrl;
import cn.edu.fudan.se.cfg.gradle.parse.bean.LibObj;
//import cn.edu.fudan.se.cfg.gradle.parse.bean.Project;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.util.*;

public class LibIntoSet {

   /* static Map<String, LibObj> libMaps;
    static final String LIB_DIR = "F://commit_dependency_output//";

    public static void main(String[] args) {
        libMaps = new HashMap<>();
        File libDir = new File(LIB_DIR);
        File[] files = libDir.listFiles();
        int size = files.length;
        int index = 1;
        for (File file : files) {
            System.out.println(String.valueOf(index) + "/" + String.valueOf(size) + " : " + file.getName());
            String content = FileUtil.read(file.getAbsolutePath());
            Project project = new Gson().fromJson(content, new TypeToken<Project>() {
            }.getType());
            List<DependencyUrl> dependencyUrlList = project.getDependencyUrls();
            for (DependencyUrl dependencyUrl : dependencyUrlList) {
                //"lib_name": "org.apache.camel camel-jetty-common-starter"
                String lib_name = dependencyUrl.getGroupId() + " " + dependencyUrl.getArtifactId();
                String version = dependencyUrl.getVersion();

                if (!libMaps.containsKey(lib_name)) {
                    LibObj libObj = new LibObj(lib_name);
                    libMaps.put(lib_name, libObj);
                }
                libMaps.get(lib_name).getVersions_array().add(version + " jar");
            }
            index++;
        }
        FileUtil.writeFlie("F://mergeLib_temp.json", new GsonBuilder().setPrettyPrinting().create().toJson(libMaps));

        List<LibObj> resultList = new ArrayList<>();
        Iterator iter = libMaps.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            LibObj val = (LibObj) entry.getValue();
            resultList.add(val);
        }
        FileUtil.writeFlie("F://mergeLib.json", new GsonBuilder().setPrettyPrinting().create().toJson(resultList));
    }*/
}
