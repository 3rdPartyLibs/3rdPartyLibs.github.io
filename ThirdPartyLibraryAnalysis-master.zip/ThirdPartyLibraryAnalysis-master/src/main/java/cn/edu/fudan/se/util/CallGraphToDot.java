package cn.edu.fudan.se.util;

import java.io.File;

import soot.MethodOrMethodContext;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;
import soot.util.dot.DotGraph;
import soot.util.queue.QueueReader;

/**
 * callgraph 转成dot文件
 * 
 * @author Thinkpad
 *
 */
public class CallGraphToDot {
	public static void serializeCallGraph(CallGraph graph, String fileName) {
		if (fileName == null) {
			fileName = soot.SourceLocator.v().getOutputDir();
			if (fileName.length() > 0) {
				fileName = fileName + File.separator;
			}
			fileName = fileName + "call-graph" + DotGraph.DOT_EXTENSION;
		}
		System.out.println("writing to file" + fileName);
		DotGraph canvas = new DotGraph("call.graph");
		QueueReader<Edge> listener = graph.listener();
		while (listener.hasNext()) {
			// 一个边
			Edge next = listener.next();
			// 获取这个边的头
			MethodOrMethodContext src = next.getSrc();
			MethodOrMethodContext tgt = next.getTgt();
			String srcString = src.toString();
			String tgtString = tgt.toString();
			System.out.println(srcString + "\t" + tgtString);
			if ((!srcString.startsWith("<java.") && !srcString.startsWith("<sun.") && !srcString.startsWith("<org.")
					&& !srcString.startsWith("<com.") && !srcString.startsWith("<jdk.")
					&& !srcString.startsWith("<javax."))
					|| (!tgtString.startsWith("<java.") && !tgtString.startsWith("<sun.")
							&& !tgtString.startsWith("<org.") && !tgtString.startsWith("<com.")
							&& !tgtString.startsWith("<jdk.") && !tgtString.startsWith("<javax."))) {
				canvas.drawNode(srcString);
				canvas.drawNode(tgtString);
				canvas.drawEdge(srcString, tgtString);
			}
		}
		canvas.plot(fileName);

	}
}
