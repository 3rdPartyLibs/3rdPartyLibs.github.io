package cn.edu.fudan.se.cfg.gradle.parse.bean;

public class ProjectSearchResult {

    boolean find;
    String projectName;
    String projectPath;
    String type;

    public ProjectSearchResult() {
    }

    public ProjectSearchResult(boolean find, String projectName, String projectPath, String type) {

        this.find = find;
        this.projectName = projectName;
        this.projectPath = projectPath;
        this.type = type;
    }

    public boolean isFind() {

        return find;
    }

    public void setFind(boolean find) {
        this.find = find;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectPath() {
        return projectPath;
    }

    public void setProjectPath(String projectPath) {
        this.projectPath = projectPath;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
