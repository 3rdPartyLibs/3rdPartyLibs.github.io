package cn.edu.fudan.se.cfg.rq1;

public class ModifierUtils {

    public static boolean isAbstract(int m) {
        return (m & 1024) != 0;
    }

    public static boolean isInterface(int m) {
        return (m & 512) != 0;
    }

    public static boolean isNative(int m) {
        return (m & 256) != 0;
    }

    public static boolean isPrivate(int m) {
        return (m & 2) != 0;
    }

    public static boolean isProtected(int m) {
        return (m & 4) != 0;
    }

    public static boolean isPublic(int m) {
        return (m & 1) != 0;
    }

    public static boolean isStatic(int m) {
        return (m & 8) != 0;
    }

    public static boolean isSynchronized(int m) {
        return (m & 32) != 0;
    }

    public static boolean isTransient(int m) {
        return (m & 128) != 0;
    }

    public static boolean isVolatile(int m) {
        return (m & 64) != 0;
    }

    public static boolean isStrictFP(int m) {
        return (m & 2048) != 0;
    }

    public static boolean isAnnotation(int m) {
        return (m & 8192) != 0;
    }

    public static boolean isEnum(int m) {
        return (m & 16384) != 0;
    }

    public static boolean isSynthetic(int m) {
        return (m & 4096) != 0;
    }

    public static boolean isConstructor(int m) {
        return (m & 65536) != 0;
    }

    public static boolean isDeclaredSynchronized(int m) {
        return (m & 131072) != 0;
    }

}
