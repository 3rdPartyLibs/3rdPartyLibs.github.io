package cn.edu.fudan.se.git;

import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.util.*;

public class IssueUtil {

    private static List<ProjectVersion> readIssues(String path) {
        String content = FileUtil.read(path);

        JsonObject contentJson = new Gson().fromJson(content, JsonObject.class);

        List<ProjectVersion> projectVersionList = new ArrayList<>();

        for (Map.Entry<String, JsonElement> set : contentJson.entrySet()) {
            if (set.getValue().toString().startsWith("{")) {
                ProjectVersion projectVersion = new Gson().fromJson(set.getValue(), new TypeToken<ProjectVersion>() {
                }.getType());
                projectVersion.setName(set.getKey());
                projectVersionList.add(projectVersion);
            }
        }

        return projectVersionList;
    }

    private static List<IssueCommitId> readIssueCommitIds(String path) {
        String content = FileUtil.read(path);

        List<IssueCommitId> issueCommitIdList = new Gson().fromJson(content, new TypeToken<List<IssueCommitId>>() {
        }.getType());

        return issueCommitIdList;
    }

    private static List<String> getUniqueIssueCommitId(List<IssueCommitId> issueCommitIdList) {
        Set<String> issueCommitIds = new HashSet<>();
        for (IssueCommitId issueCommitId : issueCommitIdList) {
            issueCommitIds.add(issueCommitId.getIssueId());
        }
        return new ArrayList<>(issueCommitIds);
    }

    public static List<String> getUniqueIssueCommitId(String path) {
        return getUniqueIssueCommitId(readIssueCommitIds(path));
    }


    private static List<String> getUniqueIssueId(List<ProjectVersion> projectVersionList) {

        Set<String> issueIds = new HashSet<>();
        for (ProjectVersion projectVersion : projectVersionList) {
            List<Bug> bugList = projectVersion.getBugs();
            for (Bug bug : bugList) {
                issueIds.add(bug.getKey());
            }
        }
        return new ArrayList<>(issueIds);
    }

    private static List<String> realUniqueIssueId(List<ProjectVersion> projectVersionList,Set<String> affectVersion) {

        Set<String> issueIds = new HashSet<>();
        for (ProjectVersion projectVersion : projectVersionList) {
            List<Bug> bugList = projectVersion.getBugs();
            for (Bug bug : bugList) {
                if(affectVersion.contains(bug.getAffectsVersions())) {
                    issueIds.add(bug.getKey());
                }
            }
        }
        return new ArrayList<>(issueIds);
    }

    public static List<String> getUniqueIssueId(String path) {
        return getUniqueIssueId(readIssues(path));
    }

    public static Set<String> readAffectsVersion(String path){
        String content = FileUtil.read(path);
        Set<String> versions = new HashSet<>();
        JsonArray contentJson = new Gson().fromJson(content, JsonArray.class);
        Iterator iter = contentJson.iterator();
        while(iter.hasNext()){
            JsonPrimitive v = (JsonPrimitive)iter.next();
            versions.add(v.getAsString());
        }
        return versions;
    }

    public static List<String> getRealUniqueIssueId(String issuePath,String realIssuePath) {
        List<ProjectVersion> projectVersions = readIssues(issuePath);
        Set<String> versions = readAffectsVersion(realIssuePath);
        List<String> issue = realUniqueIssueId(projectVersions,versions);
        return issue;
    }


}
