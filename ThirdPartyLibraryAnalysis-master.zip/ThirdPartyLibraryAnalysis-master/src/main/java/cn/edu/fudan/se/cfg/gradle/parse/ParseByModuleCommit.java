package cn.edu.fudan.se.cfg.gradle.parse;

import cn.edu.fudan.se.cfg.gradle.parse.bean.*;
import cn.edu.fudan.se.cfg.gradle.parse.utils.GradleUtils;
import cn.edu.fudan.se.cfg.gradle.parse.utils.ParseUtil2;
import cn.edu.fudan.se.cfg.rq1.bean.DependencyLib;
import cn.edu.fudan.se.cfg.rq2.bean.CommitInfo;
import cn.edu.fudan.se.cfg.rq2.utils.GitUtil;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class ParseByModuleCommit {

    private static final String projs = "H:\\wangying\\rq2\\proj_in_usage.txt";
    //private static final String projs = "H:/wangying/rq1/test.json";
    private static final String DIR = "I:\\RQ3\\projects\\";
    private static final String OUTPUT_DIR = "I://commit_dependency\\normal//";
    private static final String ERROR_DIR = "I://commit_dependency\\error/";
    //private static final String MAVEN_DIR = "I://rq1_output\\rq3_dependency_maven//";
    private static GitUtil jGit;

    public static void main(String[] args) {

        String content = FileUtil.read(projs);
        List<ProjUsage> projUsageList = new Gson().fromJson(content, new TypeToken<List<ProjUsage>>() {
        }.getType());

        for (ProjUsage projUsage : projUsageList) {

            if (projUsage.getLocal_addr().contains("gradle")) {
                String url = projUsage.getLocal_addr();
                int id = projUsage.getId();
                System.out.println(url);
                String[] urls = url.split("/");
                String dirName = urls[urls.length - 1];
                String groupId = dirName.split("__fdse__")[0];
                String artifactId = dirName.split("__fdse__")[1];
//                File existFile = new File(OUTPUT_DIR + groupId + "__fdse__" + groupId + ".txt");
//                if (existFile.exists()) {
//                    continue;
//                }
                parseCommit(groupId + "__fdse__" + artifactId, "I:/projects/" + groupId + "__fdse__" + artifactId, id);
                jGit.close();
            }

        }
    }

    /**
     * 解析单个commit tree
     *
     * @param projectName
     * @param projectPath
     */
    private static void parseCommit(String projectName, String projectPath, int projectId) {
        List<CommitInfo> commitInfoList = getAllCommit(projectPath);
        int index = 1;
        int commitSize = commitInfoList.size();
        for (CommitInfo commitInfo : commitInfoList) {

            String commit1 = commitInfo.getCommitId();
            int time1 = commitInfo.getTime();
            File normalFile = new File(OUTPUT_DIR + String.valueOf(projectId) + "_" + commit1 + "_" + String.valueOf(time1) + ".txt");
            File errorFile = new File(ERROR_DIR + String.valueOf(projectId) + "_" + commit1 + "_" + String.valueOf(time1) + ".txt");

            if (normalFile.exists()||errorFile.exists()){
                continue;
            }

            try {
                String commit = commitInfo.getCommitId();
                System.out.println("parsing " + String.valueOf(projectId) + " " + projectName + " " + String.valueOf(index) + "/" + String.valueOf(commitSize) + " " + commitInfo.getCommitId());
                int time = commitInfo.getTime();
                checkout(commit, projectPath);
                List<GradleFile> gradleFileList = GradleUtils.getAllGradleFiles(projectPath);
                if (gradleFileList == null) {
                    //FileUtil.writeFlie(MAVEN_DIR + projectName + ".txt", "");
                    return;
                }
                int size = gradleFileList.size();
                if (size == 0) {
                    //FileUtil.writeFlie(MAVEN_DIR + projectName + ".txt", "");
                    return;
                }
//                boolean isAllProperties = isAllProperties(gradleFileList);
//                if (isAllProperties) {
//                    System.out.println("all properties" + String.valueOf(projectName));
//                    System.out.println(OUTPUT_DIR + projectName + ".txt");
//                    // File file = new File(OUTPUT_DIR + String.valueOf(projectId) + "_" + commit + ")" + String.valueOf(time) + ".txt");
//                    //file.delete();
//                    //FileUtil.writeFlie(MAVEN_DIR + projectName + ".txt", "");
//                    return;
//                }
                for (int gradleFileIndex = 0; gradleFileIndex < size; gradleFileIndex++) {
                    GradleFile gradleFile = gradleFileList.get(gradleFileIndex);
                    if (gradleFile.getType().equals("build.gradle")) {
                        ParseUtil2.parse(gradleFile.getContent(), gradleFile.getPath());
                    } else if (gradleFile.getType().endsWith("properties")) {
                        ParseUtil2.parseProperties(gradleFile.getPath());
                    }
                }
                ParseUtil2.replaceDependencyValue();
                ParseUtil2.replaceDependencyValue();
                ParseUtil2.replaceDependencyValue();
                ParseUtil2.replaceDependencyValue();
                ParseUtil2.clearDependencyValue();
                List<Dependency2> dependencies = ParseUtil2.getDependencies();

                handleDependency(projectName, dependencies, projectId, commit, time);
                ParseUtil2.clearDependencies();
                ParseUtil2.clearDependencyValue();
            } catch (Exception e) {
                //File file = new File(ERROR_DIR + String.valueOf(projectId) + "_" + commitInfo.getCommitId() + ")" + String.valueOf(commitInfo.getTime()) + ".txt");
                FileUtil.writeFlie(ERROR_DIR + String.valueOf(projectId) + "_" + commitInfo.getCommitId() + "_" + String.valueOf(commitInfo.getTime()) + ".txt", e.getMessage() == null ? "" : e.getMessage());
            } finally {
                index++;
            }
        }
    }

    private static List<CommitInfo> getAllCommit(String gitPath) {
        jGit = new GitUtil();
        jGit.buildRepository(gitPath + "/.git", -1);
        jGit.walkRepository(gitPath);
        return jGit.getIssueCommitIdList();
    }

    private static boolean isAllProperties(List<GradleFile> gradleFileList) {
        for (GradleFile gradleFile : gradleFileList) {
            if (!gradleFile.getPath().endsWith(".properties")) {
                return false;
            }
        }
        return true;
    }

    /**
     * 处理结果
     *
     * @param projectName
     * @param dependencies
     * @param projectId
     * @param commit
     * @param time
     */
    private static void handleDependency(String projectName, List<Dependency2> dependencies,
                                         int projectId, String commit, int time) {
        //Set<String> dependenciesSet = new HashSet<>(dependencies);
        Project2 project = new Project2();
        DependencyProject dependencyProject;
        DependencyLib dependencyLib;
        DependencyUrl dependencyUrl;

        for (Dependency2 s : dependencies) {
            if (s == null || s.getDependency() == null) {
                continue;
            }
            if (s.getDependency().startsWith("project(")) {
                //compile project(xxxxx)
//                dependencyProject = new DependencyProject(s);
//                project.getDependencyProjects().add(dependencyProject);
            } else if (s.getDependency().startsWith("files")) {
                //compile libs
//                dependencyLib = new DependencyLib(s);
//                project.getDependencyLibs().add(dependencyLib);
            } else {
                //uk.co.chrisjenx:calligraphy:2.2.0
                //group:xxx, name:xxx, version:xxx
                String dependencyString = s.getDependency();

                if (dependencyString.contains(", ")) {
                    String group = dependencyString.split(", ")[0].split(":")[1];
                    String artifactId = dependencyString.split(", ")[1].split(":")[1];
                    String version = "";
                    try {
                        version = dependencyString.split(", ")[2].split(":")[1];
                    } catch (Exception e) {
                        System.out.println(dependencyString);
                        System.out.println(s.getPath());
                        e.printStackTrace();
                        String dir = s.getPath();
                        String name = dir.split("\\\\")[2];
                        FileUtil.writeFlie(ERROR_DIR + String.valueOf(projectId) + "_" + commit + "_" + String.valueOf(time) + ".txt", "");

                    }
                    dependencyUrl = new DependencyUrl(group, artifactId, "jar", version, s.getPath());
                    project.getDependencyUrlList().add(dependencyUrl);
                } else if (s.getDependency().contains(":")) {
                    String[] tempDependencies = s.getDependency().split(":");
                    if (tempDependencies.length >= 3) {
                        String group = tempDependencies[0];
                        String artifactId = tempDependencies[1];
                        String version = tempDependencies[2];
                        dependencyUrl = new DependencyUrl(group, artifactId, "jar", version, s.getPath());
                        project.getDependencyUrlList().add(dependencyUrl);
                    }
                }
            }
        }

        FileUtil.writeFlie(OUTPUT_DIR + String.valueOf(projectId) + "_" + commit + "_" + String.valueOf(time) + ".txt", new GsonBuilder().setPrettyPrinting().create().toJson(project));


    }

    private static void checkout(String commit, String projectPath) {

        String command = String.format("git --git-dir=%s/.git --work-tree=%s checkout -f %s", projectPath, projectPath, commit);
        ProcessBuilder builder = new ProcessBuilder(
                "cmd.exe", "/c", command);
        builder.redirectErrorStream(true);
        try {
            Process p = builder.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while (true) {
                line = r.readLine();
                if (line == null) {
                    break;
                }
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
