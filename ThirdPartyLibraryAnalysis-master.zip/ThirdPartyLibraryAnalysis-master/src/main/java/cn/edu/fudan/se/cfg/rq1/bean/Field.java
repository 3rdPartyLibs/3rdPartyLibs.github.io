package cn.edu.fudan.se.cfg.rq1.bean;

public class Field {

    String type;
    String fieldName;
    int modifiers;

    public Field(String type, String fieldName, int modifiers) {
        this.type = type;
        this.fieldName = fieldName;
        this.modifiers = modifiers;
    }

    public int getModifiers() {

        return modifiers;
    }

    public void setModifiers(int modifiers) {
        this.modifiers = modifiers;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public Field() {

    }
}
