package cn.edu.fudan.se.cfg.rq2.utils;

import cn.edu.fudan.se.cfg.rq2.bean.CommitInfo;
import cn.edu.fudan.se.db.DB;
import cn.edu.fudan.se.git.IssueCommitId;
import cn.edu.fudan.se.handlepom.ChangedPomModel;
import cn.edu.fudan.se.handlepom.PomDiff;
import cn.edu.fudan.se.util.FileUtil;
import org.eclipse.jgit.api.CheckoutCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.ListBranchCommand;
import org.eclipse.jgit.api.errors.*;
import org.eclipse.jgit.diff.DiffEntry;
import org.eclipse.jgit.diff.DiffFormatter;
import org.eclipse.jgit.errors.AmbiguousObjectException;
import org.eclipse.jgit.errors.IncorrectObjectTypeException;
import org.eclipse.jgit.errors.MissingObjectException;
import org.eclipse.jgit.errors.RevisionSyntaxException;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.ObjectReader;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevTree;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.storage.file.FileRepositoryBuilder;
import org.eclipse.jgit.treewalk.CanonicalTreeParser;
import org.eclipse.jgit.treewalk.TreeWalk;
import org.eclipse.jgit.util.io.DisabledOutputStream;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GitUtil {
    private RevWalk revWalk;
    Repository repository;
    private Git git;
    int count;
    private String projectPath;
    private int projectId;
    private Map<String, List<String>> commitModifiedLib = new HashMap<>();
    private String savePath = "E:/data/lib_update/gradle_maven/";
    private static String proLocalPath = "F:/gradle_maven500/";
    private static String outOfMemoryRecordPath = "C:/Users/yw/Desktop/outofmemory.txt";
    private static String existsFilePath = "C:/Users/yw/Desktop/exists.txt";
    //	private boolean go =false;
//	private Map<String, List<String>> commitaddedLib = new HashMap<>();
//	private Map<String, List<String>> commitdeletedLib = new HashMap<>();
    private String currentProjectName;
    private List<CommitInfo> issueCommitIdList;

    public void setCurrentProjectName(String currentProjectName) {
        this.currentProjectName = currentProjectName;
    }

    public List<CommitInfo> getIssueCommitIdList() {
        return issueCommitIdList;
    }

    public void buildRepository(String path, int projectId) {
        this.projectId = projectId;
        FileRepositoryBuilder builder = new FileRepositoryBuilder();
        try {
            this.repository = builder.setGitDir(new File(path)).readEnvironment() // scan
                    .findGitDir() // scan up the file system tree
                    .build();
            this.revWalk = new RevWalk(this.repository);
            this.git = new Git(this.repository);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void close() {
        this.git.close();
        this.repository.close();
    }

    public void walkRepository(String projectPath) {
        issueCommitIdList = new ArrayList<>();
        this.projectPath = projectPath;
        Queue<RevCommit> commitQueue = new LinkedList<>();
        Map<String, Boolean> isTraversed = new HashMap<>();

        List<Ref> mList;
        try {
            mList = this.git.branchList().setListMode(ListBranchCommand.ListMode.ALL).call();
            for (Ref item : mList) {
                RevCommit commit = this.revWalk.parseCommit(item.getObjectId());
                commitQueue.offer(commit);
                while (commitQueue.size() != 0) {
                    RevCommit queueCommitItem = commitQueue.poll();
                    //String fullMessage = queueCommitItem.get
                    String commitId = queueCommitItem.getName();
                    int time = queueCommitItem.getCommitTime();


                    RevCommit[] parentCommits = queueCommitItem.getParents();
                    if (isTraversed.containsKey(queueCommitItem.getName()) || parentCommits == null) {
                        continue;
                    }

                    Map<String, Map<String, List<String>>> fileMap = getCommitParentMappedFileList(commitId);
                    boolean modifyGradleFileFlag = false;
                    for (Map.Entry<String, Map<String, List<String>>> entry :
                            fileMap.entrySet()) {
                        String parentCommitId = entry.getKey();
                        Map<String, List<String>> fileMapEntry = entry.getValue();
                        for (Map.Entry<String, List<String>> fileMapEntry2 :
                                fileMapEntry.entrySet()) {
                            List<String> files = fileMapEntry2.getValue();
                            for (String file : files) {
                                if (file.endsWith(".gradle") || file.endsWith(".properties")) {
                                    issueCommitIdList.add(new CommitInfo(commitId,parentCommitId, time));
                                    modifyGradleFileFlag = true;
                                    break;
                                }
                            }
                            if (modifyGradleFileFlag) {
                                break;
                            }
                        }
//                        if (modifyGradleFileFlag) {
//                            break;
//                        }
                    }

                    isTraversed.put(queueCommitItem.getName(), true);
                    for (RevCommit item2 : parentCommits) {
                        RevCommit commit2 = this.revWalk.parseCommit(item2.getId());
                        commitQueue.offer(commit2);
                    }
//		            break;
                }
            }
        } catch (GitAPIException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (MissingObjectException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IncorrectObjectTypeException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private Set<String> checkHasIssueId(String message, String currentProjectName) {
        String reg = currentProjectName + "-" + "([0-9]+)";
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(message);
        Set<String> resultSet = new HashSet<>();
        while (matcher.find()) {
            int size = matcher.groupCount();
            for (int index = 0; index < size; index++) {
                resultSet.add(matcher.group(index));
            }
        }
        return resultSet;
    }

//    public void pomChange(Map<String, Map<String, List<String>>> changedFiles, String currCommitId, String projectPath) {
//        for (Map.Entry<String, Map<String, List<String>>> entry : changedFiles.entrySet()) {
//            String parentCommitId = entry.getKey();
//            commitModifiedLib = new HashMap<>();
//            String name = null;
//            RevCommit commit;
//            int time1 = -1, time2 = -1;
//            try {
//                commit = this.revWalk.parseCommit(this.repository.resolve(parentCommitId));
//                time1 = commit.getCommitTime();
//                commit = this.revWalk.parseCommit(this.repository.resolve(currCommitId));
//                time2 = commit.getCommitTime();
//            } catch (RevisionSyntaxException | IOException e) {
//                // TODO Auto-generated catch block
//                e.printStackTrace();
//            }
//            Map<String, List<String>> changedFileEntry = entry.getValue();
//            if (changedFileEntry.containsKey("modifiedFiles")) {
//                List<String> modifiedFile = changedFileEntry.get("modifiedFiles");
//                for (String file : modifiedFile) {
//                    if (file.endsWith("pom.xml")) {
//                        name = file;
//
////					if(file.equals("actionbarsherlock/library/pom.xml") && currCommitId.equals("2b70c8f7553c4b43e37bf653482d2d5682083877")) {
//                        System.out.println("---------------------modify:" + file);
//                        System.out.println(parentCommitId + " " + currCommitId);
//                        ChangedPomModel changedPomModel1 = new ChangedPomModel(this.projectPath, this, parentCommitId);
//                        changedPomModel1.handlePom(file);
//                        Map<String, Map<String, String>> prevLibVerPairs = changedPomModel1.getLibVerPairs();
//                        PomDiff.printLibs(prevLibVerPairs);
//                        ChangedPomModel changedPomModel2 = new ChangedPomModel(this.projectPath, this, currCommitId);
//                        changedPomModel2.handlePom(file);
//                        Map<String, Map<String, String>> currLibVerPairs = changedPomModel2.getLibVerPairs();
//                        PomDiff.printLibs(currLibVerPairs);
//                        Map<String, Map> changedLib = PomDiff.compareDiff(prevLibVerPairs, currLibVerPairs);
//                        if (changedLib.containsKey("modified")) {
//                            Map<String, String[]> modifiedLib = changedLib.get("modified");
//                            for (Map.Entry<String, String[]> modified : modifiedLib.entrySet()) {
//                                String lib = modified.getKey();
//                                String version1 = modified.getValue()[0];
//                                String version2 = modified.getValue()[1];
////								System.out.println(lib +" "+ version1 +" "+ version2);
//                                if (this.commitModifiedLib.containsKey(lib)) {
////									if(this.commitModifiedLib.get(lib) == null) {
////										List<String> vers = new ArrayList<>();
////										vers.add(version1 +" "+version2);
////										this.commitModifiedLib.put(lib, vers);
////									}
////									else {
////										if(!this.commitModifiedLib.get(lib).contains(version1 +" "+version2)) {
////											this.commitModifiedLib.get(lib).add(version1 +" "+version2);
////										}
////									}
//                                    if (!this.commitModifiedLib.get(lib).contains(version1 + " " + version2)) {
//                                        this.commitModifiedLib.get(lib).add(version1 + " " + version2);
//                                    }
////									&& this.commitModifiedLib.get(lib)[0].equals(version1)&& this.commitModifiedLib.get(lib)[1].equals(version2)
//                                } else {
//                                    List<String> vers = new ArrayList<>();
//                                    vers.add(version1 + " " + version2);
//                                    this.commitModifiedLib.put(lib, vers);
//                                }
//                            }
//                        }
//                    }
////                	}
//                }
//            }
////            System.out.println(this.commitModifiedLib.size());
//            PomDiff.printModify(this.commitModifiedLib);
//            storeToFile(name, parentCommitId, currCommitId, time1, time2);
////            storeToDb(name,parentCommitId,currCommitId,time1,time2);
//        }
//
//    }

    public void storeToDb(String file, String parentCommitId, String currCommitId, int time1, int time2) {
        for (Map.Entry<String, List<String>> modified : this.commitModifiedLib.entrySet()) {
            String[] lib = modified.getKey().split(" ");
            String groupId = lib[0];
            String artifactId = lib[1];
            String type = lib[2];
            String classifier = null;
            if (lib.length == 4) {
                classifier = lib[3];
            }
            for (String value : modified.getValue()) {
                String[] vers = value.split(" ");
                if (vers.length == 2) {
                    String version1 = vers[0];
                    String version2 = vers[1];
                    String sql = "INSERT INTO lib_update(project_id,file,group_str,name_str,prev_version,curr_version,prev_time,curr_time,prev_commit,curr_commit,remark,type,classifier) VALUES ("
                            + this.projectId + ",\'" + file + "\',\'" + groupId + "\',\'" + artifactId
                            + "\',\'" + version1 + "\',\'" + version2 + "\'," + time1 + ", " + time2 + ",\'"
                            + parentCommitId + "\',\'" + currCommitId + "\',\'modified\', \'" + type
                            + "\', \'" + classifier
                            + "\')";
                    DB.update(sql);
                }
            }

        }
//		for (Map.Entry<String, String> deleted : this.commitdeletedLib.entrySet()) {
//			String[] lib = deleted.getKey().split(" ");
//			String groupId = lib[0];
//			String artifactId = lib[1];
//			String type = null;
//			if (lib.length == 3) {
//				type = lib[2];
//			}
//			String version = deleted.getValue();
//			String sql = "INSERT INTO lib_update(project_id,file,group_str,name_str,prev_version,curr_version,prev_time,curr_time,prev_commit,curr_commit,remark,type) VALUES ("
//					+ this.projectId + ",\'" + file + "\',\'" + groupId + "\',\'" + artifactId
//					+ "\',\'" + version + "\',"+null+"," + time1 + ", " + time2 + ",\'"
//					+ parentCommitId + "\',\'" + currCommitId + "\',\'deleted\', \'" + type
//					+ "\')";
//			DB.update(sql);
//		}
//		for (Map.Entry<String, String> added : this.commitaddedLib.entrySet()) {
//			String[] lib = added.getKey().split(" ");
//			String groupId = lib[0];
//			String artifactId = lib[1];
//			String type = null;
//			if (lib.length == 3) {
//				type = lib[2];
//			}
//			String version = added.getValue();
//			String sql = "INSERT INTO lib_update(project_id,file,group_str,name_str,prev_version,curr_version,prev_time,curr_time,prev_commit,curr_commit,remark,type) VALUES ("
//					+ this.projectId + ",\'" + file + "\',\'" + groupId + "\',\'" + artifactId
//					+ "\',"+null+",\'" + version + "\'," + time1 + ", " + time2 + ",\'"
//					+ parentCommitId + "\',\'" + currCommitId + "\',\'added\', \'" + type
//					+ "\')";
//			DB.update(sql);
//		}
    }

    public void storeToFile(String file, String parentCommitId, String currCommitId, int time1, int time2) {
        for (Map.Entry<String, List<String>> modified : this.commitModifiedLib.entrySet()) {
            String[] lib = modified.getKey().split(" ");
            String groupId = lib[0];
            String artifactId = lib[1];
            String type = lib[2];
            String classifier = null;
            if (lib.length == 4) {
                classifier = lib[3];
            }
            for (String value : modified.getValue()) {
                String[] vers = value.split(" ");
                if (vers.length == 2) {
                    String version1 = vers[0];
                    String version2 = vers[1];
                    String sql = "INSERT INTO lib_update(project_id,file,group_str,name_str,prev_version,curr_version,prev_time,curr_time,prev_commit,curr_commit,remark,type,classifier) VALUES ("
                            + this.projectId + ",\'" + file + "\',\'" + groupId + "\',\'" + artifactId
                            + "\',\'" + version1 + "\',\'" + version2 + "\'," + time1 + ", " + time2 + ",\'"
                            + parentCommitId + "\',\'" + currCommitId + "\',\'modified\', \'" + type
                            + "\', \'" + classifier
                            + "\')";
//					DB.update(sql);
                    FileUtil.appendFile(this.savePath + this.projectId + ".txt", sql);
                }
            }
        }
    }

    public Map<String, Map<String, List<String>>> getCommitParentMappedFileList(String commmitid) {
        Map<String, Map<String, List<String>>> result = new HashMap<>();
        ObjectId commitId = ObjectId.fromString(commmitid);
        RevCommit commit = null;
        Map<String, List<String>> fileList = null;
        List<String> addList = null;
        List<String> modifyList = null;
        List<String> deleteList = null;

        try {
            commit = revWalk.parseCommit(commitId);
            RevCommit[] parentsCommits = commit.getParents();
            for (RevCommit parent : parentsCommits) {
                fileList = new HashMap<String, List<String>>();
                addList = new ArrayList<String>();
                modifyList = new ArrayList<String>();
                deleteList = new ArrayList<String>();
                ObjectReader reader = git.getRepository().newObjectReader();
                CanonicalTreeParser newTreeIter = new CanonicalTreeParser();
                ObjectId newTree = commit.getTree().getId();
                newTreeIter.reset(reader, newTree);
                CanonicalTreeParser oldTreeIter = new CanonicalTreeParser();
                RevCommit pCommit = revWalk.parseCommit(parent.getId());
                ObjectId oldTree = pCommit.getTree().getId();
                oldTreeIter.reset(reader, oldTree);
                DiffFormatter diffFormatter = new DiffFormatter(DisabledOutputStream.INSTANCE);
                diffFormatter.setRepository(git.getRepository());
                List<DiffEntry> entries = diffFormatter.scan(oldTreeIter, newTreeIter);
                for (DiffEntry entry : entries) {
                    switch (entry.getChangeType()) {
                        case ADD:
                            addList.add(entry.getNewPath());
                            break;
                        case MODIFY:
                            modifyList.add(entry.getNewPath());
                            break;
                        case DELETE:
                            deleteList.add(entry.getNewPath());
                            break;
                        default:
                            break;
                    }
                }
                diffFormatter.close();
                fileList.put("addedFiles", addList);
                fileList.put("modifiedFiles", modifyList);
                fileList.put("deletedFiles", deleteList);
                result.put(pCommit.getName(), fileList);
            }
            return result;
        } catch (MissingObjectException e) {
            e.printStackTrace();
        } catch (IncorrectObjectTypeException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public InputStream extract(String fileName, String revisionId) {
        if (revisionId == null || fileName == null) {
            System.err.println("revisionId/fileName is null..");
            return null;
        }
        if (this.repository == null || git == null || revWalk == null) {
            System.err.println("git repo is null..");
            return null;
        }
        RevWalk walk = new RevWalk(this.repository);
        try {
            ObjectId objId = this.repository.resolve(revisionId);
            if (objId == null) {
                System.err.println("The revision:" + revisionId + " does not exist.");
                walk.close();
                return null;
            }
            RevCommit commit = walk.parseCommit(this.repository.resolve(revisionId));
            if (commit != null) {
                RevTree tree = commit.getTree();
                TreeWalk treeWalk = TreeWalk.forPath(this.repository, fileName, tree);
                if (treeWalk == null)
                    return null;
                ObjectId id = treeWalk.getObjectId(0);

                InputStream is = FileUtil.open(id, this.repository);
                return is;
//				byte[] res = FileUtil.toByteArray(is);
//				return res;
            } else {
                System.err.println("Cannot found file(" + fileName + ") in revision(" + revisionId + "): " + revWalk);
            }
        } catch (RevisionSyntaxException e) {
            e.printStackTrace();
        } catch (MissingObjectException e) {
            e.printStackTrace();
        } catch (IncorrectObjectTypeException e) {
            e.printStackTrace();
        } catch (AmbiguousObjectException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        walk.close();
        return null;
    }

    public static String stampToDate(int time) {
        Long s = time * 1000L;
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date(s);
        res = simpleDateFormat.format(date);
        return res;
    }


    public int getCommitChangeList(String commitStr) {
        RevCommit commit;
        try {
            commit = this.revWalk.parseCommit(this.repository.resolve(commitStr));
            return commit.getCommitTime();
        } catch (RevisionSyntaxException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return -1;
    }

    public void readFile(String path) {

//		String proLocalPath = "E:/high_quality_repos/";
        int index = 0;
        Map<Integer, String> projects = new HashMap<>();
        try {
            Scanner in = new Scanner(new File(path));
            while (in.hasNextLine()) {
                String str = in.nextLine();
                String absolutePath = null;
                if (str.startsWith("https://github.com/")) {
                    absolutePath = str.substring(19);
                    String[] splitedPath = absolutePath.split("/");
                    if (splitedPath.length == 2) {
                        absolutePath = splitedPath[0] + "__fdse__" + splitedPath[1];
                    }
                    absolutePath = proLocalPath + absolutePath;
                    File file = new File(absolutePath);
                    if (file.exists()) {
//						System.out.println(index);
                        projects.put(index, absolutePath);
//						System.out.println(index+": "+absolutePath);
//						count++;
//						if(count < 2) {
//							JgitRepository jgit = new JgitRepository();
//							jgit.buildRepository(absolutePath+"/.git",index);
//							jgit.walkRepository(absolutePath);
//						}
                    }
//					else {
//						FileUtil.appendFile("remaining_maven_url_three_months.txt",""+index);
//						FileUtil.appendFile("remaining_maven_url_three_months.txt",str);
//					}
                } else
                    index = Integer.parseInt(str);
            }
            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        for (int i = 1; i <= 6000; i++) {
            if (projects.containsKey(i)) {
                File test = new File(this.savePath + this.projectId + ".txt");
                if (test.exists()) {
                    FileUtil.appendFile(this.existsFilePath, "" + i);
                    continue;
                }
                String pjPath = projects.get(i);
                System.out.println(i + ": " + pjPath);
                try {
                    GitUtil jgit = new GitUtil();
                    jgit.buildRepository(pjPath + "/.git", i);
                    jgit.walkRepository(pjPath);
                } catch (OutOfMemoryError e) {
                    // TODO Auto-generated catch block
//						e.printStackTrace();
                    System.out.println("OutOfMemoryError");
                    FileUtil.appendFile(outOfMemoryRecordPath, "" + i);
                }
            }
        }
        //1494515425 1494511216
//		String sql = "insert into lib_update (id,prev_time,curr_time) values ";
//		int count = 0;
//		for(int i = 4;i<=4;i++) {
//			try {
//				if(projects.containsKey(i)) {					
//					String pjPath = projects.get(i);
//					System.out.println(i+": "+pjPath);
//					JgitRepository jgit = new JgitRepository();
//					jgit.buildRepository(pjPath+"/.git",i);
//					ResultSet rs = DB.query("SELECT * FROM `lib_update` where `project_id`= " + i);
//					while (rs.next()) {
//						count ++;
//						System.out.println(count);
//						int id = rs.getInt("id");
//						String prevCommit  = rs.getString("prev_commit");
//						String currCommit  = rs.getString("curr_commit");
//
//						int time1 = jgit.getCommitTime(prevCommit);
//						int time2 = jgit.getCommitTime(currCommit);
//						sql += "("+id+","+time1+","+time2+"),";
//						if(count == 5000) {
//							if(sql.endsWith(","))
//								sql = sql.substring(0, sql.length()-1);
//							sql += " on duplicate key update prev_time=values(prev_time),curr_time=values(curr_time)";
//							System.out.println(sql);
//							DB.update(sql);
//							
//							count = 0;
//							sql = "insert into lib_update (id,prev_time,curr_time) values ";
//						}
//					}						
//				} 
//						
////					String pjPath = projects.get(i);
////					System.out.println(i+": "+pjPath);
////					JgitRepository jgit = new JgitRepository();
////					jgit.buildRepository(pjPath+"/.git",i);
////					jgit.walkRepository(pjPath);	
//			}
//			catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}			
//		}
//		if(sql.endsWith(","))
//			sql = sql.substring(0, sql.length()-1);
//		System.out.println(sql);
//		sql += " on duplicate key update prev_time=values(prev_time),curr_time=values(curr_time)";
//		DB.update(sql);
    }

    public static void main(String[] args) {
////        String outputPath = "C:\\cs\\issues\\output\\";
//        String outputPath = "C:\\Users\\huangkaifeng\\Desktop\\RQ3";
////        String basePath = "C:\\cs\\issues\\";
//        String basePath = "C:\\Users\\huangkaifeng\\Desktop\\RQ3\\issues";
//        String[] projectNames = {"commons-cli", "commons-codec", "commons-collections", "commons-io", "commons-lang",
//                "commons-logging", "httpcomponents-client", "logback", "logging-log4j2", "slf4j"};
//        String issueBasePath = "\\projs\\projs\\";
//        String[] issueFiles = {"CLI", "CODEC", "COLLECTIONS", "COMMON-IO", "LANG", "LOGGING", "HTTPCLIENT", "LOGBACK", "LOG4J2", "SLF4J"};
//        for (int index = 0; index < projectNames.length; index++) {
//            issueIds = IssueUtil.getUniqueIssueId(basePath + issueBasePath + issueFiles[index] + ".txt");
//            currentProjectName = issueFiles[index];
//            System.out.println("=======");
//            System.out.println(currentProjectName);
//            JgitRepository jgit = new JgitRepository();
////		jgit.readFile("gradle_maven_url_three_months.txt");
////		JgitRepository jgit = new JgitRepository();
//            String gitPath = basePath + projectNames[index] + "\\.git";
//            String repositoryPath = basePath + projectNames[index];
//            jgit.buildRepository(gitPath, -1);
////		jgit.checkout("2b70c8f7553c4b43e37bf653482d2d5682083877");
//            jgit.walkRepository(repositoryPath);
//            Gson gson = new GsonBuilder().setPrettyPrinting().create();
//            FileUtil.writeFlie(outputPath + currentProjectName + ".txt", gson.toJson(jgit.getIssueCommitIdList()));

//        }
    }

    /**
     * checkout to one commit
     *
     * @param commitid
     */
    public void checkout(String commitid) {
        try {
            CheckoutCommand checkoutCommand = git.checkout();
            Ref ref = checkoutCommand.setName(commitid).call();
            System.out.println(ref.getName());
        } catch (RefAlreadyExistsException e) {
            e.printStackTrace();
        } catch (RefNotFoundException e) {
            e.printStackTrace();
        } catch (InvalidRefNameException e) {
            e.printStackTrace();
        } catch (CheckoutConflictException e) {
            e.printStackTrace();
        } catch (GitAPIException e) {
            e.printStackTrace();
        }
    }
}
