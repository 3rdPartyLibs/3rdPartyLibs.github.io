package cn.edu.fudan.se.cfg;

import cn.edu.fudan.se.util.JavaMethodUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import soot.*;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.options.Options;
import soot.util.dot.DotGraph;
import soot.util.dot.DotGraphNode;

import java.io.File;
import java.lang.reflect.Field;
import java.util.*;

/**
 * Created by Basti on 2018/9/13.
 */
public class SootInvoker_Basti {

    //key为方法名的hash值
    //value为方法内容的hash值
    static Map<String, String> preContent, curContent;

    static final String DECOMPILE_OUTPUT_PATH = "decompile_output/";

    public static void main(String args[]) throws NoSuchFieldException, IllegalAccessException {

        String inputPath = "C:/cs/jar";
        File f = new File(inputPath);
        File[] files = f.listFiles();
        List<String> unzipPath = new ArrayList<>();
        List<String> jarPath = new ArrayList<>();
        for (File tmp : files) {
            if (tmp.getAbsolutePath().endsWith(".jar")) {
                String newPath = tmp.getAbsolutePath().substring(0, tmp.getAbsolutePath().length() - 4) + "_unzip";
                File ff = new File(newPath);
                if (!ff.exists()) {
                    //ZipUtil.zip(tmp.getAbsolutePath(), newPath);
                }
                unzipPath.add(newPath);
                jarPath.add(tmp.getAbsolutePath());
            }
        }
        JSONObject jo = SootFileUtils.fromJsonText(inputPath + "/meta.txt");
        String prevJar = jo.getString("prev_jar");
        String currJar = jo.getString("curr_jar");
        JSONArray jaPrev = (JSONArray) jo.get("prev_api_call_list");
        JSONArray jaCurr = (JSONArray) jo.get("curr_api_call_list");
        for (int i = 0; i < jarPath.size(); i++) {
            String item = jarPath.get(i);
            String item2 = unzipPath.get(i);
            if (item.contains(prevJar)) {
                invokeSoot(args, prevJar, item2, jaPrev, inputPath);
            }
            if (item.contains(currJar)) {
                invokeSoot(args, currJar, item2, jaCurr, inputPath);
            }
        }
    }


    public static void invokeSoot(String args[], String jarName, String classesPath, JSONArray methodNames, String outputPath) throws NoSuchFieldException, IllegalAccessException {
        CallGraphVisitor callGraphVisitor = new CallGraphVisitor(outputPath + "/" + jarName + ".dot");
        List<String> classNames = new ArrayList<>();
        Map<String, List<String>> mmap = SootFileUtils.getClassNameAndMethodNames(methodNames, classNames);
        G.reset();
        List<String> argsList = new ArrayList<>(Arrays.asList(args));
        //
        argsList.addAll(Arrays.asList(new String[]{"-android-jars", "C:/Users/huangkaifeng/Desktop/SootExec/android.jar", "-allow-phantom-refs", "-w",
                // "-no-bodies-for-excluded",
                "-cp", classesPath, "-process-dir",
                classesPath}));

        args = argsList.toArray(new String[0]);
        Options.v().parse(args);
        Options.v().set_src_prec(Options.src_prec_java);
//        Options.v().set_process_dir(Collections.singletonList(processDir));
        Options.v().set_whole_program(true);
        Options.v().set_allow_phantom_refs(true);

//        Options.v().set_verbose(true);
        Options.v().set_output_format(Options.output_format_none);
        Options.v().setPhaseOption("cg.spark", "on");
        Options.v().set_no_bodies_for_excluded(true);
//        Options.v().set_app(true);
        enableSpark();
        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
//        String mainClass = "Test1";
//        SootClass c = loadClass("org.openjdk.jmh.runner.options.ChainedOptionsBuilder",false);
        List<SootMethod> entryPoints = SootUtil.loadEntryPoints(classNames, mmap);
        Scene.v().setEntryPoints(entryPoints);
//        enableSpark();
        PackManager.v().runPacks();
        CallGraph callGraph = Scene.v().getCallGraph();
        for (SootMethod entryPoint : entryPoints) {
            callGraphVisitor.visit(callGraph, entryPoint);
        }
        DotGraph dotGraph = callGraphVisitor.getDot();

        /**
         * 反射获取dotGraph中的nodes变量
         */
        Class<DotGraph> dotGraphClass = (Class<DotGraph>) dotGraph.getClass();
        Field nodesField = dotGraphClass.getDeclaredField("nodes");
        nodesField.setAccessible(true);
        HashMap<String, DotGraphNode> nodes = (HashMap<String, DotGraphNode>) nodesField.get(dotGraph);
        List<Method> calledMethodList = new ArrayList<>();
        /**
         * nodes中存储着方法名，对方方法名进行遍历
         * calledMethodList中存储着在下一阶段我们需要比对的方法
         */
        for (Map.Entry<String, DotGraphNode> entry : nodes.entrySet()) {
            //eg1:<org.openjdk.jmh.util.Utils: void check(java.lang.Class,java.lang.String)>
            //eg2:<java.lang.StringBuilder: void <init>()>
            String method = entry.getKey();
            int length = method.length();
            method = method.substring(1, length - 1);
            //method:java.lang.StringBuilder: void <init>()
            String className = method.split(": ")[0];
            String methodName = method.split(": ")[1];
            boolean isJDKMethod = JavaMethodUtil.isJDKMethod(className);
            if (!isJDKMethod) {
                calledMethodList.add(new Method(className, methodName));
            }
        }

        //对calledMethodList进行排序，简化下阶段的比对
        Collections.sort(calledMethodList, new Comparator<Method>() {

            @Override
            public int compare(Method m1, Method m2) {
                return (m1.getClassName() + m1.getMethodName()).compareTo(m2.getClassName() + m2.getMethodName());
            }
        });

        /**
         * 遍历calledMethodList,对每个方法通过查询反编译代码的方法获取其方法body和hash
         */
        boolean different = sameTwoVersionsMethodList(calledMethodList, calledMethodList);

        // SootFileUtils.toFile(outputPath.substring(0, outputPath.length() - 4) + "/" + jarName + "_dot.dot", callGraphVisitor.getDot());
    }

    /**
     * 比对两个版本的方法是否相同
     * <p>
     * 比较方法：
     * 1. 首先比较方法列表的数量，数量不同，说明v1 v2发生了变化
     * 2. 如果数量相同，比较方法列表每一个item的内容，如果不同，说明v1 v2发生了变化
     * 3. 如果每个item内容（方法名）都相同，则需要比较对应方法的hash值
     *
     * @param preMethodList
     * @param currMethodList
     * @return
     */
    private static boolean sameTwoVersionsMethodList(List<Method> preMethodList, List<Method> currMethodList) {

        boolean same = true;

        //1
        int preSize = preMethodList.size();
        int currSize = currMethodList.size();
        if (preSize != currSize) {
            return false;
        }

        //2
        for (int index = 0; index < preSize; index++) {
            if (!preMethodList.get(index).equals(currMethodList.get(index))) {
                return false;
            }
        }

        //3.1 首先反编译
        String preJarPath = "";
        String currJarPath = "";

        String preJarOutputPath = JavaMethodUtil.decompileJar(preJarPath, DECOMPILE_OUTPUT_PATH);
        String currJarOutputPath = JavaMethodUtil.decompileJar(currJarPath, DECOMPILE_OUTPUT_PATH);

        //3.2 反编译后得到java文件，将java文件读入inputstream，交给CompilationUnit分析
        List<Method> preMethodHashList = new ArrayList<>();
        List<Method> currMethodHashList = new ArrayList<>();
        for (int index = 0; index < preSize; index++) {
            Method m1 = preMethodList.get(index);
            Method m2 = currMethodList.get(index);
            //对于一个Method
            //eg1:<org.openjdk.jmh.util.Utils: void check(java.lang.Class,java.lang.String)>
            //eg2:<java.lang.StringBuilder: void <init>()>
            //className: org.openjdk.jmh.util.Utils
            //methodName: void check(java.lang.Class,java.lang.String)
            String preJavaPath = preJarOutputPath + "/" + m1.getClassName().replaceAll("\\.", "/") + ".java";
            String currJavaPath = currJarOutputPath + "/" + m1.getClassName().replaceAll("\\.", "/") + ".java";

            CompilationUnit preUnit = JavaMethodUtil.getCompilationUnit(preJavaPath);
            CompilationUnit currUnit = JavaMethodUtil.getCompilationUnit(currJavaPath);

            //接下来从两个unit中找到我们需要比对的方法，
            TypeDeclaration preType = (TypeDeclaration) preUnit.types().get(0);
            TypeDeclaration currType = (TypeDeclaration) currUnit.types().get(0);
            List<BodyDeclaration> preBodyDeclarationList = preType.bodyDeclarations();
            List<BodyDeclaration> currBodyDeclarationList = currType.bodyDeclarations();
            initMethodList(preMethodHashList, m1, preBodyDeclarationList);
            initMethodList(currMethodHashList, m2, currBodyDeclarationList);
        }
        //两个jar包的某个方法所有相关方法都已存在preMethodHashList和currMethodList中，比较像对应方法的hash值
        int size = preMethodHashList.size();
        for (int index = 0; index < size; index++) {
            Method preMethod = preMethodHashList.get(index);
            Method currMethod = currMethodHashList.get(index);

            if (preMethod == null||currMethod == null){
                return false;
            }

            if (preMethod.getBodyHashCode() != currMethod.getBodyHashCode()){
                return false;
            }
        }
        return true;
    }

    private static void initMethodList(List<Method> preMethodHashList, Method m1, List<BodyDeclaration> preBodyDeclarationList) {
        boolean preFlag = false;//用flag标志是否找到该方法
        for (BodyDeclaration bodyDeclaration : preBodyDeclarationList) {
            if (bodyDeclaration instanceof MethodDeclaration) {
                Method tempMethod = new Method((MethodDeclaration) bodyDeclaration);
                //判别是否是m1对应的方法
                if (m1.isSameWithMethodDeclaration(tempMethod)) {
                    //tempMethod就是找到的方法
                    preMethodHashList.add(tempMethod);
                    preFlag = true;
                }
            }
        }
        //如果没有找到该方法，添加一个null占位
        if (!preFlag) {
            preMethodHashList.add(null);
        }
    }


    private static SootClass loadClass(String name, boolean main) {
        SootClass c = Scene.v().loadClassAndSupport(name);
        c.setApplicationClass();
        if (main)
            Scene.v().setMainClass(c);
        return c;
    }


    private static void enableSpark() {
        HashMap opt = new HashMap();
        opt.put("verbose", "true");
        opt.put("propagator", "worklist");
        opt.put("simple-edges-bidirectional", "false");
        opt.put("on-fly-cg", "true");
        opt.put("apponly", "true");
        opt.put("set-impl", "double");
        opt.put("double-set-old", "hybrid");
        opt.put("double-set-new", "hybrid");
        SparkTransformer.v().transform("", opt);
    }


}

