package cn.edu.fudan.se.git;

public class Bug {
    /**
     * summary : HelpFormatter throws NullPointerException
     * affectsVersions : Nightly Builds
     * components : CLI-1.x
     * fixVersions : 1.0
     * priority : Major
     * resolution : Fixed
     * key : CLI-11
     */
    private String summary;
    private String affectsVersions;
    private String components;
    private String fixVersions;
    private String priority;
    private String resolution;
    private String key;

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public void setAffectsVersions(String affectsVersions) {
        this.affectsVersions = affectsVersions;
    }

    public void setComponents(String components) {
        this.components = components;
    }

    public void setFixVersions(String fixVersions) {
        this.fixVersions = fixVersions;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getSummary() {
        return summary;
    }

    public String getAffectsVersions() {
        return affectsVersions;
    }

    public String getComponents() {
        return components;
    }

    public String getFixVersions() {
        return fixVersions;
    }

    public String getPriority() {
        return priority;
    }

    public String getResolution() {
        return resolution;
    }

    public String getKey() {
        return key;
    }
}
