package cn.edu.fudan.se.cfg.rq2;

import cn.edu.fudan.se.cfg.MethodResult;
import cn.edu.fudan.se.cfg.NeedMethods;
import cn.edu.fudan.se.cfg.rq2.bean.Meta;
import cn.edu.fudan.se.cfg.rq2.bean.MethodList;
import cn.edu.fudan.se.cfg.rq2.bean.Result;
import cn.edu.fudan.se.cfg.rq2.utils.JDTUtils;
import cn.edu.fudan.se.cfg.rq2.utils.JavaCallGraphJDTAdapter;
import cn.edu.fudan.se.cfg.rq2.utils.MapUtils;
import cn.edu.fudan.se.cfg.rq2.utils.MetaMethodUtil;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.GsonBuilder;
import gr.gousiosg.javacg.stat.InvokeUtils4;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import soot.Body;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CallGraphDiff {
    //    static final String DECOMPILE_OUTPUT_PATH = "d:/cs/jar/decompile_output/";//反编译路径
    //static final String JAR_PATH = "H:\\wangying\\lib_all\\";//jar包所在的路径
    static final String JAR_PATH_DEBUG = "D:\\cs\\jar\\jar\\";//jar包所在的路径
    static final String JAR_PATH_PRO = "H:\\wangying\\lib_all\\";//jar包所在的路径
    //    //static final String META_PATH = "D:\\cs\\jar\\final_output\\";//所有meta文件所在的目录路径
//    static final String META_PATH = "D:\\cs\\jar\\test\\";//所有meta文件所在的目录路径
//    static final String UNZIP_PATH = "D:\\cs\\jar\\unzip\\";//解压jar包的目录路径
//    static final String RESULT_PATH = "D:\\cs\\jar\\result\\";//输出结果目录
//    static final String DECOMPILE_OUTPUT_PATH = "d:/cs/jar/decompile_output/";//反编译路径
//    static final String JAR_PATH = "H:\\wangying\\lib_all\\";//jar包所在的路径
    static final String META_PATH_DEBUG = "D:\\cs\\jar\\test\\";//所有meta文件所在的目录路径
    static final String META_PATH_PRO = "D:/wangying/rq2/compare_list/";//所有meta文件所在的目录路径
    static final String UNZIP_PATH = "D:\\cs\\jar\\unzip\\";//解压jar包的目录路径
    static final String RESULT_PATH_DEBUG = "D:\\cs\\jar\\result\\";//输出结果目录
    static final String RESULT_PATH_PRO = "D:\\wangying\\rq2\\result\\";//输出结果目录

    static final boolean DEBUG = false;


    public static void main(String[] args) throws Exception {

        String JAR_PATH = DEBUG ? JAR_PATH_DEBUG : JAR_PATH_PRO;
        String META_PATH = DEBUG ? META_PATH_DEBUG : META_PATH_PRO;
        String RESULT_PATH = DEBUG ? RESULT_PATH_DEBUG : RESULT_PATH_PRO;

        File file = new File(META_PATH);
        File[] metaList = file.listFiles();

        for (File metaFile : metaList) {
            //对于每一个meta文件

            //如果在输出结果目录存在该文件，说明已经解析过，跳过
            System.out.println("===========");
            System.out.println(metaFile.getName());
            File resultFile1 = new File(RESULT_PATH + metaFile.getName());
            File resultFile2 = new File(RESULT_PATH + metaFile.getName());
            if (resultFile1.exists() || resultFile2.exists()) {
                continue;
            }
            List<Result> resultList = new ArrayList<>();
            //读取meta文件，得到prev和curr两个方法列表
            List<Meta> metas = MetaMethodUtil.readMethodList(metaFile.getAbsolutePath());
            for (Meta meta : metas) {
                MethodList methodList = new MethodList(meta.getPrev_api_call_list(), meta.getCurr_api_call_list(), meta.getPrev_jar(), meta.getCurr_jar());

                List<String> prevMethodStringList = methodList.getPrevList();
                List<String> currMethodStringList = methodList.getCurrList();
                String prevJar = methodList.getPrevJar();
                String currJar = methodList.getCurrJar();

                Result result = new Result(prevJar, currJar, false);
                //生成需要检查的方法列表
                NeedMethods needMethods = initFinalList(prevMethodStringList, currMethodStringList);
                String preJarPath = JAR_PATH + prevJar;
                String currJarPath = JAR_PATH + currJar;
                /**
                 *
                 * 1.检查needMethods中 uniqueList中的每个方法在prevJar中是否存在，只要有一个方法不存在就返回false
                 * 2.如果uniqueList中的每个方法都在prevJar中存在，则从头开始进行方法比较
                 */

                List<String> needMethodList = new ArrayList<>();
                needMethodList.addAll(needMethods.getUniqueList());
                needMethodList.addAll(needMethods.getCommonList());
                int size = needMethodList.size();
                if (size == 0) {
                    //FileUtil.writeFlie(RESULT_PATH + "false_" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(false, -1)));
                    resultList.add(result);
                    continue;
                }
                //控制输出
                boolean hasOutput = false;
                for (int index = 0; index < size; index++) {
                    String needMethod = needMethodList.get(index);
                    System.out.println(prevJar + needMethod);
                    System.out.println(currJar + needMethod);
                    //首先比较该方法的callgraph数，如果树不相同，则肯定需要更新
                    Map<String, List<String>> preInvokeMap = InvokeUtils4.getInvokeMethodByMethodName(prevJar, preJarPath, needMethod);
                    Map<String, List<String>> currInvokeMap = InvokeUtils4.getInvokeMethodByMethodName(prevJar, currJarPath, needMethod);
                    if (!MapUtils.compare(preInvokeMap, currInvokeMap)) {
                        //如果发生变化
                        hasOutput = true;
                      //  FileUtil.writeFlie(RESULT_PATH + "true_" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(true, 1)));
                        result.setChange(true);
                        resultList.add(result);
                        break;
                    }
                    //比较完树以后，需要比较具体的方法body
                    //首先生成需要比较的list
                    List<String> invokeMethodList = MapUtils.invokeMapToList(preInvokeMap);

                    for (String invokeMethod : invokeMethodList) {
                        //java文件路径
                        String javaPath = JDTUtils.packageToJavaPath(invokeMethod);
                        List<BodyDeclaration> preBodyDeclarationList = JDTUtils.getCompilationUnitByJar(preJarPath, javaPath);
                        List<BodyDeclaration> currBodyDeclarationList = JDTUtils.getCompilationUnitByJar(currJarPath, javaPath);
                        MethodDeclaration preMethod = JavaCallGraphJDTAdapter.searchMethod(invokeMethod, preBodyDeclarationList);
                        MethodDeclaration currMethod = JavaCallGraphJDTAdapter.searchMethod(invokeMethod, currBodyDeclarationList);
                        if (preMethod == null && currMethod == null) {
                            //都为空，都找不到
                            continue;
                        }
                        if (preMethod == null || currMethod == null) {
                            //一个空一个非空，视为发生改变
                            hasOutput = true;
                            //FileUtil.writeFlie(RESULT_PATH + "true_" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(true, 1)));
                            result.setChange(true);
                            resultList.add(result);
                            break;
                        }

                        //两个都非空，都能找到，比较方法体
                        Block preBlock = preMethod.getBody();
                        Block currBlock = currMethod.getBody();

                        if (preBlock == null && currBlock == null) {
                            continue;
                        }
                        if (preBlock == null || currBlock == null) {
                            //一个空一个非空，视为发生改变
                            hasOutput = true;
                            //FileUtil.writeFlie(RESULT_PATH + "true_" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(true, 1)));
                            result.setChange(true);
                            resultList.add(result);
                            break;
                        }
                        boolean same = preBlock.toString().equals(currBlock.toString());
                        if (same) {
                            continue;
                        } else {
                            hasOutput = true;
                            //FileUtil.writeFlie(RESULT_PATH + "true_" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(true, 1)));
                            result.setChange(true);
                            resultList.add(result);
                            break;
                        }
                    }
                    if (!hasOutput) {
                        //如果此时还没有输出，说明全部相同
                        hasOutput = true;
                        //FileUtil.writeFlie(RESULT_PATH + "false_" + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(new MethodResult(false, -1)));
                        result.setChange(false);
                        resultList.add(result);
                        break;
                    }
                    //resultList.add(result);
                }
            }
            FileUtil.writeFlie(RESULT_PATH + metaFile.getName(), new GsonBuilder().setPrettyPrinting().create().toJson(resultList));
        }

    }


    /**
     * 生成需要调查的方法
     *
     * @param prevMethodList
     * @param currMethodList
     * @return
     */
    private static NeedMethods initFinalList(List<String> prevMethodList, List<String> currMethodList) {
        NeedMethods needMethods = new NeedMethods();

        //加入条件：
        //curr中的方法，若在prev中存在，添加到commonList
        //若不在prev中存在，添加到uniqueList
        for (String currMethod : currMethodList) {
            if (prevMethodList.contains(currMethod)) {
                needMethods.addCommonMethod(currMethod);
            } else {
                needMethods.addUniqueMethod(currMethod);
            }
        }
        return needMethods;
    }

}
