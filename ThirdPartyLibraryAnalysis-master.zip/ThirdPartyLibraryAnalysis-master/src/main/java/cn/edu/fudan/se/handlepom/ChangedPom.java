package cn.edu.fudan.se.handlepom;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.maven.model.Dependency;
import org.apache.maven.model.Model;
import org.apache.maven.model.Plugin;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;

import cn.edu.fudan.se.git.JgitRepository;
import cn.edu.fudan.se.net.Client;
import net.sf.json.JSONObject;

public class ChangedPom extends ProjectPom{
	
	private String projectPath;
	private String fileModule = "";
	private String[] prefix;
	private String rootPrefix = "";
	private int level = 0;
	private JgitRepository repo;
	private String commitId;
	private Map<String,Map<String,String[]>> libVerPairsInParents= new HashMap<>();
	
	public Map<String,Map<String,String[]>> getLibVerPairs() {
		return this.libVerPairs;
	}
	
	public ChangedPom(String path,JgitRepository repo,String commitId) {
		this.projectPath = path;
		this.repo = repo;
		this.commitId = commitId;
	}
	
	public void pomDiff(String fileName) {
//		this.fileModule = fileName.substring(fileName.length()-8);
		int index = fileName.lastIndexOf("/");
		if(index >= 0)
			this.fileModule = "/"+fileName.substring(0,index);
		this.prefix = fileName.split("/");
//		for(int i =0;i<this.prefix.length;i++) {
//			System.out.println(this.prefix[i]);
//		}
		if(!prefix[prefix.length-1].equals("pom.xml")) {
			System.out.println("Not pom file error : "+fileName);
			return;
		}	
		try {
			InputStream is = this.repo.extract("pom.xml", this.commitId);
			if(is == null) {				
				for(int i = 0;i<this.prefix.length - 1;i++) {
					rootPrefix = rootPrefix +"/"+ this.prefix[i];
					if(rootPrefix.startsWith("/"))
						rootPrefix = rootPrefix.substring(1);
					is = this.repo.extract(rootPrefix+"/pom.xml", this.commitId);
					if(is != null) {
						is.close();
						break;
					}
				}
			}
			else {			
				is.close();			
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		parsePomFile(projectPath,null,false,false);
		getVersionFromPomLib();
//		System.out.println("++++++++++++++++++++++++++++"+pomPath);
//		readModel(model,path,module,isPomLib,isParent);		
		
	}
	
	@Override
	public void parsePomFile(String path,String module,boolean isPomLib,boolean isParent) {
		String pomPath = null;
		//new add to handle pom in local
		if(isPomLib) {
			pomPath = path;
			MavenXpp3Reader reader = new MavenXpp3Reader();

			Model model = null;
			try {
				FileReader fr = new FileReader(pomPath); 
				model = reader.read(fr);
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch (XmlPullParserException e) {
				// TODO Auto-generated catch block
				System.out.println("XmlPullParserException : error id : "+projectId);
				return;
			}       		
			if(model == null)
				return;		
			readModel(model,path,module,isPomLib,isParent);	
		}
		else {
			if(module == null)
				pomPath = rootPrefix + "/"+"pom.xml";
			else
				pomPath = rootPrefix + "/"+module+ "/" + "pom.xml";		
			while (pomPath.startsWith("/"))
				pomPath = pomPath.substring(1);
			InputStream is = this.repo.extract(pomPath, this.commitId);
			parsePomFile(is,path,module,isPomLib,isParent);	
		}			
	}	
	
	@Override
	public void readModel(Model model,String path,String module,boolean isPomLib,boolean isParent) {
		if(module == null) {
			this.level = 0;
		}
		//处理parent
		if(module == null && model.getParent() != null && !new File(model.getParent().getRelativePath()).exists()) {			
			String parentGroupId = model.getParent().getGroupId();
			String parentArtifactId = model.getParent().getArtifactId();
			String parentVersion = model.getParent().getVersion();
			handlePomType(parentGroupId,parentArtifactId,parentVersion,module,true,true);
		}
		
		if (model.getGroupId() != null && this.projectGroupId == null && !isPomLib && !isParent)
			this.projectGroupId = model.getGroupId();
		if (model.getVersion() != null && this.projectVersion == null && !isPomLib && !isParent)
			this.projectVersion = model.getVersion();		
		if (model.getGroupId() != null && isParent)
			this.parentProjectGroupId = model.getGroupId();	
		if (model.getArtifactId() != null && isParent)
			this.parentProjectArtifactId = model.getArtifactId();	
		if (model.getVersion() != null && isParent)
			this.parentProjectVersion = model.getVersion();	
		if(model.getProperties() != null)
			this.properties.putAll(model.getProperties());
		List<Dependency> dependencies = model.getDependencies();
		parseDependencyFromList(dependencies,module,"Dependency",model,isPomLib); 		
		if (model.getDependencyManagement() != null) {
			dependencies = model.getDependencyManagement().getDependencies();
			parseDependencyFromList(dependencies,module,"DependencyManagement",model,isPomLib);
		}

		if(!isPomLib && !isParent) {
			if(this.level < this.prefix.length - 1) {
				List<String> modules = model.getModules();
				for(int m = 0;m < modules.size();m++) {		
					if(modules.get(m).equals(this.prefix[this.level])) {
						if(module == null)
							parsePomFile(path,"/"+modules.get(m),false,false);
						else
							parsePomFile(path, module + "/"+modules.get(m),false,false);
						break;
					}
				}
				this.level ++;
			}	
		}					
	}
	
	@Override
	public void parseDependencyFromList(List list,String module,String information,Model model,boolean isPomLib) {
		for (int i = 0; i < list.size(); i++) {
			String groupId,artifactId,version,type = null;
			if(list.get(i) instanceof Plugin) {
				groupId = ((Plugin) list.get(i)).getGroupId();
				artifactId = ((Plugin) list.get(i)).getArtifactId();
				version = ((Plugin) list.get(i)).getVersion();
			}
			else if (list.get(i) instanceof Dependency) {
				groupId = ((Dependency) list.get(i)).getGroupId();
				artifactId = ((Dependency) list.get(i)).getArtifactId();
				version = ((Dependency) list.get(i)).getVersion();
				type = ((Dependency) list.get(i)).getType();
			}
			else 
				continue;	
			if (groupId != null && groupId.contains("${"))
				groupId = parseProperty(groupId,model);
			if (artifactId != null && artifactId.contains("${"))
				artifactId = parseProperty(artifactId,model);
			if (version != null && version.contains("${")) {				
				version = parseProperty(version,model);			
			}																			
			if(type != null) {
				if(type.equals("pom")) {
					handlePomType(groupId,artifactId,version,module,true,false);
				}
				else if(!type.equals("jar")){
					if(isPomLib)
						addToLibVerPairs(this.libVerPairsInPom, groupId +" "+artifactId+" "+type,version,module,information);
					else if((module==null && !this.fileModule.equals("")) || (module != null && !module.equals(this.fileModule)))
						addToLibVerPairs(this.libVerPairsInParents,groupId +" "+artifactId+" "+type,version,module,information);
					else
						addToLibVerPairs(this.libVerPairs,groupId +" "+artifactId+" "+type,version,module,information);
				}
			}
//			if(type == null || (type != null && type.equals("jar"))) {
				if (isPomLib)
					addToLibVerPairs(this.libVerPairsInPom, groupId + " " + artifactId, version, module, information);
				else if((module==null && !this.fileModule.equals("")) || (module != null && !module.equals(this.fileModule)))
					addToLibVerPairs(this.libVerPairsInParents,groupId +" "+artifactId,version,module,information);
				else
					addToLibVerPairs(this.libVerPairs, groupId + " " + artifactId, version, module, information);
//			}			
		}
	}

	private void getVersionFromPomLib() {
//		System.out.println(this.libVerPairsInParents.size());
//		System.out.println(this.libVerPairsInPom.size());
//		PomDiff.printLibs(libVerPairsInParents);
		for (Map.Entry<String, Map<String,String[]>> entry : this.libVerPairs.entrySet()) {
			String libStr = entry.getKey();
			for (Map.Entry<String, String[]> value : entry.getValue().entrySet()) {
				String version = value.getKey();
				String[] versionInfo = value.getValue();
				if(version == null) {
					boolean solved = false;
					if(this.libVerPairsInParents.get(libStr) != null) {
						for (Map.Entry<String, String[]> parentLib : this.libVerPairsInParents.get(libStr).entrySet()) {
							if(parentLib.getKey() != null) {
								String newVersion = parentLib.getKey();
								this.libVerPairs.get(libStr).put(newVersion, versionInfo);
								this.libVerPairs.get(libStr).remove(version);	
								solved = true;
								break;
							}
						}
					}	
					else if(!solved && this.libVerPairsInPom.get(libStr) != null) {
						for (Map.Entry<String, String[]> pomLib : this.libVerPairsInPom.get(libStr).entrySet()) {
							if(pomLib.getKey() != null) {
								String newVersion = pomLib.getKey();
								this.libVerPairs.get(libStr).put(newVersion, versionInfo);
								this.libVerPairs.get(libStr).remove(version);							
								break;
							}
						}
					}					
				}
			}			
		}
	}
}
