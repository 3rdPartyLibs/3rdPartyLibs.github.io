package cn.edu.fudan.se.cfg;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import soot.MethodOrMethodContext;
import soot.Scene;
import soot.SootClass;
import soot.SootMethod;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Targets;
import soot.options.Options;
import soot.util.Chain;
import soot.util.dot.DotGraph;

import java.util.Map;

import org.apache.commons.io.IOUtils;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;
public class SootInvoker {
	
	

	public static void main(String[] args) {
		String inputPath = "C:/Users/huangkaifeng/Desktop/RQ2";
		String decompileExecJarPath = "C:/Users/huangkaifeng/Desktop/SootExec/decompile_jar/jd-cmd-bin/jd-cli.jar";
		File f = new File(inputPath);
		File[] files = f.listFiles();
		List<String> shs = new ArrayList<>();

		//unzip
//		for(File tmp:files){
//			String sh = "unzip -o \""+decompileExecJarPath+"\" -d \"";
//			if(tmp.getAbsolutePath().endsWith(".jar")){
//				String newDirName = tmp.getName().substring(0,tmp.getName().length()-4)+"_extract";
//				File tmpDirFile = new File(inputPath+"/"+newDirName);
//				if(!tmpDirFile.exists()){
//					tmpDirFile.mkdirs();
//				}
//				sh+= inputPath+"/"+newDirName+"\" ";
//				System.out.println(sh);
//				shs.add(sh);
////				decompiledPath.add(tmp.getName().substring(0,tmp.getName().length()-4)+"_decompile");
//			}
//		}
//		for(String sh:shs){
////			String output = RunShell.execToString(sh);
//		}

		JSONObject jo = SootFileUtils.fromJsonText(inputPath+"/meta.txt");
		String prevJar = jo.getString("prev_jar");
		String currJar = jo.getString("curr_jar");
		JSONArray jaPrev = (JSONArray)jo.get("prev_api_call_list");
		JSONArray jaCurr = (JSONArray)jo.get("curr_api_call_list");
		invokeSoot(args,inputPath+'/'+prevJar.substring(0,prevJar.length()-4),jaPrev,inputPath+'/'+prevJar);
		invokeSoot(args,inputPath+'/'+currJar.substring(0,currJar.length()-4),jaCurr,inputPath+'/'+currJar);

	}
	


	public static HashMap defaultOpt(){
		HashMap opt = new HashMap();
		opt.put("enabled", "true");
		opt.put("verbose", "true");
		opt.put("ignore-types", "false");
		opt.put("force-gc", "false");
		opt.put("pre-jimplify", "false");
		opt.put("vta", "true");
		opt.put("rta", "true");
		opt.put("field-based", "false");
		opt.put("types-for-sites", "false");
		opt.put("merge-stringbuffer", "true");
		opt.put("string-constants", "false");
		opt.put("simulate-natives", "true");
		opt.put("simple-edges-bidirectional", "false");
		opt.put("on-fly-cg", "true");
		opt.put("simplify-offline", "false");
		opt.put("simplify-sccs", "false");
		opt.put("ignore-types-for-sccs", "false");
		opt.put("propagator", "worklist");
		opt.put("set-impl", "double");
		opt.put("double-set-old", "hybrid");
		opt.put("double-set-new", "hybrid");
		opt.put("dump-html", "false");
		opt.put("dump-pag", "false");
		opt.put("dump-solution", "false");
		opt.put("topo-sort", "false");
		opt.put("dump-types", "true");
		opt.put("class-method-var", "true");
		opt.put("dump-answer", "false");
		opt.put("add-tags", "false");
		opt.put("set-mass", "false");
		return opt;
	}

	
	public static void invokeSoot(String[] args,String classesPath,JSONArray methodNames,String outputPath){
		classesPath+="_unzip";
		CallGraphVisitor callGraphVisitor = new CallGraphVisitor(classesPath+".dot");
		List<String> classNames = new ArrayList<>();
		Map<String,List<String>> mmap = SootFileUtils.getClassNameAndMethodNames(methodNames,classNames);
//		String compiledClassPath = classesPath;
//		String clazzName ="org.main.Entrance";
//		String methodName ="a4";
		List<String> argsList = new ArrayList<>(Arrays.asList(args));
		argsList.addAll(Arrays.asList(new String[] { "-allow-phantom-refs", "-w",
				// "-no-bodies-for-excluded",
				"-cp", classesPath, "-process-dir",
				classesPath }));
		args = argsList.toArray(new String[0]);
		Options.v().parse(args);
		List<SootMethod> entryPoints = SootUtil.loadEntryPoints(classNames,mmap);
		Scene.v().setEntryPoints(entryPoints);
		Options.v().setPhaseOption("cg.spark", "on");
		HashMap opt = defaultOpt();
		// PackManager.v().runPacks();
		SparkTransformer.v().transform("", opt);
		CallGraph cg = Scene.v().getCallGraph();
		for(SootMethod entryPoint:entryPoints) {
			callGraphVisitor.visit(cg, entryPoint);
		}
		SootFileUtils.toFile(outputPath.substring(0,outputPath.length()-4)+"_dot.dot",callGraphVisitor.getDot());
	}






}
