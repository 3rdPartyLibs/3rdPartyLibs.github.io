package cn.edu.fudan.se.cfg.rq1.bean;

import java.util.List;

public class ClassField {

    public ClassField(String className, List<Field> fields, List<Method> methods) {
		super();
		this.className = className;
		this.fields = fields;
		this.methods = methods;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public List<Field> getFields() {
		return fields;
	}

	public void setFields(List<Field> fields) {
		this.fields = fields;
	}

	public List<Method> getMethods() {
		return methods;
	}

	public void setMethods(List<Method> methods) {
		this.methods = methods;
	}

	String className;
    List<Field> fields;
    List<Method> methods;
}