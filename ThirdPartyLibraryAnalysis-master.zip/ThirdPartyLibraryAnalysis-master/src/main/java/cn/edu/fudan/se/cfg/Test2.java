package cn.edu.fudan.se.cfg;

import cn.edu.fudan.se.util.JavaMethodUtil;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import java.io.InputStream;
import java.util.List;

public class Test2 {


    public static void main(String[] args) {
        //JavaMethodUtil.decompileJar("C:\\cs\\jar\\jmh-core-1.17.4.jar","D:\\cs\\");

        InputStream inputStream = JavaMethodUtil.readFileInputStream("D:\\cs\\jmh-core-1.17.4_decompile\\org\\openjdk\\jmh\\runner\\Action.java");
        try {
            CompilationUnit compilationUnit = JavaMethodUtil.getCompilationUnit("D:\\cs\\jmh-core-1.17.4_decompile\\org\\openjdk\\jmh\\runner\\Action.java");
            //接下来从两个unit中找到我们需要比对的方法，
            TypeDeclaration preType = (TypeDeclaration) compilationUnit.types().get(0);
            List<BodyDeclaration> bodyDeclarationList = preType.bodyDeclarations();
            for (BodyDeclaration bodyDeclaration : bodyDeclarationList) {
                if (bodyDeclaration instanceof MethodDeclaration) {
                    Method tempMethod = new Method((MethodDeclaration) bodyDeclaration);
                    int a = 1;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
