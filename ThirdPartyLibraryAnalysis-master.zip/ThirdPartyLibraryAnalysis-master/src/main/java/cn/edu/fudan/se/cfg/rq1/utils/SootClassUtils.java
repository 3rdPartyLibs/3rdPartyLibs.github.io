package cn.edu.fudan.se.cfg.rq1.utils;

import soot.G;
import soot.Scene;
import soot.SootClass;
import soot.options.Options;
import soot.util.HashChain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SootClassUtils {

    public static SootClass loadSootClass(String jarPath, String className, int index) {
        List<String> argsList = new ArrayList<>();
        if (index == 1) {
            G.reset();
            argsList.addAll(Arrays.asList(new String[]{"-allow-phantom-refs", "-w",
                    // "-no-bodies-for-excluded",
                    "-cp", jarPath, "-process-dir",
                    jarPath}));
            String[] arg = argsList.toArray(new String[0]);
            Options.v().parse(arg);
        }
        Scene.v().loadClassAndSupport(className);
        SootClass sootClass = Scene.v().getSootClass(className);

        return sootClass;
    }

}
