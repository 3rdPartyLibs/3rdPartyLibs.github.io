package cn.edu.fudan.se.git;

import java.util.List;

public class ProjectVersion {
    List<Bug> bugs;
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Bug> getBugs() {
        return bugs;
    }

    public void setBugs(List<Bug> bugs) {
        this.bugs = bugs;
    }

    public ProjectVersion() {

    }
}
