package cn.edu.fudan.se.cfg.rq2.utils;

import cn.edu.fudan.se.cfg.SootFileUtils;
import cn.edu.fudan.se.cfg.rq2.bean.Meta;
import cn.edu.fudan.se.cfg.rq2.bean.MethodList;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MetaMethodUtil {

    public static List<Meta> readMethodList(String metaPath){
        List<Meta> metas = new Gson().fromJson(FileUtil.read(metaPath), new TypeToken<List<Meta>>() {
        }.getType());
        return metas;
    }

    public static MethodList readMethodFromMeta(String metaPath) {
        //解析一个meta文件
        //JSONObject jo = SootFileUtils.fromJsonText(metaPath);
        Meta meta = new Gson().fromJson(FileUtil.read(metaPath), new TypeToken<Meta>() {
        }.getType());
        String prevJar = meta.getPrev_jar();
        String currJar = meta.getCurr_jar();
       // JSONArray jaPrevArray = (JSONArray) jo.get("prev_api_call_list");
        //JSONArray jaCurrArray = (JSONArray) jo.get("curr_api_call_list");

        List<String> prevMethodStringList = meta.getPrev_api_call_list();
        List<String> currMethodStringList = meta.getCurr_api_call_list();

        return new MethodList(prevMethodStringList, currMethodStringList, prevJar, currJar);

    }

    public static List<MethodList> getMethodList(List<Meta> metas){
        List<MethodList> methodLists = new ArrayList<>();
        MethodList methodList;
        for (Meta meta:metas){
           methodList =  new MethodList(meta.getPrev_api_call_list(), meta.getCurr_api_call_list(), meta.getPrev_jar()  , meta.getCurr_jar());
            methodLists.add(methodList);
        }
        return methodLists;
    }

}
