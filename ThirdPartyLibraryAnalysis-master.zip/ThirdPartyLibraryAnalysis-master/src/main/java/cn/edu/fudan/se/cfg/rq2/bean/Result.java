package cn.edu.fudan.se.cfg.rq2.bean;

public class Result {

    String prevJar;
    String currJar;
    boolean change;

    public String getPrevJar() {
        return prevJar;
    }

    public void setPrevJar(String prevJar) {
        this.prevJar = prevJar;
    }

    public String getCurrJar() {
        return currJar;
    }

    public void setCurrJar(String currJar) {
        this.currJar = currJar;
    }

    public boolean isChange() {
        return change;
    }

    public void setChange(boolean change) {
        this.change = change;
    }

    public Result() {

    }

    public Result(String prevJar, String currJar, boolean change) {

        this.prevJar = prevJar;
        this.currJar = currJar;
        this.change = change;
    }
}
