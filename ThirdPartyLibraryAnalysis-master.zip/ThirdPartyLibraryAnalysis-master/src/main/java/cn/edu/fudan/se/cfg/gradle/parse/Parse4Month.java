package cn.edu.fudan.se.cfg.gradle.parse;

import cn.edu.fudan.se.cfg.gradle.parse.bean.GradleFile;
import cn.edu.fudan.se.cfg.gradle.parse.utils.GradleUtils;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Parse4Month {
    private static final String SOURCE_PATH = "D:/wangying/rq2/four_month.txt";

    public static void main(String[] args) {

//        String content = FileUtil.read(SOURCE_PATH);
//        Map<String, String> map = new HashMap<>();
//        map = new Gson().fromJson(content, map.getClass());
//
//        for (Map.Entry<String, String> entry : map.entrySet()) {
//            String id = entry.getKey();
//            String projectName = entry.getValue();
//
//            System.out.println("parse " + file.getName());
//            String path = file.getAbsolutePath();
////                if (new File(OUTPUT_DIR + file.getName()).exists()) {
////                    continue;
////                }
//            try {
//                parseCommit(file.getName(), path);
//            } catch (Exception e) {
//                String message = e.getMessage();
//                FileUtil.writeFlie(ERROR_DIR + file.getName() + ".txt", message == null ? "" : message);
//                e.printStackTrace();
//            }
//        }
//    }
//
///**
// * 解析单个commit tree
// *
// * @param projectName
// * @param projectPath
// */
//    private static void parseCommit(String projectName, String projectPath) {
//
//        List<GradleFile> gradleFileList = GradleUtils.getAllGradleFiles(projectPath);
//        if (gradleFileList == null) {
//            //FileUtil.writeFlie(MAVEN_DIR + projectName + ".txt", "");
//            return;
//        }
//        int size = gradleFileList.size();
//        if (size == 0) {
//            //FileUtil.writeFlie(MAVEN_DIR + projectName + ".txt", "");
//            return;
//        }
//        boolean isAllProperties = isAllProperties(gradleFileList);
//        if (isAllProperties) {
//            System.out.println("all properties"+String.valueOf(projectName));
//            System.out.println(OUTPUT_DIR + projectName + ".txt");
//            File file = new File(OUTPUT_DIR + projectName + ".txt");
//            file.delete();
//            //FileUtil.writeFlie(MAVEN_DIR + projectName + ".txt", "");
//            return;
//        }
//        *//*for (int gradleFileIndex = 0; gradleFileIndex < size; gradleFileIndex++) {
//            GradleFile gradleFile = gradleFileList.get(gradleFileIndex);
//            if (gradleFile.getType().equals("build.gradle")) {
//                ParseUtil.parse(gradleFile.getContent(), gradleFile.getPath());
//            } else if (gradleFile.getType().endsWith("properties")) {
//                ParseUtil.parseProperties(gradleFile.getPath());
//            }
//        }
//        ParseUtil.replaceDependencyValue();
//        ParseUtil.replaceDependencyValue();
//        ParseUtil.clearDependencyValue();
//        List<String> dependencies = ParseUtil.getDependencies();
//
//        handleDependency(projectName, dependencies);
//        ParseUtil.clearDependencies();
//        ParseUtil.clearDependencyValue();
//    }
    }

}
