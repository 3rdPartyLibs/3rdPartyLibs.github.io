package cn.edu.fudan.se.api;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import cn.edu.fudan.se.db.DB;
import cn.edu.fudan.se.util.MyException;
import net.sf.json.JSONObject;


public class JarAnalyzer1 {
//	private Map<String,List<String>> apiList = new HashMap<>();
	
	public static void main(String args[]) {
		JarAnalyzer1 ja = new JarAnalyzer1();
		ja.analyzeJarFromDb(1);
	}	
	
	public void analyzeJarFromDb(int typeId) {
		Map<String,List<String>> apiList = new HashMap<>();
		ResultSet rs = DB.query("SELECT * FROM `version_types` where `type_id`=" + typeId);
		try {
			while (rs.next()) {
				String packagePath = "F:/GP/lib/"+rs.getString("jar_package_url");
				if(packagePath != null && packagePath.endsWith(".jar")) {
					File jarFile = load(packagePath);
					try {
			        	parseJarFile(apiList,jarFile,typeId);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
//					printApiList(apiList);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private File load(String jarPath) {
        File file = new File(jarPath);
        Method method = null;
        try {
            method = URLClassLoader.class.getDeclaredMethod("addURL", URL.class);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        boolean accessible = method.isAccessible();     // 获取方法的访问权限
        try {
            if (accessible == false) {
                method.setAccessible(true);     // 设置方法的访问权限
            }
            // 获取系统类加载器
            URLClassLoader classLoader = (URLClassLoader) ClassLoader.getSystemClassLoader();
            URL url = file.toURI().toURL();
            try {
                method.invoke(classLoader, url);
            } catch (Exception e) {
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } finally {
            method.setAccessible(accessible);
        }
        return file;
    }
	
	public void printApiList(Map<String,List<String>> apiList) {
		for (Map.Entry<String, List<String>> entry : apiList.entrySet()) {
			String importClass = entry.getKey();
			System.out.println("+++++++++++++++++++++"+importClass);
			List<String> apis = entry.getValue();
			for (String api : apis) {
				System.out.println(api);
			}			
		}
	}	
	
	public List<Class> parseJarFile(Map<String,List<String>> apiList,File file,int versionTypeId) throws IOException {
        JarFile jarFile = new JarFile(file);

        List<Class> clazzs = new ArrayList<Class>();
        List<JarEntry> jarEntryList = new ArrayList<JarEntry>();
        Enumeration<JarEntry> entries = jarFile.entries();
        
        List<String> apis = new ArrayList<>();

        while (entries.hasMoreElements()) {
            JarEntry entry = entries.nextElement();
            if (entry.getName().endsWith(".class")) {
                jarEntryList.add(entry);
            }
        }        
        for (int i = 0; i < jarEntryList.size(); i++) {
            JarEntry entry = jarEntryList.get(i);
            String className = entry.getName().replace('/', '.');
            className = className.substring(0, className.length() - 6);// .class
            if(!className.equals("com.actionbarsherlock.widget.ShareActionProvider"))
            	continue;
            try {
                if(!isMemberOrAnonymousClass(className)) {
                    if(apiList.containsKey(className)) {//去重
                    }
                    else{
//                    	String sql = "INSERT INTO api_classes(version_type_id,class_name) VALUES ("+ versionTypeId + ",\'" + className + "\')";
//    					DB.update(sql);
//    					int classId=-1;
//    					ResultSet rs = DB.query("select LAST_INSERT_ID()");
//    					if (rs.next())
//    						classId = rs.getInt(1);
                        Class c = null;
                        c = Thread.currentThread().getContextClassLoader().loadClass(className);
                        System.out.println(className);
                        if(c !=null && !c.isInterface() && !Modifier.isAbstract(c.getModifiers())) {
                            clazzs.add(c);
                            Method[] method = c.getDeclaredMethods();
                            for (Method m: method) {
                                if(Modifier.isPublic(m.getModifiers())){
                                	String[] s = m.toString().split(" ");
                                	apis.add(s[s.length-1]);
                                	System.out.println(s[s.length-1]);
//                                	sql = "INSERT INTO api_interface(class_id,name,remark) VALUES ("+ classId + ",\'" + s[s.length-1] + "\', 'method')";
//                					DB.update(sql);
                                }
                            }
                            Field[] fields = c.getDeclaredFields();
                            for (Field f: fields) {
                                if(Modifier.isPublic(f.getModifiers())){
                                	apis.add(f.getName());
                                	System.out.println(f.getName());
//                                	sql = "INSERT INTO api_interface(class_id,name,remark) VALUES ("+ classId + ",\'" + f.getName() + "\', 'field')";
//                					DB.update(sql);
                                }
                            }
                            apiList.put(className, apis);
                        }
                    }
                }
            } catch (IncompatibleClassChangeError | VerifyError | ClassFormatError | NoClassDefFoundError | Exception e){
                 e.printStackTrace();
            }
        }
        return clazzs;
    }
	private int insertApiClass(int versionTypeId,String className) {
		String sql = "INSERT INTO api_classes(version_type_id,class_name) VALUES ("+ versionTypeId + ",\'" + className + "\')";
		DB.update(sql);
		int classId=-1;
		ResultSet rs = DB.query("select LAST_INSERT_ID()");
		try {
			if (rs.next())
				classId = rs.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return classId;
	}
	
	private boolean isMemberOrAnonymousClass(String className) {
        String result = className;
        if(className.lastIndexOf(".") >= 0) {
            result = result.substring(className.lastIndexOf("."), className.length());
        }
        if (result.contains("$")) {
            return true;
        }
        return false;
    }
}

