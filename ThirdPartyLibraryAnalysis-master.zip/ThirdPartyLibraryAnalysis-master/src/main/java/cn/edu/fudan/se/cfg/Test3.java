package cn.edu.fudan.se.cfg;

public class Test3 {
    public static final int TEST = 1;

    public static void main(String[] args) {
        String s = "ab";
        String[] a = s.split("ab");
        int b = 1;
    }

    private static int a() {
        return TEST;
    }
}
