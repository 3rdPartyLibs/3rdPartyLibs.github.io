package cn.edu.fudan.se.cfg.rq2.bean;

import java.util.List;

public class MethodList {

    List<String> prevList;
    List<String> currList;
    String prevJar;
    String currJar;

    public List<String> getPrevList() {
        return prevList;
    }

    public void setPrevList(List<String> prevList) {
        this.prevList = prevList;
    }

    public List<String> getCurrList() {
        return currList;
    }

    public void setCurrList(List<String> currList) {
        this.currList = currList;
    }

    public MethodList() {

    }

    public String getPrevJar() {
        return prevJar;
    }

    public void setPrevJar(String prevJar) {
        this.prevJar = prevJar;
    }

    public String getCurrJar() {
        return currJar;
    }

    public void setCurrJar(String currJar) {
        this.currJar = currJar;
    }

    public MethodList(List<String> prevList, List<String> currList, String prevJar, String currJar) {
        this.prevList = prevList;
        this.currList = currList;
        this.prevJar = prevJar;
        this.currJar = currJar;
    }
}
