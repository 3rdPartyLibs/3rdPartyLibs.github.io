package cn.edu.fudan.se.cfg.gradle.parse.utils;

import cn.edu.fudan.se.cfg.gradle.parse.bean.LibObj;
//import cn.edu.fudan.se.cfg.gradle.parse.bean.Project;

import java.util.Set;

public class Adapter {

  /*  public static LibObj project2LibObj(Project project) {


        return null;
    }*/

}
