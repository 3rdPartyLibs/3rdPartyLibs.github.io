package cn.edu.fudan.se.statistics;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import com.alibaba.fastjson.JSONArray;

import cn.edu.fudan.se.util.FileUtil;
import cn.edu.fudan.se.util.JsonFileUtil;

public class ApiCall {

	public static void readProjCall() {
		String dir = "C:/Users/yw/Desktop/sun/call";
		String[] files = new File(dir).list();
		for(String file:files) {
			String content = JsonFileUtil.readJsonFile(dir+"/"+file);
			JSONArray array = JSONArray.parseArray(content);
			for(int i = 0; i < array.size() - 1; i++) {
				System.out.println(array.getString(i));
			}
			break;
		}
	}
	
	public static void errorRate() {
		int count = 0;
		int error = 0,total = 0;
//		String dir = "J:/project_call/call";
//		String dir = "D:/data/call";
//		String dir = "E:\\project_call\\5_ZW\\call"; 
		String dir = "E:\\project_call\\3_lj\\call";
		String[] files = new File(dir).list();
		for(String file:files) {
			//1971(308) 1982(472) 1992(51) 1996(162) 2004(4501) 2016(35) 2028(119) 2030(62) 2056(367) 2059(41) 2061(120) 2065(139) 2066(187) 2077(126) 2086(1062)
//			if(file.startsWith("1982_")) {				
			System.out.println(file);
			try {
				String content = JsonFileUtil.readJsonFile(dir+"/"+file);
				JSONArray array = JSONArray.parseArray(content);
				String[] numStr = array.getString(array.size()-1).split(" ");
				int errorNum = Integer.parseInt(numStr[0]);
				int totalNum = Integer.parseInt(numStr[1]);
				error += errorNum;
				total += totalNum;
				count ++;
			}catch(com.alibaba.fastjson.JSONException e) {
				System.out.println("JSONException:" + file);
			}catch(java.lang.NullPointerException e) {
				System.out.println("NullPointerException:" + file);
			}
			
//			}
//			break;
		}
		System.out.println(count);
		System.out.println(error + " " + total + " " + (float)error/total);
	}
	
	public static void handleUnsolvedCmd() {
		int count = 0;
		String dir = "E:\\project_call\\9_huangkaifeng\\";
		try {
			Scanner in = new Scanner(new File(dir+"unsolved_cmd.txt"));
			while (in.hasNextLine()) {
				String str = in.nextLine();
				str = str.substring(0,str.indexOf(" D:/wangying/call/"));

				String[] list = str.split(" ");
				int num1 = Integer.parseInt(list[list.length-2]);
				int num2 = Integer.parseInt(list[list.length-1]);
				count += num2-num1;
				System.out.println(str+":"+num1+" "+num2);
				for(int i=num1;i<num2;i++) {
					String newCmd = "java -jar apicallvalidator.jar "+list[list.length-3];
					newCmd += " "+i+" " +(i+1);
					System.out.println("+++++++++++++ " +newCmd);
					FileUtil.appendFile(dir+"new_cmd.sh", newCmd);
				}
//				break;
			}
			in.close();
			System.out.println(count);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		handleUnsolvedCmd();
//		readProjCall();
//		errorRate();
//		System.out.println((float)(1750966+2442705+1675644+1495420+1089280+521243+1260175+1378465+4157080+972927)/(6838890+6097799+3516327+3287448+2820570+1465686+3761949+4993809+11154178+4266933));
	}
}
