package cn.edu.fudan.se.cfg.gradle.parse.bean;

import java.util.HashSet;
import java.util.Set;

public class LibObj {
    Set<String> versions_array;
    Set<String> repo_array;
    String lib_name;

    public Set<String> getVersions_array() {
        return versions_array;
    }

    public void setVersions_array(Set<String> versions_array) {
        this.versions_array = versions_array;
    }

    public Set<String> getRepo_array() {
        return repo_array;
    }

    public void setRepo_array(Set<String> repo_array) {
        this.repo_array = repo_array;
    }

    public String getLib_name() {
        return lib_name;
    }

    public void setLib_name(String lib_name) {
        this.lib_name = lib_name;
    }

    public LibObj() {

    }

    public LibObj(String lib_name) {
        this.lib_name = lib_name;
        versions_array = new HashSet<>();
    }

    public LibObj(Set<String> versions_array, Set<String> repo_array, String lib_name) {

        this.versions_array = versions_array;
        this.repo_array = repo_array;
        this.lib_name = lib_name;
    }
}
