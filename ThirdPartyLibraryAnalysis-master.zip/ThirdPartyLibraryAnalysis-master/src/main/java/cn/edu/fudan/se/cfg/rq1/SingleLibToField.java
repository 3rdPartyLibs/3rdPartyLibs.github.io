package cn.edu.fudan.se.cfg.rq1;

import cn.edu.fudan.se.cfg.ZipUtil;
import cn.edu.fudan.se.cfg.rq1.bean.ClassField;
import cn.edu.fudan.se.cfg.rq1.bean.Field;
import cn.edu.fudan.se.cfg.rq1.bean.Method;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import soot.*;
import soot.jimple.spark.SparkTransformer;
import soot.options.Options;
import soot.util.Chain;
import soot.util.HashChain;

import java.io.File;
import java.util.*;

public class SingleLibToField {
    static final String BASE = "H:\\wangying\\rq1/activemq-broker.jar";
    private static List<SootClass> sootClassList = null;
    static final String UNZIP_PATH = "D:\\cs\\jar\\unzip/";//解压jar包的目录路径

    public static void main(String[] args) {
//        String jarName = args[0];
//        File errorFile = new File("F:\\wy\\lib_field_plus\\error\\" + jarName + ".txt");
//        if (errorFile.exists()) {
//            return;
//        }
//        File exceptionFile = new File("F:\\wy\\lib_field_plus\\exception\\" + jarName + ".txt");
//        if (exceptionFile.exists()) {
//            return;
//        }
//        File normalFile = new File("F:\\wy\\lib_field_plus\\lib_field\\" + jarName + ".json");
//        if (normalFile.exists()) {
//            return;
//        }
        try {
            libToFields(BASE, "activemq-broker.jar");
        } catch (Exception e) {
            System.out.println("catch exception");
            e.printStackTrace();
            File temp = new File("exception");
            if (!temp.exists()) {
                temp.mkdirs();
            }
            // FileUtil.writeFlie("F://wy//lib_field_plus//exception//" + jarName + ".json", "");
        } catch (Error error) {
            error.printStackTrace();
            System.out.println("catch error");
            File temp = new File("error");
            if (!temp.exists()) {
                temp.mkdirs();
            }
        }
//            // FileUtil.writeFlie("F://wy//lib_field_plus//error//" + jarName + ".json", "");
//        }


    }

    /**
     * 给定一个jar包的路径，生成一个json文件存储其中的fields
     * <p>
     * 首先解压得到class文件
     *
     * @param path jar包路径
     */
    private static void libToFields(String path, String jarName) {
        //解压缩的路径
        sootClassList = new ArrayList<>();
        List<ClassField> result = new ArrayList<>();
        System.out.print(jarName + "unzip start    ");
        String unZipDir = unzipJar(path, jarName);
        System.out.println(jarName + "unzip finish    ");
        init(unZipDir);
        for (SootClass sootClass : sootClassList) {
            List<Field> sootFieldList = new ArrayList<>();
            List<Method> sootMethodList = new ArrayList<>();
            Chain<SootField> sootFields = sootClass.getFields();
            List<SootMethod> sootMethods = sootClass.getMethods();
            if (sootFields instanceof HashChain) {
                Iterator<SootField> iterator = sootFields.iterator();
                while (iterator.hasNext()) {
                    SootField temp = iterator.next();
                    sootFieldList.add(new Field(temp.getType().toString(), temp.getName(), 1));
                }
            } else {

            }
            for (SootMethod sootMethod : sootMethods) {
                sootMethodList.add(new Method(sootMethod.toString(), sootMethod.getModifiers()));
            }

            result.add(new ClassField(sootClass.getName(), sootFieldList, sootMethodList));
        }
        File file = new File("I:\\rq1_output\\test\\");
        if (!file.exists()) {
            file.mkdirs();
        }
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        FileUtil.writeFlie("I:\\rq1_output\\test\\" + jarName + ".json", gson.toJson(result));
        removeDir(unZipDir);
    }

    /**
     * delete Dir
     *
     * @param unZipDir
     */
    private static void removeDir(String unZipDir) {
        System.out.println(unZipDir + "remove start");
        delFolder(unZipDir); //删除完里面所有内容
        System.out.println(unZipDir + "remove end");
    }

    //param folderPath 文件夹完整绝对路径
    public static void delFolder(String folderPath) {
        try {
            delAllFile(folderPath); //删除完里面所有内容
            String filePath = folderPath;
            filePath = filePath.toString();
            java.io.File myFilePath = new java.io.File(filePath);
            myFilePath.delete(); //删除空文件夹
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //删除指定文件夹下所有文件
//param path 文件夹完整绝对路径
    public static boolean delAllFile(String path) {
        boolean flag = false;
        File file = new File(path);
        if (!file.exists()) {
            return flag;
        }
        if (!file.isDirectory()) {
            return flag;
        }
        String[] tempList = file.list();
        File temp = null;
        for (int i = 0; i < tempList.length; i++) {
            if (path.endsWith(File.separator)) {
                temp = new File(path + tempList[i]);
            } else {
                temp = new File(path + File.separator + tempList[i]);
            }
            if (temp.isFile()) {
                temp.delete();
            }
            if (temp.isDirectory()) {
                delAllFile(path + "/" + tempList[i]);//先删除文件夹里面的文件
                delFolder(path + "/" + tempList[i]);//再删除空文件夹
                flag = true;
            }
        }
        return flag;
    }

    private static String unzipJar(String preJarPath, String jarName) {
        String newPath = UNZIP_PATH + jarName.substring(0, jarName.length() - 4) + "_unzip";
        File ff = new File(newPath);
        if (!ff.exists()) {
            ZipUtil.zip(preJarPath, newPath);
        }
        return newPath;
    }


    public static void init(String classesPath) {
        G.reset();
        List<String> argsList = new ArrayList<>();
        //
        argsList.addAll(Arrays.asList(new String[]{"-allow-phantom-refs", "-w",
                // "-no-bodies-for-excluded",
                "-cp", classesPath, "-process-dir",
                classesPath}));
        String[] args = argsList.toArray(new String[0]);
        Options.v().parse(args);
        Options.v().set_src_prec(Options.src_prec_java);
        //Options.v().set_process_dir(Collections.singletonList(classesPath));
        Options.v().set_whole_program(true);
        Options.v().set_allow_phantom_refs(true);

//        Options.v().set_verbose(true);
        Options.v().set_output_format(Options.output_format_none);
        Options.v().setPhaseOption("cg.spark", "on");
        Options.v().set_no_bodies_for_excluded(true);
//        Options.v().set_app(true);
       // enableSpark();
        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
        Scene scene = Scene.v();
        HashChain<SootClass> sootClasses = (HashChain<SootClass>) scene.getApplicationClasses();
        Iterator<SootClass> iterator = sootClasses.iterator();
        while (iterator.hasNext()) {
            SootClass sootClass = iterator.next();
            sootClassList.add(sootClass);
        }
    }

    private static void enableSpark() {
        HashMap opt = new HashMap();
        opt.put("verbose", "true");
        opt.put("propagator", "worklist");
        opt.put("simple-edges-bidirectional", "false");
        opt.put("on-fly-cg", "true");
        opt.put("apponly", "true");
        opt.put("set-impl", "double");
        opt.put("double-set-old", "hybrid");
        opt.put("double-set-new", "hybrid");
        SparkTransformer.v().transform("", opt);
    }

}
