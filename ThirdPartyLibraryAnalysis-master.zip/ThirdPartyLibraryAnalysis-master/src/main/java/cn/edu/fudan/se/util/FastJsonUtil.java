package cn.edu.fudan.se.util;

import java.io.FileWriter;
import java.io.IOException;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class FastJsonUtil {
	public static void writeJson(String savePath, JSONArray array) {
		try {
			FileWriter f = new FileWriter(savePath);
			f.write(array.toString());// 写入
			f.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void writeJson(String savePath, JSONObject obj) {
		try {
			FileWriter f = new FileWriter(savePath);
			f.write(obj.toString());// 写入
			f.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void writeJsonString(String savePath, String obj) {
		try {
			FileWriter f = new FileWriter(savePath);
			f.write(obj);// 写入
			f.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
