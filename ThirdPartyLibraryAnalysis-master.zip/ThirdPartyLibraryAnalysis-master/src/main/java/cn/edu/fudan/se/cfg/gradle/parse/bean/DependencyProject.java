package cn.edu.fudan.se.cfg.gradle.parse.bean;

public class DependencyProject {
    String project;

    public DependencyProject() {
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public DependencyProject(String project) {

        this.project = project;
    }
}
