package cn.edu.fudan.se.cfg.rq2.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MapUtils {

    public static boolean compare(Map<String, List<String>> map1, Map<String, List<String>> map2) {
        int size1 = map1.size();
        int size2 = map2.size();

        for (Map.Entry<String, List<String>> map1Entry : map1.entrySet()) {
            String key1 = map1Entry.getKey();
            List<String> value1 = map1Entry.getValue();
            if (map2.containsKey(key1)) {
                //map2中存在key1则比较value，否则返回false
                List<String> value2 = map2.get(key1);
                boolean listSame = compare(value1, value2);
                if (!listSame) {
                    return false;
                }
            } else {
                return false;
            }
        }
        return true;
    }

    /**
     * 比较list
     *
     * @param list1
     * @param list2
     * @return
     */
    private static boolean compare(List<String> list1, List<String> list2) {

        if (list1 == null && list2 == null) {
            return true;
        }
        if (list1 == null || list2 == null) {
            //一个为空一个不为空
            return false;
        }

        //数量不同
        int size1 = list1.size();
        int size2 = list2.size();
        if (size1 != size2) {
            return false;
        }

        //内容不同
        for (String s : list1) {
            if (!list2.contains(s)) {
                return false;
            }
        }
        return true;
    }

    public static List<String> invokeMapToList(Map<String, List<String>> invokeMap) {
        List<String> methods = new ArrayList<>();

        for (Map.Entry<String, List<String>> mapEntry : invokeMap.entrySet()) {
            String key = mapEntry.getKey();
            methods.add(key);
        }
        return methods;
    }


}
