package cn.edu.fudan.se.statistics;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.edu.fudan.se.db.DB;
import cn.edu.fudan.se.util.FastJsonUtil;
import cn.edu.fudan.se.util.JsonFileUtil;

public class Tool {

	public static void getLibNameListOfProj(int projectId) {
		List<String> libList = new ArrayList<>();
		ResultSet rs = DB.query("SELECT * FROM `project_lib_usage` where `project_id`=" + projectId);
		try {
			while (rs.next()) {
				int versionTypeId = rs.getInt("version_type_id");
				ResultSet trs = DB.query("SELECT * FROM `version_types` where `type_id`=" + versionTypeId);
				while (trs.next()) {
					String packageUrl = trs.getString("jar_package_url");
					if(packageUrl.endsWith(".jar"))
						libList.add(packageUrl);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(0);
		}
		
		JSONArray result = JSONArray.parseArray(JSON.toJSONString(libList));
		FastJsonUtil.writeJson("C:/lib_list/"+projectId+".json", result);
	}
	
	public static void main(String[] args) {
//		List<Integer> ids = new ArrayList<>();
//		ResultSet rs = DB.query("SELECT distinct(project_id) FROM `project_lib_usage`");
//		try {
//			while (rs.next()) {
//				int id = rs.getInt("project_id");
//				ids.add(id);
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			System.exit(0);
//		}
//		System.out.println(ids.size());
//		for(int projectId:ids) {
//			getLibNameListOfProj(projectId);
//		}
//		String content = JsonFileUtil.readJsonFile("C:/lib_list/2.json");
//		JSONArray array = JSON.parseArray(content);
//		for(int i=0;i<array.size();i++) {
//			System.out.println(array.getString(i));
//		}
		
//		String content = JsonFileUtil.readJsonFile("proj_in_usage.txt");
//		JSONArray array = JSONArray.parseArray(content);
//		System.out.println(array.size());
//		for(int i =0;i<array.size();i++) {
//			JSONObject obj = array.getJSONObject(i);
//			int projectId = obj.getInteger("id");
//			String localAddr = obj.getString("local_addr");
//			if(!new File("G:\\project_call\\batch\\"+projectId+".sh").exists()) {
//				System.out.println(projectId+":"+localAddr);
//			}
//		}
		
		checkJar();
	}
	
	public static void checkJar() {
		List<String> total = new ArrayList<>();
		try {
			Scanner in = new Scanner(new File("C:\\0.txt"));
			while (in.hasNextLine()) {
				String str = in.nextLine();
				String[] info = str.split(" ");
				String jarName = info[info.length-1];
//				System.out.println(jarName);
				total.add(jarName);
			}
			in.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(0);
		}
		System.out.println(total.size());
		
		List<String> result = new ArrayList<>();
		String dir = "C:\\lib_list";
		String[] files = new File(dir).list();		
		
		for(String f:files) {
			String content = JsonFileUtil.readJsonFile(dir + "/" + f);
			JSONArray array = JSON.parseArray(content);
			for(int i=0;i<array.size();i++) {
				String jar = array.getString(i);
				if(!total.contains(jar)) {
					if(!result.contains(jar)) {
						result.add(jar);
						System.out.println(jar);
					}
						
				}
			}
		}
		System.out.println(result.size());
	}
	
}
