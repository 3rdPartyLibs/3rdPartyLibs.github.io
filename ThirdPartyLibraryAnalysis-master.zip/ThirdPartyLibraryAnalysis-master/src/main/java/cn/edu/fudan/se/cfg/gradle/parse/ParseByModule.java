package cn.edu.fudan.se.cfg.gradle.parse;

import cn.edu.fudan.se.cfg.gradle.parse.bean.*;
import cn.edu.fudan.se.cfg.gradle.parse.utils.GradleUtils;
import cn.edu.fudan.se.cfg.gradle.parse.utils.ParseUtil2;
import cn.edu.fudan.se.cfg.rq1.bean.DependencyLib;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.util.List;

public class ParseByModule {

    private static final String projs = "H:/wangying/rq1/projs8.11.json";
    //private static final String projs = "H:/wangying/rq1/test.json";
    private static final String DIR = "I:\\RQ3\\projects\\";
    private static final String OUTPUT_DIR = "I://rq1_output\\normal//";
    private static final String ERROR_DIR = "I://rq1_output\\error/";
    //private static final String MAVEN_DIR = "I://rq1_output\\rq3_dependency_maven//";

    public static void main(String[] args) {

        String content = FileUtil.read(projs);
        List<ProjInfo> projInfos = new Gson().fromJson(content, new TypeToken<List<ProjInfo>>() {
        }.getType());

        for (ProjInfo projInfo : projInfos) {

            if (projInfo.getPath().contains("gradle")) {
                String url = projInfo.getUrl();
                System.out.println(url);
                String[] urls = url.split("/");
                String groupId = urls[urls.length - 2];
                String artifactId = urls[urls.length - 1];
                File existFile = new File(OUTPUT_DIR + groupId + "__fdse__" + groupId + ".txt");
                if (existFile.exists()) {
                    continue;
                }
                try {
                    parseCommit(groupId + "__fdse__" + artifactId, "I:/projects/" + groupId + "__fdse__" + artifactId);
                } catch (Exception e) {
                    e.printStackTrace();
                    FileUtil.writeFlie(ERROR_DIR + groupId + "__fdse__" + artifactId + ".txt", "");
                }
            }

        }
    }

    /**
     * 解析单个commit tree
     *
     * @param projectName
     * @param projectPath
     */
    private static void parseCommit(String projectName, String projectPath) {

        List<GradleFile> gradleFileList = GradleUtils.getAllGradleFiles(projectPath);
        if (gradleFileList == null) {
            //FileUtil.writeFlie(MAVEN_DIR + projectName + ".txt", "");
            return;
        }
        int size = gradleFileList.size();
        if (size == 0) {
            //FileUtil.writeFlie(MAVEN_DIR + projectName + ".txt", "");
            return;
        }
        boolean isAllProperties = isAllProperties(gradleFileList);
        if (isAllProperties) {
            System.out.println("all properties" + String.valueOf(projectName));
            System.out.println(OUTPUT_DIR + projectName + ".txt");
            File file = new File(OUTPUT_DIR + projectName + ".txt");
            file.delete();
            //FileUtil.writeFlie(MAVEN_DIR + projectName + ".txt", "");
            return;
        }
        for (int gradleFileIndex = 0; gradleFileIndex < size; gradleFileIndex++) {
            GradleFile gradleFile = gradleFileList.get(gradleFileIndex);
            if (gradleFile.getType().equals("build.gradle")) {
                ParseUtil2.parse(gradleFile.getContent(), gradleFile.getPath());
            } else if (gradleFile.getType().endsWith("properties")) {
                ParseUtil2.parseProperties(gradleFile.getPath());
            }
        }
        ParseUtil2.replaceDependencyValue();
        ParseUtil2.replaceDependencyValue();
        ParseUtil2.replaceDependencyValue();
        ParseUtil2.replaceDependencyValue();
        ParseUtil2.clearDependencyValue();
        List<Dependency2> dependencies = ParseUtil2.getDependencies();

        handleDependency(projectName, dependencies);
        ParseUtil2.clearDependencies();
        ParseUtil2.clearDependencyValue();
    }

    private static boolean isAllProperties(List<GradleFile> gradleFileList) {
        for (GradleFile gradleFile : gradleFileList) {
            if (!gradleFile.getPath().endsWith(".properties")) {
                return false;
            }
        }
        return true;
    }

    /**
     * 处理结果
     *
     * @param projectName
     * @param dependencies
     */
    private static void handleDependency(String projectName, List<Dependency2> dependencies) {
        //Set<String> dependenciesSet = new HashSet<>(dependencies);
        Project2 project = new Project2();
        DependencyProject dependencyProject;
        DependencyLib dependencyLib;
        DependencyUrl dependencyUrl;

        for (Dependency2 s : dependencies) {
            if (s == null || s.getDependency() == null) {
                continue;
            }
            if (s.getDependency().startsWith("project(")) {
                //compile project(xxxxx)
//                dependencyProject = new DependencyProject(s);
//                project.getDependencyProjects().add(dependencyProject);
            } else if (s.getDependency().startsWith("files")) {
                //compile libs
//                dependencyLib = new DependencyLib(s);
//                project.getDependencyLibs().add(dependencyLib);
            } else {
                //uk.co.chrisjenx:calligraphy:2.2.0
                //group:xxx, name:xxx, version:xxx
                String dependencyString = s.getDependency();

                if (dependencyString.contains(", ")) {
                    String group = dependencyString.split(", ")[0].split(":")[1];
                    String artifactId = dependencyString.split(", ")[1].split(":")[1];
                    String version = "";
                    try {
                        version = dependencyString.split(", ")[2].split(":")[1];
                    } catch (Exception e) {
                        System.out.println(dependencyString);
                        System.out.println(s.getPath());
                        e.printStackTrace();
                        String dir = s.getPath();
                        String name = dir.split("\\\\")[2];
                        FileUtil.writeFlie(ERROR_DIR + name + ".txt", "");

                    }
                    dependencyUrl = new DependencyUrl(group, artifactId, "jar", version, s.getPath());
                    project.getDependencyUrlList().add(dependencyUrl);
                } else if (s.getDependency().contains(":")) {
                    String[] tempDependencies = s.getDependency().split(":");
                    if (tempDependencies.length >= 3) {
                        String group = tempDependencies[0];
                        String artifactId = tempDependencies[1];
                        String version = tempDependencies[2];
                        dependencyUrl = new DependencyUrl(group, artifactId, "jar", version, s.getPath());
                        project.getDependencyUrlList().add(dependencyUrl);
                    }
                }
            }
        }

        FileUtil.writeFlie(OUTPUT_DIR + projectName + ".txt", new GsonBuilder().setPrettyPrinting().create().toJson(project));


    }


}
