package cn.edu.fudan.se.cfg.rq1.bean;

import java.util.List;

public class ErrorExceptionLib {

    List<String> error;
    List<String> exception;

    public List<String> getError() {
        return error;
    }

    public void setError(List<String> error) {
        this.error = error;
    }

    public List<String> getException() {
        return exception;
    }

    public void setException(List<String> exception) {
        this.exception = exception;
    }

    public ErrorExceptionLib() {

    }

    public ErrorExceptionLib(List<String> error, List<String> exception) {

        this.error = error;
        this.exception = exception;
    }
}
