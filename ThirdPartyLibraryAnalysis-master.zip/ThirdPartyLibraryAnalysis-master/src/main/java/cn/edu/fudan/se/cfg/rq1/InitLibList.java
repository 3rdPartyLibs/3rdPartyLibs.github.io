package cn.edu.fudan.se.cfg.rq1;

import cn.edu.fudan.se.cfg.rq1.bean.Lib;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 150K个jar包的最终统计
 */
public class InitLibList {

    static final String ALL_JAR_FILE_NAME = "F:\\lib_all.json";

    static final String LIB_RESULT_BASE_DIR = "G://wangying//LibToFieldsAll//";

    static final String RESULT_JAR_FILE_DIR_NORMAL_PATH = LIB_RESULT_BASE_DIR + "lib_field";
    static final String RESULT_JAR_FILE_DIR_EXCEPTION_PATH = LIB_RESULT_BASE_DIR + "exception";
    static final String RESULT_JAR_FILE_DIR_ERROR_PATh = LIB_RESULT_BASE_DIR + "error";

    public static void main(String[] args) {
        String content = FileUtil.read(ALL_JAR_FILE_NAME);
        List<String> allJarList = new Gson().fromJson(content, new TypeToken<List<String>>() {
        }.getType());

        List<String> resultNormalJarList = initResultList(RESULT_JAR_FILE_DIR_NORMAL_PATH);
        List<String> resultExceptionJarList = initResultList(RESULT_JAR_FILE_DIR_EXCEPTION_PATH);
        List<String> resultErrorJarList = initResultList(RESULT_JAR_FILE_DIR_ERROR_PATh);

        List<Lib> libs = getResultList(allJarList, resultNormalJarList, resultExceptionJarList, resultErrorJarList);

        FileUtil.writeFlie("F:/LibApiResult.json", new GsonBuilder().setPrettyPrinting().create().toJson(libs));

    }

    /**
     * 判断对于某一个jar包，属于哪个文件夹
     *
     * @param allJarList
     * @param resultNormalJarList
     * @param resultExceptionJarList
     * @param resultErrorJarList
     * @return
     */
    private static List<Lib> getResultList(List<String> allJarList, List<String> resultNormalJarList, List<String> resultExceptionJarList, List<String> resultErrorJarList) {

        Lib lib;
        List<Lib> libList = new ArrayList<>();
        for (String jar : allJarList) {
            int type = ifContains(jar, resultExceptionJarList, 2);
            if (type == -1) {
                //未找到
                type = ifContains(jar, resultErrorJarList, 1);
                if (type == -1) {
                    type = ifContains(jar, resultNormalJarList, 0);
                }
            }

            lib = new Lib(jar, type);
            libList.add(lib);
        }


        return libList;
    }

    /**
     * 是否包含在list中
     *
     * @param jar
     * @param jarList
     * @param defaultType 如果找到，就返回defaultType,找不到就返回-1
     * @return
     */
    private static int ifContains(String jar, List<String> jarList, int defaultType) {
        return 0;
    }

    private static List<String> initResultList(String resultJarFileDir) {

        File dir = new File(resultJarFileDir);
        File[] files = dir.listFiles();
        List<String> jars = new ArrayList<>();

        for (File file : files) {
            String name = file.getName();

            if (name.endsWith(".txt")) {
                name = name.substring(0, name.length() - 4);
            }
            if (name.endsWith(".json")) {
                name = name.substring(0, name.length() - 4);
            }

            if (file.getAbsolutePath().contains("error") || file.getAbsolutePath().contains("exception")) {

            }

        }


        return null;
    }
}
