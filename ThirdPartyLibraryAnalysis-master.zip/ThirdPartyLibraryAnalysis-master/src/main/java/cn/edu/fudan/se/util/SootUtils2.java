package cn.edu.fudan.se.util;

import cn.edu.fudan.se.cfg.CallGraphVisitor;
import cn.edu.fudan.se.cfg.SootFileUtils;
import cn.edu.fudan.se.cfg.SootUtil;
import soot.*;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CHATransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Targets;
import soot.options.Options;
import soot.util.dot.DotGraph;

import java.util.*;

import static groovyjarjarantlr.build.ANTLR.jarName;

public class SootUtils2 {

    private static final String RT_JAR_PATH = "C:/cs/jdk1.8.0_181/jre/lib/rt.jar;";
    private static final String JCE_JAR_PATH = "C:/cs/jdk1.8.0_181/jre/lib/jce.jar;";


    public static void generateCallGraph(String jarPath, String className, String methodName) {
        G.reset();

        CallGraphFetcher callGraphFetcher = new CallGraphFetcher(className, methodName);
        PackManager.v().getPack("wjtp").add(new Transform("wjtp.cgfetcher", callGraphFetcher));

        List<String> args = new ArrayList<>();
        args.add("-allow-phantom-refs");
        args.add("-w");
        //args.add("-whole-program");
        args.add("-cp");
        args.add(RT_JAR_PATH + JCE_JAR_PATH + jarPath + ";");
        args.add("-process-dir");
        args.add(jarPath);

        //String[] soot_options = new String[4];
//        soot_options[0] = "-src-prec";
//        soot_options[1] = "c";
//        soot_options[2] = "-cp";
//        soot_options[3] = RT_JAR_PATH
//                + JCE_JAR_PATH
//                + jarPath + ";";
        // soot_options[4] = "-w";
        //soot_options[5] = className;
        String[] sootOptions = args.toArray(new String[0]);
        Options.v().set_src_prec(Options.src_prec_java);
        Options.v().set_whole_program(true);
        Options.v().set_allow_phantom_refs(true);
        Options.v().set_output_format(Options.output_format_none);
        Options.v().setPhaseOption("cg.spark", "on");
        Options.v().set_no_bodies_for_excluded(true);
        Main.main(sootOptions);
    }

    private static class CallGraphFetcher extends SceneTransformer {

        String className;
        String methodName;

        public CallGraphFetcher(String className, String methodName) {
            this.className = className;
            this.methodName = methodName;
        }

        @Override
        protected void internalTransform(String phaseName, Map<String, String> options) {
            // TODO Auto-generated method stub

//			SootClass a = Scene.v().getSootClass("cn.fan.jar.Test");
//			CallGraph cg = Scene.v().getCallGraph();
//			SootMethod target = Scene.v().getMainClass().getMethodByName("way");
//
//			Iterator sources = new Sources(cg.edgesInto(target));
//			while (sources.hasNext()) {
//				SootMethod src = (SootMethod) sources.next();
//				System.out.println(target + " might be called by " + src);
//			}
//
//			Iterator<Edge> edgesInto = cg.edgesInto(target);
//			while (edgesInto.hasNext()) {
//				System.out.println(edgesInto.next());
//			}
            CHATransformer.v().transform();
            CallGraphVisitor callGraphVisitor = new CallGraphVisitor(jarName + ".dot");
            SootClass a = Scene.v().getSootClass(className);
            a.setApplicationClass();
            //Scene.v().setMainClass(a);
            SootMethod src = convertStringToSootMethod(methodName);
            List<SootMethod> entryList = new ArrayList<>();
            entryList.add(src);
            Scene.v().loadNecessaryClasses();
            Scene.v().loadBasicClasses();
            Scene.v().setEntryPoints(entryList);
            enableSpark();
            //PackManager.v().runPacks();
            CallGraph cg = Scene.v().getCallGraph();
            //SootMethod src = a.getMethod("");

            //Body body = src.retrieveActiveBody();
            Iterator<MethodOrMethodContext> targets = new Targets(cg.edgesOutOf(src));
            while (targets.hasNext()) {
                SootMethod target = (SootMethod) targets.next();
                System.out.println(src + " might call " + target);
            }

            for (SootMethod entryPoint : entryList) {
                callGraphVisitor.visit(cg, entryPoint);
            }
            DotGraph dotGraph = callGraphVisitor.getDot();
            int ab = 1;
            //CallGraphToDot.serializeCallGraph(cg, "D:\\myeclipseWorkSpace\\BuildSootDatas\\sootOutput\\call.dot");
        }
    }

    public static SootMethod convertStringToSootMethod(String methodNameString) {
        List<String> classNames = new ArrayList<>();
        Map<String, List<String>> mmap = SootFileUtils.getClassNameAndMethodNames(methodNameString, classNames);
        for (String clazzName : classNames) {
            List<String> methods = mmap.get(clazzName);
//            SootClass sootClass = Scene.v().forceResolve(clazzName, SootClass.BODIES);
            SootClass sootClass = Scene.v().loadClassAndSupport(clazzName);
            sootClass.setApplicationClass();
            Scene.v().loadNecessaryClasses();
            for (String methodKey : methods) {
                try {
                    String[] keys = methodKey.split("---");
                    String methodName = keys[0].substring(clazzName.length() + 1);
                    String params = keys[1];
                    List<String> paramList = SootFileUtils.toParamList(params);
                    String[] clazzNames = clazzName.split("\\.");
                    int size = clazzNames.length;
                    //构造函数
                    if (clazzNames[size - 1].equals(methodName)) {
                        methodName = "<init>";
                    }
                    SootMethod sootMethod = SootUtil.getMethodByNameAndParams(sootClass, methodName, paramList);
                    if (sootMethod != null) {
                        return sootMethod;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }


    public static void main(String[] args) {
        //"<java.io.PrintWriter: void close()>"
        String name = "<com.basti.TestStatic: void testStatic(java.lang.String)>";
        generateCallGraph("D:\\cs\\jar\\jar/TestJar21.jar", "com.basti.Test", "com.basti.Test.run1(java.lang.String,com.basti.Food)");
    }

    private static void enableSpark() {
        HashMap opt = new HashMap();
        opt.put("verbose", "true");
        opt.put("propagator", "worklist");
        opt.put("simple-edges-bidirectional", "false");
        opt.put("on-fly-cg", "true");
        opt.put("apponly", "true");
        opt.put("set-impl", "double");
        opt.put("double-set-old", "hybrid");
        opt.put("double-set-new", "hybrid");
        SparkTransformer.v().transform("", opt);
    }
}
