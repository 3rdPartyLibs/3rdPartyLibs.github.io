package cn.edu.fudan.se.cfg.gradle.parse.config;

import java.util.Arrays;
import java.util.List;

public class Config {
    //不需要遍历的文件夹
    //private static final String PASS_FILE_RAW[] = {".git", "src"};
    private static final String PASS_FILE_RAW[] = {".git"};
    public static final List<String> PASS_FILE = Arrays.asList(PASS_FILE_RAW);

    private static final String DEPENDENCY_TAG_RAW[] = {"compile", "provided", "apk", "implementation", "api", "only",
            "androidtestimplementation", "debugimplementation", "androidtestcompile", "testcompile","testcompileonly","compileonly",
            "testimplementation","signature","api","jmh"};
    public static final List<String> DEPENDENCY_TAG = Arrays.asList(DEPENDENCY_TAG_RAW);
}
