package cn.edu.fudan.se.util;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.maven.model.InputLocation;
import org.apache.maven.model.Model;
import org.apache.maven.model.building.DefaultModelBuildingRequest;
import org.apache.maven.model.building.ModelBuilder;
import org.apache.maven.model.building.ModelBuildingException;
import org.apache.maven.model.building.ModelBuildingRequest;
//import org.apache.archiva.metadata.repository.storage.RepositoryPathTranslator;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.codehaus.plexus.util.DirectoryScanner;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;

public class Test {
	
	private static final String[] INCLUDE_ALL_POMS = new String[]{"*/**/pom.xml"};
	
	public static List getPoms() {
		// "F:\\GP\\high_quality_repos\\JakeWharton\\ActionBarSherlock"
		//"F:\\GP\\high_quality_repos\\netty\\netty"
		final DirectoryScanner scanner = new DirectoryScanner();
        scanner.setBasedir("F:\\GP\\high_quality_repos\\JakeWharton\\ActionBarSherlock");
        scanner.setIncludes(INCLUDE_ALL_POMS);
        scanner.scan();
        final List poms = new ArrayList();
        for (int ctr = 0; ctr < scanner.getIncludedFiles().length; ctr++)
        {
            final File file = new File(
            		"F:\\GP\\high_quality_repos\\JakeWharton\\ActionBarSherlock",
                    scanner.getIncludedFiles()[ctr]);
//            System.out.println(scanner.getIncludedFiles()[ctr]);
            if (file.exists())
            {
            	System.out.println(file.getAbsolutePath());
                poms.add(file);
            }
        }
        return poms;
	}
	
	public static void testPom() {
		MavenXpp3Reader reader = new MavenXpp3Reader();

		Model model = null;
		try {
			FileReader fr = new FileReader("F:\\GP\\high_quality_repos\\JakeWharton\\ActionBarSherlock\\actionbarsherlock\\pom.xml"); 
			model = reader.read(fr);
			fr.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			System.out.println();
			e.printStackTrace();
			return;
		}
//		RepositoryPathTranslator pathTranslator;
//		ModelBuildingRequest req = new DefaultModelBuildingRequest();
//		req.setProcessPlugins( false );
//		req.setPomFile( new File("F:\\GP\\high_quality_repos\\JakeWharton\\ActionBarSherlock\\actionbarsherlock\\pom.xml") );
//		req.setModelResolver( new RepositoryModelResolver( "F:\\GP\\high_quality_repos\\JakeWharton\\ActionBarSherlock", pathTranslator ) );
//		req.setValidationLevel( ModelBuildingRequest.VALIDATION_LEVEL_MINIMAL );
//
//		ModelBuilder builder;
//		try
//		{
//		    model = builder.build( req ).getEffectiveModel();
//		}
//		catch ( ModelBuildingException e )
//		{
//		}
	}
	
	public static void main(String[] args) {
//		getPoms();
		testPom();
	}
}
