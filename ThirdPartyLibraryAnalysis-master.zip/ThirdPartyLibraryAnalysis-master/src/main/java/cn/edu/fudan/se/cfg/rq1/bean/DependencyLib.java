package cn.edu.fudan.se.cfg.rq1.bean;

public class DependencyLib {
    /**
     * jar_url : logback-classic-1.1.7.jar
     * groupId : ch.qos.logback
     * artifactId : logback-classic
     * version : 1.1.7
     */
    private String jar_url;
    private String groupId;
    private String artifactId;
    private String version;

    private int count;
    private int rank;

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public DependencyLib() {
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setJar_url(String jar_url) {
        this.jar_url = jar_url;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public void setArtifactId(String artifactId) {
        this.artifactId = artifactId;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getJar_url() {
        return jar_url;
    }

    public String getGroupId() {
        return groupId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    public String getVersion() {
        return version;
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof DependencyLib && ((DependencyLib) obj).getJar_url().equals(jar_url);
    }

    @Override
    public int hashCode() {
        return jar_url.hashCode();
    }
}
