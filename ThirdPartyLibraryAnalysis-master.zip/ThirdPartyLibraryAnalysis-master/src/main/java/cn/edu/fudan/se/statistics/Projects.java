package cn.edu.fudan.se.statistics;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.edu.fudan.se.db.DB;
import cn.edu.fudan.se.util.JsonFileUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class Projects {
	
	public static void getMavenProj() {
		JSONArray array = new JSONArray();
		int count = 0;
		List<String> paths = readAllProjList("C:\\Users\\yw\\Desktop\\1.json");
		System.out.println(paths.size());
		for(String path : paths) {
//			System.out.println(path);
			path = path.replace("/home/fdse/data/prior_repository", "https://github.com");
			ResultSet highQualityRs = DB.query("SELECT * FROM `repository_high_quality` where `url` = '"+path+"'");
			boolean has = false;
			try {
				while (highQualityRs.next()) {
					int repositoryId = highQualityRs.getInt("repository_id");
					String url = highQualityRs.getString("url");
					String localAddr = highQualityRs.getString("repos_addr");
					if(localAddr == null) {
						localAddr = url.replace("https://github.com", "home/fdse/data/prior_repository");
//						System.out.println(localAddr);
					}
					localAddr = localAddr.replace("home/fdse", "..");				
					JSONObject obj = new JSONObject();
					obj.put("id", highQualityRs.getInt("id"));
					obj.put("repository_id", highQualityRs.getInt("repository_id"));
					obj.put("url", url);
					obj.put("stars", highQualityRs.getInt("stars"));
					obj.put("commit_count", highQualityRs.getInt("commit_count"));
					obj.put("sizes", highQualityRs.getInt("sizes"));
					obj.put("fork", highQualityRs.getInt("fork"));
					obj.put("local_addr", localAddr);						
					array.add(obj);
					has = true;
					break;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(!has) {
				System.out.println(path);
				count++;
			}
		}
		System.out.println(count);
		System.out.println(array.size());
		JsonFileUtil.save("projects_maven.txt", array);
//		int count = 0;
//		
//		ResultSet highQualityRs = DB.query("SELECT * FROM `repository_high_quality`");
//		try {
//			while (highQualityRs.next()) {
////				int repositoryId = highQualityRs.getInt("repository_id");
//				String url = highQualityRs.getString("url");
//				String localAddr = highQualityRs.getString("repos_addr");
//				if(localAddr == null) {
//					localAddr = url.replace("https://github.com", "/home/fdse/data/prior_repository");
////					System.out.println(localAddr);
//				}
//				if(paths.contains(localAddr)) {
//					localAddr = localAddr.replace("/home/fdse", "..");				
//					JSONObject obj = new JSONObject();
//					obj.put("id", highQualityRs.getInt("id"));
//					obj.put("repository_id", highQualityRs.getInt("repository_id"));
//					obj.put("url", url);
//					obj.put("stars", highQualityRs.getInt("stars"));
//					obj.put("commit_count", highQualityRs.getInt("commit_count"));
//					obj.put("sizes", highQualityRs.getInt("sizes"));
//					obj.put("fork", highQualityRs.getInt("fork"));
//					obj.put("local_addr", localAddr);						
//					array.add(obj);
//				}
//				else {
//					count++;
//					System.out.println(localAddr);
//				}
//					
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println(array.size());
//		System.out.println(count);
//		JsonFileUtil.save("projects_maven.txt", array);
	}
	
	public static List<String> readAllProjList(String path) {
//		Map<String,Boolean> list = new HashMap<String,Boolean>();
		List<String> allProjs = new ArrayList<String>();
		String whole = JsonFileUtil.readJsonFile(path);		
		JSONArray array = JSONArray.fromObject(whole);
		for (int i = 0; i < array.size(); i++) {
			JSONObject obj = array.getJSONObject(i);
			String proj = obj.optString("proj");
			boolean isGradle = obj.optBoolean("gradle");
			boolean isMaven = obj.optBoolean("maven");
			boolean isAndroid = obj.optBoolean("android");
			if(isMaven && !isGradle && !isAndroid) {
				if(!allProjs.contains(proj)) {
					allProjs.add(proj);
				}
				else{
					System.out.println("error: repeat "+proj);
					System.exit(0);
				}
			}
//			if(!allProjs.contains(proj)) {
//				allProjs.add(proj);
//			}        		
        }
		return allProjs;
	}
	
	public static void getUnsolvedJar() {
		int count = 0;
		ResultSet typeRs = DB.query("SELECT * FROM `version_types` where `jar_package_url` like '%.jar' and `jar_package_url` not like '%-javadoc.jar'");
		try {
			while (typeRs.next()) {
				int type_id = typeRs.getInt("type_id");
				ResultSet rs = DB.query("SELECT * FROM `api_classes` where `version_type_id` = " + type_id);
				boolean have = false;
				while (rs.next()) {
					have = true;
					break;
				}
				if(!have) {
					System.out.println(type_id);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
//		getMavenProj();
		getUnsolvedJar();
	}
}
