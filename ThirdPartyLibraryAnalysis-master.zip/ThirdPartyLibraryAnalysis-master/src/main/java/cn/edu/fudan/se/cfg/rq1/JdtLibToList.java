package cn.edu.fudan.se.cfg.rq1;

import cn.edu.fudan.se.cfg.rq2.utils.JDTUtils;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import polyglot.ast.For;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class JdtLibToList {

    private static final String DECOMPILE_OUTPUT_DIR = "H:\\wangying\\rq1\\decompile\\";
    //private static final String LIB_DIR = "H:\\wangying\\lib_all\\";
    private static final String LIB_DIR = "d:/cs/jar/jar/";
    //private static final String SOURCE_FILE_PATH = "H:\\wangying\\rq1\\21479jar_list.json";
    private static final String SOURCE_FILE_PATH = "H:\\wangying\\rq1\\test2.json";

    public static void main(String[] args) {

        String content = FileUtil.read(SOURCE_FILE_PATH);
        List<String> jarFileNameList = new Gson().fromJson(content, new TypeToken<List<String>>() {
        }.getType());
        for (String jarName : jarFileNameList) {
            jarToList(LIB_DIR + jarName);
        }
    }


    public static void jarToList(String jarPath) {
        String outputPath = JDTUtils.decompileJar(jarPath, DECOMPILE_OUTPUT_DIR);
        List<String> paths = getAllJavaFile(outputPath);

        for (String path : paths) {
            List<BodyDeclaration> bodyDeclarationList = JDTUtils.getCompilationUnit(path);
            for (BodyDeclaration bodyDeclaration : bodyDeclarationList) {
                if (bodyDeclaration instanceof MethodDeclaration) {
                    //com.bast.classname.method(param1,param2)
                    //非interface和非abstract的public方法
                    boolean isInterface = ((TypeDeclaration) bodyDeclaration.getParent()).isInterface();
                    if (isInterface) {
                        continue;
                    }
                    boolean isAbstract = bodyDeclaration.modifiers().contains("abstract");
                    if (isAbstract) {
                        continue;
                    }
                    boolean isPublic = bodyDeclaration.modifiers().contains("public");
                    if (!isPublic) {
                        continue;
                    }
                    //package


                }
            }
        }
    }

    private static List<String> getAllJavaFile(String outputPath) {

        Queue<String> q = new LinkedList<>();
        q.offer(outputPath);
        List<String> javaPaths = new ArrayList<>();
        while (!q.isEmpty()) {
            String path = q.poll();

            if (new File(path).isDirectory()) {
                File[] files = new File(path).listFiles();

                for (File file : files) {
                    q.offer(file.getAbsolutePath());
                }
            } else if (new File(path).isFile()) {
                if (path.endsWith("java"))
                    javaPaths.add(path);
            }

        }
        return javaPaths;
    }

}
