package cn.edu.fudan.se.util;

import java.util.Iterator;
import java.util.Map;
import soot.G;
import soot.Main;
import soot.MethodOrMethodContext;
import soot.PackManager;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootMethod;
import soot.Transform;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Targets;

/**
 * 生成调用关系图孵化池
 * 
 * @author Thinkpad
 *
 */

public class GenerateCallGraph {
	public static void testCallGraphGeneration() throws Exception {
		G.reset();

		CallGraphFetcher callGraphFetcher = new CallGraphFetcher();
		PackManager.v().getPack("wjtp").add(new Transform("wjtp.cgfetcher", callGraphFetcher));

		String[] soot_options = new String[6];
		soot_options[0] = "-src-prec";
		soot_options[1] = "c";
		soot_options[2] = "-cp";
		soot_options[3] = "C:\\Program Files\\Java\\jdk1.8.0_181\\jre\\lib\\rt.jar;"
				+ "C:\\Program Files\\Java\\jdk1.8.0_181\\jre\\lib\\jce.jar;"
				+ "C:\\Users\\Thinkpad\\Desktop\\项目\\科研\\测试的jar\\Test.jar;";
		soot_options[4] = "-w";
		soot_options[5] = "cn.fan.jar.St";
		Main.main(soot_options);
	}

	private static class CallGraphFetcher extends SceneTransformer {

		@Override
		protected void internalTransform(String phaseName, Map<String, String> options) {
			// TODO Auto-generated method stub

//			SootClass a = Scene.v().getSootClass("cn.fan.jar.Test");
//			CallGraph cg = Scene.v().getCallGraph();
//			SootMethod target = Scene.v().getMainClass().getMethodByName("way");
//
//			Iterator sources = new Sources(cg.edgesInto(target));
//			while (sources.hasNext()) {
//				SootMethod src = (SootMethod) sources.next();
//				System.out.println(target + " might be called by " + src);
//			}
//
//			Iterator<Edge> edgesInto = cg.edgesInto(target);
//			while (edgesInto.hasNext()) {
//				System.out.println(edgesInto.next());
//			}
			// CHATransformer.v().transform();
			SootClass a = Scene.v().getSootClass("cn.fan.jar.St");
			CallGraph cg = Scene.v().getCallGraph();
			SootMethod src = a.getMethodByName("A");

			Iterator<MethodOrMethodContext> targets = new Targets(cg.edgesOutOf(src));
			while (targets.hasNext()) {
				SootMethod target = (SootMethod) targets.next();
				System.out.println(src + " might call " + target);
			}
			CallGraphToDot.serializeCallGraph(cg, "D:\\myeclipseWorkSpace\\BuildSootDatas\\sootOutput\\call.dot");
		}

	}

	public static void main(String[] args) {
		try {
			testCallGraphGeneration();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
