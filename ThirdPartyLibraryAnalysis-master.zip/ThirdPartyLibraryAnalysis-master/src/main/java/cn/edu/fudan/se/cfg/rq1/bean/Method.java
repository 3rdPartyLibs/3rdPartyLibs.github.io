package cn.edu.fudan.se.cfg.rq1.bean;

public class Method {

    String methodName;
    int modifiers;

    public String getMethodName() {

        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public int getModifiers() {
        return modifiers;
    }

    public void setModifiers(int modifiers) {
        this.modifiers = modifiers;
    }

    public Method(String methodName, int modifiers) {

        this.methodName = methodName;
        this.modifiers = modifiers;
    }
}
