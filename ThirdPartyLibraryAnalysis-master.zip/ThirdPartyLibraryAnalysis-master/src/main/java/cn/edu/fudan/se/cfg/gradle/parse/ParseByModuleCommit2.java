package cn.edu.fudan.se.cfg.gradle.parse;

import cn.edu.fudan.se.cfg.gradle.parse.bean.*;
import cn.edu.fudan.se.cfg.gradle.parse.utils.GradleUtils;
import cn.edu.fudan.se.cfg.gradle.parse.utils.ParseUtil2;
import cn.edu.fudan.se.cfg.rq1.bean.DependencyLib;
import cn.edu.fudan.se.cfg.rq2.bean.CommitInfo;
import cn.edu.fudan.se.cfg.rq2.utils.GitUtil;
import cn.edu.fudan.se.util.FileUtil;
import cn.edu.fudan.se.util.JsonFileUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class ParseByModuleCommit2 {

    private static String OUTPUT_DIR;// = "I://commit_dependency\\normal//";
    private static String ERROR_DIR ;//= "I://commit_dependency\\error/";
    private static GitUtil jGit;

    public static void main(String[] args) {
        String rootPath = args[0];
        OUTPUT_DIR = rootPath+"/ok/";
        ERROR_DIR = rootPath+"/error/";
        String content = JsonFileUtil.readJsonFile(rootPath+"/gradle-projs-id-gt145-17.json");
        JSONArray array = JSONArray.parseArray(content);
        for(Object jo :array) {
            JSONObject jsonO = (JSONObject)jo;
            int id = jsonO.getInteger("id");
//            if(id ==328){
//                continue;
//            }
            String name = jsonO.getString("name");
            File f = new File(rootPath+"/projects_unzips/"+name);
            if(f.exists()){
                System.out.println(name);
                parseCommit(name, rootPath+"/projects_unzips/"+name, id);
                jGit.close();
                break;
            }

        }
    }



    /**
     * 解析单个commit tree
     *
     * @param projectName
     * @param projectPath
     */
    private static void parseCommit(String projectName, String projectPath, int projectId) {
        List<CommitInfo> commitInfoList = getAllCommit(projectPath);
        int index = 1;
        int commitSize = commitInfoList.size();
        for (CommitInfo commitInfo : commitInfoList) {
            String commit1 = commitInfo.getCommitId();
            int time1 = commitInfo.getTime();
            File normalFile = new File(OUTPUT_DIR + String.valueOf(projectId) + "_" + commit1 + "_" + String.valueOf(time1) + ".txt");
            File errorFile = new File(ERROR_DIR + String.valueOf(projectId) + "_" + commit1 + "_" + String.valueOf(time1) + ".txt");
            if (normalFile.exists()||errorFile.exists()){
                continue;
            }

            try {

                Project2 project = new Project2();

                String commit = commitInfo.getCommitId();
                System.out.println("parsing " + String.valueOf(projectId) + " " + projectName + " " + String.valueOf(index) + "/" + String.valueOf(commitSize) + " " + commitInfo.getCommitId());
                int time = commitInfo.getTime();

                checkout(commit, projectPath);
                List<GradleFile> gradleFileList = GradleUtils.getAllGradleFiles(projectPath);
                if (gradleFileList == null) {
                    return;
                }
                int size = gradleFileList.size();
                if (size == 0) {
                    return;
                }
                for (int gradleFileIndex = 0; gradleFileIndex < size; gradleFileIndex++) {
                    GradleFile gradleFile = gradleFileList.get(gradleFileIndex);
                    if (gradleFile.getType().equals("build.gradle")) {
                        ParseUtil2.parse(gradleFile.getContent(), gradleFile.getPath());
                    } else if (gradleFile.getType().endsWith("properties")) {
                        ParseUtil2.parseProperties(gradleFile.getPath());
                    }
                }
                ParseUtil2.replaceDependencyValue();
                ParseUtil2.replaceDependencyValue();
                ParseUtil2.replaceDependencyValue();
                ParseUtil2.replaceDependencyValue();
                ParseUtil2.clearDependencyValue();
                List<Dependency2> dependencies = ParseUtil2.getDependencies();
                List<DependencyUrl> depends = project.getDependencyUrlList();
                handleDependency(depends,projectName, dependencies, projectId, commit, time);
                ParseUtil2.clearDependencies();
                ParseUtil2.clearDependencyValue();



                //parent



                String parentCommit = commitInfo.getParentCommitId();
                System.out.println("parsing " + String.valueOf(projectId) + " " + projectName + " " + String.valueOf(index) + "/" + String.valueOf(commitSize) + " " + commitInfo.getParentCommitId());
                checkout(parentCommit, projectPath);
                gradleFileList = GradleUtils.getAllGradleFiles(projectPath);
                if (gradleFileList == null) {
                    return;
                }
                size = gradleFileList.size();
                if (size == 0) {
                    return;
                }
                for (int gradleFileIndex = 0; gradleFileIndex < size; gradleFileIndex++) {
                    GradleFile gradleFile = gradleFileList.get(gradleFileIndex);
                    if (gradleFile.getType().equals("build.gradle")) {
                        ParseUtil2.parse(gradleFile.getContent(), gradleFile.getPath());
                    } else if (gradleFile.getType().endsWith("properties")) {
                        ParseUtil2.parseProperties(gradleFile.getPath());
                    }
                }
                ParseUtil2.replaceDependencyValue();
                ParseUtil2.replaceDependencyValue();
                ParseUtil2.replaceDependencyValue();
                ParseUtil2.replaceDependencyValue();
                ParseUtil2.clearDependencyValue();
                dependencies = ParseUtil2.getDependencies();
                List<DependencyUrl> parentDepends = project.getParentDependencyUrlList();
                handleDependency(parentDepends,projectName, dependencies, projectId, parentCommit, time);
                ParseUtil2.clearDependencies();
                ParseUtil2.clearDependencyValue();

                FileUtil.writeFlie(OUTPUT_DIR + String.valueOf(projectId) + "_" + commit + "_"+parentCommit+"_" + String.valueOf(time) + ".txt", new GsonBuilder().setPrettyPrinting().create().toJson(project));


            } catch (Exception e) {
                FileUtil.writeFlie(ERROR_DIR + String.valueOf(projectId) + "_" + commitInfo.getCommitId() + "_" + String.valueOf(commitInfo.getTime()) + ".txt", e.getMessage() == null ? "" : e.getMessage());
            } finally {
                index++;
            }
        }
    }

    private static List<CommitInfo> getAllCommit(String gitPath) {
        jGit = new GitUtil();
        jGit.buildRepository(gitPath + "/.git", -1);
        jGit.walkRepository(gitPath);
        return jGit.getIssueCommitIdList();
    }

    private static boolean isAllProperties(List<GradleFile> gradleFileList) {
        for (GradleFile gradleFile : gradleFileList) {
            if (!gradleFile.getPath().endsWith(".properties")) {
                return false;
            }
        }
        return true;
    }

    /**
     * 处理结果
     *
     * @param projectName
     * @param dependencies
     * @param projectId
     * @param commit
     * @param time
     */
    private static void handleDependency(List<DependencyUrl> depends,String projectName, List<Dependency2> dependencies,
                                         int projectId, String commit, int time) {

        DependencyProject dependencyProject;
        DependencyLib dependencyLib;
        DependencyUrl dependencyUrl;

        for (Dependency2 s : dependencies) {
            if (s == null || s.getDependency() == null) {
                continue;
            }
            if (s.getDependency().startsWith("project(")) {
                //compile project(xxxxx)
//                dependencyProject = new DependencyProject(s);
//                project.getDependencyProjects().add(dependencyProject);
            } else if (s.getDependency().startsWith("files")) {
                //compile libs
//                dependencyLib = new DependencyLib(s);
//                project.getDependencyLibs().add(dependencyLib);
            } else {
                //uk.co.chrisjenx:calligraphy:2.2.0
                //group:xxx, name:xxx, version:xxx
                String dependencyString = s.getDependency();

                if (dependencyString.contains(", ")) {
                    String group = dependencyString.split(", ")[0].split(":")[1];
                    String artifactId = dependencyString.split(", ")[1].split(":")[1];
                    String version = "";
                    try {
                        version = dependencyString.split(", ")[2].split(":")[1];
                    } catch (Exception e) {
                        System.out.println(dependencyString);
                        System.out.println(s.getPath());
                        e.printStackTrace();
                        String dir = s.getPath();
                        String name = dir.split("\\\\")[2];
                        FileUtil.writeFlie(ERROR_DIR + String.valueOf(projectId) + "_" + commit + "_" + String.valueOf(time) + ".txt", "");

                    }
                    dependencyUrl = new DependencyUrl(group, artifactId, "jar", version, s.getPath());
                    depends.add(dependencyUrl);
                } else if (s.getDependency().contains(":")) {
                    String[] tempDependencies = s.getDependency().split(":");
                    if (tempDependencies.length >= 3) {
                        String group = tempDependencies[0];
                        String artifactId = tempDependencies[1];
                        String version = tempDependencies[2];
                        dependencyUrl = new DependencyUrl(group, artifactId, "jar", version, s.getPath());
                        depends.add(dependencyUrl);
                    }
                }
            }
        }



    }

    private static void checkout(String commit, String projectPath) {

        String command = String.format("/usr/bin/git --git-dir=%s/.git --work-tree=%s checkout -f %s", projectPath, projectPath, commit);
//        ProcessBuilder builder = new ProcessBuilder(
//                "cmd.exe", "/c", command);
        ProcessBuilder builder = new ProcessBuilder(command.split(" "));
        builder.redirectErrorStream(true);
        try {
            Process p = builder.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while (true) {
                line = r.readLine();
                if (line == null) {
                    break;
                }
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
