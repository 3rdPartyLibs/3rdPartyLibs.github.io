package cn.edu.fudan.se.cfg.gradle.parse.bean;

public class Dependency2 {
    String dependency;
    String path;

    public String getDependency() {
        if (dependency == null){
            dependency = "";
        }
        return dependency;
    }

    public void setDependency(String dependency) {
        this.dependency = dependency;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Dependency2() {

    }

    public Dependency2(String dependency, String path) {

        this.dependency = dependency;
        this.path = path;
    }
}
