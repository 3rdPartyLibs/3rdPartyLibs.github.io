package cn.edu.fudan.se.api;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.edu.fudan.se.db.DB;

public class ExtractLibApi {
	
}
