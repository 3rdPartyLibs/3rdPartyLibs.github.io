package cn.edu.fudan.se.cfg.gradle.parse.bean;

public class ProjUsage {
    /**
     * local_addr : F:/wangying/projects_last_unzips/gradle500/Netflix__fdse__SimianArmy
     * id : 2
     */
    private String local_addr;
    private int id;

    public void setLocal_addr(String local_addr) {
        this.local_addr = local_addr;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLocal_addr() {
        return local_addr;
    }

    public int getId() {
        return id;
    }
}
