package cn.edu.fudan.se.statistics;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import cn.edu.fudan.se.db.DB;
import cn.edu.fudan.se.util.JsonFileUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class ProjectStatistics {
	
	public static void getMavenProjects() {
		JSONArray array = new JSONArray();
		try {
			Scanner in = new Scanner(new File("E:/data/500p.txt"));
			String path=null;
			while (in.hasNextLine()) {
				String str = in.nextLine();
				if(str.startsWith("http")) {					
					path = str;
				}
				else if(str.startsWith("proj-type:")) {
					if(str.equals("proj-type: maven")) {
						System.out.println(path);
						path = path.replace("/home/fdse/data/prior_repository", "https://github.com");
						ResultSet highQualityRs = DB.query("SELECT * FROM `repository_high_quality` where `url` = '"+path+"'");
						try {
							while (highQualityRs.next()) {
								int id = highQualityRs.getInt("id");
								System.out.println(id);
								if(id > 1380) {
									String url = highQualityRs.getString("url");
									String localAddr = highQualityRs.getString("repos_addr");
									if(localAddr == null) {
										localAddr = url.replace("https://github.com", "home/fdse/data/prior_repository");
//										System.out.println(localAddr);
									}
									localAddr = localAddr.replace("home/fdse", "..");				
									JSONObject obj = new JSONObject();
									obj.put("id", highQualityRs.getInt("id"));
									obj.put("repository_id", highQualityRs.getInt("repository_id"));
									obj.put("url", url);
									obj.put("stars", highQualityRs.getInt("stars"));
									obj.put("commit_count", highQualityRs.getInt("commit_count"));
									obj.put("sizes", highQualityRs.getInt("sizes"));
									obj.put("fork", highQualityRs.getInt("fork"));
									obj.put("local_addr", localAddr);						
									array.add(obj);
									break;
								}
								
							}
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
			in.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println(array.size());
		JsonFileUtil.save("projects_maven_1380+.txt", array);
	}
	
	public static void getMavenProjects(String range) {
		String whole = JsonFileUtil.readJsonFile("E:/data/projs.json");
		JSONArray pa = JSONArray.fromObject(whole);
		JSONArray array = new JSONArray();
		for(int i=0;i<pa.size();i++) {
			JSONObject proj =  pa.getJSONObject(i);
			String path = proj.getString("url");
			String type = proj.getString("proj-type");
			String stars = proj.getString("stars");
//			if(type.equals("proj-type: maven") && stars.equals(range)) {
			if(type.equals("proj-type: maven-gradle")) {
				path = path.replace("/home/fdse/data/prior_repository", "https://github.com");
				ResultSet highQualityRs = DB.query("SELECT * FROM `repository_high_quality` where `url` = '"+path+"'");
				try {
					while (highQualityRs.next()) {
						int id = highQualityRs.getInt("id");
//						if(id <= 1380) {
							System.out.println(id);
							System.out.println(path);

							String url = highQualityRs.getString("url");
							String localAddr = highQualityRs.getString("repos_addr");
							if(localAddr == null) {
								localAddr = url.replace("https://github.com", "home/fdse/data/prior_repository");
//								System.out.println(localAddr);
							}
							localAddr = localAddr.replace("home/fdse", "..");				
							JSONObject obj = new JSONObject();
							obj.put("id", highQualityRs.getInt("id"));
							obj.put("repository_id", highQualityRs.getInt("repository_id"));
							obj.put("url", url);
							obj.put("stars", highQualityRs.getInt("stars"));
							obj.put("commit_count", highQualityRs.getInt("commit_count"));
							obj.put("sizes", highQualityRs.getInt("sizes"));
							obj.put("fork", highQualityRs.getInt("fork"));
							obj.put("local_addr", localAddr);						
							array.add(obj);
							break;
//						}
						
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		System.out.println(array.size());
//		JsonFileUtil.save("projects_maven_"+range+".txt", array);
		JsonFileUtil.save("projects_maven_gradle.txt", array);
	}
	
	public static void main(String[] args)  
	{
//		String whole = JsonFileUtil.readJsonFile("projects_maven_1380+.txt");
//		JSONArray array = JSONArray.fromObject(whole);
//		System.out.println(array.size());
//		getMavenProjects("200-500");
		getMavenProjects("");
//		getMavenProjects();
	}
}
