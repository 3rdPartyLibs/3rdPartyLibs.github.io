package cn.edu.fudan.se.cfg;

//方法比对的结果
public class MethodResult {
    boolean shouldInstead;
    //0表示调用了新增方法
    //1 表示方法发生了改变
    int type;

    public boolean isShouldInstead() {
        return shouldInstead;
    }

    public void setShouldInstead(boolean shouldInstead) {
        this.shouldInstead = shouldInstead;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public MethodResult() {

    }

    public MethodResult(boolean shouldInstead, int type) {

        this.shouldInstead = shouldInstead;
        this.type = type;
    }
}
