package cn.edu.fudan.se.handlepom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

public class PomDiff {
	public static Map<String, Map> compareDiff(Map<String,Map<String,String>> prevLibVerPairs,Map<String,Map<String,String>> currLibVerPairs) {
//		printLibs(prevLibVerPairs);
//		printLibs(currLibVerPairs);
		Map<String, Map> changedLib = new HashMap<String, Map>();
		Map<String,String[]> modifiedLib = new HashMap<String,String[]>();
//		Map<String,String> addedLib = new HashMap<String,String>();
//		Map<String,String> deletedLib = new HashMap<String,String>();
		for (Map.Entry<String, Map<String,String>> entry : prevLibVerPairs.entrySet()) {
			String libStr = entry.getKey();
			if(currLibVerPairs.containsKey(libStr)) {
				for (Map.Entry<String, String> value : entry.getValue().entrySet()) {
					String version = value.getKey();
					if(version != null) {
						if(currLibVerPairs.get(libStr).containsKey(version)) {
//							currLibVerPairs.get(libStr).remove(version);
//							prevLibVerPairs.get(libStr).remove(version);
						}
						else {
							for (Map.Entry<String, String> currValue : currLibVerPairs.get(libStr).entrySet()) {
								if(currValue.getKey() != null) {
									String[] versions = {version,currValue.getKey()};
									modifiedLib.put(libStr, versions);
//									prevLibVerPairs.get(libStr).remove(version);
//									currLibVerPairs.get(libStr).remove(currValue.getKey());
								}
//								else
//									currLibVerPairs.get(libStr).remove(version);//暂定
							}
						}
					}	
//					else 
//						prevLibVerPairs.get(libStr).remove(version);//暂定					
				}	
			}					
		}
//		for (Map.Entry<String, Map<String,String[]>> entry : prevLibVerPairs.entrySet()) {
//			String libStr = entry.getKey();		
//			for (Map.Entry<String, String[]> value : entry.getValue().entrySet()) {
//				String version = value.getKey();
//				if(version != null) {
//					deletedLib.put(libStr, version);
//				}
//			}
//		}
//		for (Map.Entry<String, Map<String,String[]>> entry : currLibVerPairs.entrySet()) {
//			String libStr = entry.getKey();		
//			for (Map.Entry<String, String[]> value : entry.getValue().entrySet()) {
//				String version = value.getKey();
//				if(version != null) {
//					addedLib.put(libStr, version);
//				}
//			}
//		}
		changedLib.put("modified", modifiedLib);
//		changedLib.put("deleted", deletedLib);
//		changedLib.put("added", addedLib);
//		printChange(modifiedLib,deletedLib,addedLib);
		return changedLib;
	}
//	public static Map<String, Map> compareDiff(Map<String,Map<String,String[]>> prevLibVerPairs,Map<String,Map<String,String[]>> currLibVerPairs) {
////		printLibs(prevLibVerPairs);
////		printLibs(currLibVerPairs);
//		Map<String, Map> changedLib = new HashMap<String, Map>();
//		Map<String,String[]> modifiedLib = new HashMap<String,String[]>();
////		Map<String,String> addedLib = new HashMap<String,String>();
////		Map<String,String> deletedLib = new HashMap<String,String>();
//		for (Map.Entry<String, Map<String,String[]>> entry : prevLibVerPairs.entrySet()) {
//			String libStr = entry.getKey();
//			if(currLibVerPairs.containsKey(libStr)) {
//				for (Map.Entry<String, String[]> value : entry.getValue().entrySet()) {
//					String version = value.getKey();
//					if(version != null) {
//						if(currLibVerPairs.get(libStr).containsKey(version)) {
////							currLibVerPairs.get(libStr).remove(version);
////							prevLibVerPairs.get(libStr).remove(version);
//						}
//						else {
//							for (Map.Entry<String, String[]> currValue : currLibVerPairs.get(libStr).entrySet()) {
//								if(currValue.getKey() != null) {
//									String[] versions = {version,currValue.getKey()};
//									modifiedLib.put(libStr, versions);
////									prevLibVerPairs.get(libStr).remove(version);
////									currLibVerPairs.get(libStr).remove(currValue.getKey());
//								}
////								else
////									currLibVerPairs.get(libStr).remove(version);//暂定
//							}
//						}
//					}	
////					else 
////						prevLibVerPairs.get(libStr).remove(version);//暂定					
//				}	
//			}					
//		}
////		for (Map.Entry<String, Map<String,String[]>> entry : prevLibVerPairs.entrySet()) {
////			String libStr = entry.getKey();		
////			for (Map.Entry<String, String[]> value : entry.getValue().entrySet()) {
////				String version = value.getKey();
////				if(version != null) {
////					deletedLib.put(libStr, version);
////				}
////			}
////		}
////		for (Map.Entry<String, Map<String,String[]>> entry : currLibVerPairs.entrySet()) {
////			String libStr = entry.getKey();		
////			for (Map.Entry<String, String[]> value : entry.getValue().entrySet()) {
////				String version = value.getKey();
////				if(version != null) {
////					addedLib.put(libStr, version);
////				}
////			}
////		}
//		changedLib.put("modified", modifiedLib);
////		changedLib.put("deleted", deletedLib);
////		changedLib.put("added", addedLib);
////		printChange(modifiedLib,deletedLib,addedLib);
//		return changedLib;
//	}
	
	public static void printChange(Map<String,String[]> modifiedLib,Map<String,String> deletedLib,Map<String,String> addedLib) {
		for (Map.Entry<String, String[]> entry : modifiedLib.entrySet()) {
			System.out.println("modified lib:"+entry.getKey()+": "+entry.getValue()[0]+" "+entry.getValue()[1]);
		}
		for (Map.Entry<String, String> entry : deletedLib.entrySet()) {
			System.out.println("deleted lib:"+entry.getKey()+" "+entry.getValue());
		}
		for (Map.Entry<String, String> entry : addedLib.entrySet()) {
			System.out.println("added lib:"+entry.getKey()+" "+entry.getValue());
		}
	}
	
	public static void printModify(Map<String,List<String>> modifiedLib) {
		for (Map.Entry<String, List<String>> entry : modifiedLib.entrySet()) {
			for(String vers:entry.getValue()) {
				System.out.println("modified lib:"+entry.getKey()+": "+vers);
			}
		}
		
	}
	
//	public static void printLibs(Map<String,Map<String,String[]>> libVerPairs) {
//		for (Map.Entry<String, Map<String, String[]>> entry : libVerPairs.entrySet()) {
//			String libStr = entry.getKey();
//			for (Map.Entry<String, String[]> value : entry.getValue().entrySet()) {
//				System.out.println(libStr + ": " + value.getKey());
//			}
//		}
//	}
	public static void printLibs(Map<String,Map<String,String>> libVerPairs) {
		for (Map.Entry<String, Map<String, String>> entry : libVerPairs.entrySet()) {
			String libStr = entry.getKey();
			for (Map.Entry<String, String> value : entry.getValue().entrySet()) {
				System.out.println(libStr + ": " + value.getKey()+"  " +value.getValue());
			}
		}
	}
}
