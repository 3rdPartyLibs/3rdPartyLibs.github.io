package cn.edu.fudan.se.cfg.gradle.parse;

import cn.edu.fudan.se.cfg.gradle.parse.bean.*;
import cn.edu.fudan.se.cfg.gradle.parse.utils.GradleUtils;
import cn.edu.fudan.se.cfg.gradle.parse.utils.ParseUtil;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GradleParserRq3 {
//    private static final String DIR = "I:\\RQ3\\projects\\";
//    private static final String OUTPUT_DIR = "I://RQ3\\rq3_dependency_output//";
//    private static final String ERROR_DIR = "I://RQ3\\rq3_dependency_error//";
//    private static final String MAVEN_DIR = "I://RQ3\\rq3_dependency_maven//";
//    String a = "version: 1.0.0\n" +
//            "\n" +
//            "\tJira issues:\n" +
//            "\tSMTPAppender does not send messages\n" +
//            "\taffectsVersions:1.0.0\n" +
//            "\thttps://jira.qos.ch/projects/LOGBACK/issues/LOGBACK-329?filter=allopenissues\n" +
//            "\tSyslogAppender doesn't respect %nopex; outputs stack trace\n" +
//            "\taffectsVersions:1.0.0\n" +
//            "\thttps://jira.qos.ch/projects/LOGBACK/issues/LOGBACK-353?filter=allopenissues\n" +
//            "\tMixing periods and dollar signs in a logger name causes IllegalArgumentException from LoggerFactory.getLogger\n" +
//            "\taffectsVersions:1.0.0\n" +
//            "\thttps://jira.qos.ch/projects/LOGBACK/issues/LOGBACK-384?filter=allopenissues\n" +
//            "\tConcurrentModificationException when LoggerContext.reset \n" +
//            "\taffectsVersions:1.0.0\n" +
//            "\thttps://jira.qos.ch/projects/LOGBACK/issues/LOGBACK-397?filter=allopenissues\n" +
//            "\tSiftingAppender does not substitute variable value inside sift\n" +
//            "\taffectsVersions:1.0.0\n" +
//            "\thttps://jira.qos.ch/projects/LOGBACK/issues/LOGBACK-403?filter=allopenissues";
/*    public static void main(String[] args) {

        init();
        File dir = new File(DIR);
        File[] projects = dir.listFiles();
        for (File file : projects) {
            if (file.isDirectory()) {
                System.out.println("parse " + file.getName());
                String path = file.getAbsolutePath();
//                if (new File(OUTPUT_DIR + file.getName()).exists()) {
//                    continue;
//                }
                try {
                    parseCommit(file.getName(), path);
                } catch (Exception e) {
                    String message = e.getMessage();
                    FileUtil.writeFlie(ERROR_DIR + file.getName() + ".txt", message == null ? "" : message);
                    e.printStackTrace();
                }
            }
        }
    }

    private static void init() {
        File outputFile = new File(OUTPUT_DIR);
        if (!outputFile.exists()) {
            outputFile.mkdirs();
        }
        File errorFile = new File(ERROR_DIR);
        if (!errorFile.exists()) {
            errorFile.mkdirs();
        }
        File mavenFile = new File(MAVEN_DIR);
        if (!mavenFile.exists()) {
            mavenFile.mkdirs();
        }
    }

    *//**
     * 解析单个commit tree
     *
     * @param projectName
     * @param projectPath
     *//*
    private static void parseCommit(String projectName, String projectPath) {

        List<GradleFile> gradleFileList = GradleUtils.getAllGradleFiles(projectPath);
        if (gradleFileList == null) {
            //FileUtil.writeFlie(MAVEN_DIR + projectName + ".txt", "");
            return;
        }
        int size = gradleFileList.size();
        if (size == 0) {
            //FileUtil.writeFlie(MAVEN_DIR + projectName + ".txt", "");
            return;
        }
        boolean isAllProperties = isAllProperties(gradleFileList);
        if (isAllProperties) {
            System.out.println("all properties"+String.valueOf(projectName));
            System.out.println(OUTPUT_DIR + projectName + ".txt");
            File file = new File(OUTPUT_DIR + projectName + ".txt");
            file.delete();
            //FileUtil.writeFlie(MAVEN_DIR + projectName + ".txt", "");
            return;
        }
        *//*for (int gradleFileIndex = 0; gradleFileIndex < size; gradleFileIndex++) {
            GradleFile gradleFile = gradleFileList.get(gradleFileIndex);
            if (gradleFile.getType().equals("build.gradle")) {
                ParseUtil.parse(gradleFile.getContent(), gradleFile.getPath());
            } else if (gradleFile.getType().endsWith("properties")) {
                ParseUtil.parseProperties(gradleFile.getPath());
            }
        }
        ParseUtil.replaceDependencyValue();
        ParseUtil.replaceDependencyValue();
        ParseUtil.clearDependencyValue();
        List<String> dependencies = ParseUtil.getDependencies();

        handleDependency(projectName, dependencies);
        ParseUtil.clearDependencies();
        ParseUtil.clearDependencyValue();*//*
    }

    private static boolean isAllProperties(List<GradleFile> gradleFileList) {
        for (GradleFile gradleFile : gradleFileList) {
            if (!gradleFile.getPath().endsWith(".properties")) {
                return false;
            }
        }
        return true;
    }

    *//**
     * 处理结果
     *
     * @param projectName
     * @param dependencies
     *//*
    private static void handleDependency(String projectName, List<String> dependencies) {
        Set<String> dependenciesSet = new HashSet<>(dependencies);
        Project project = new Project();
        DependencyProject dependencyProject;
        DependencyLib dependencyLib;
        DependencyUrl dependencyUrl;

        for (String s : dependenciesSet) {
            if (s == null) {
                continue;
            }
            if (s.startsWith("project(")) {
                //compile project(xxxxx)
                dependencyProject = new DependencyProject(s);
                project.getDependencyProjects().add(dependencyProject);
            } else if (s.startsWith("files")) {
                //compile libs
                dependencyLib = new DependencyLib(s);
                project.getDependencyLibs().add(dependencyLib);
            } else {
                //uk.co.chrisjenx:calligraphy:2.2.0
                if (s.contains(":")) {
                    String[] tempDependencies = s.split(":");
                    if (tempDependencies.length >= 3) {
                        String group = tempDependencies[0];
                        String artifactId = tempDependencies[1];
                        String version = tempDependencies[2];
                        dependencyUrl = new DependencyUrl(group, artifactId, version);
                        project.getDependencyUrls().add(dependencyUrl);
                    }
                }
            }
        }

        FileUtil.writeFlie(OUTPUT_DIR + projectName + ".txt", new GsonBuilder().setPrettyPrinting().create().toJson(project));


    }*/

}
