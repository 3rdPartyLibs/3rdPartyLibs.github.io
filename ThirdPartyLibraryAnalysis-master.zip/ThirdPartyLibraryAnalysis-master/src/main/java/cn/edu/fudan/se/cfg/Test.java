package cn.edu.fudan.se.cfg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by huangkaifeng on 2018/9/17.
 */
public class Test {
    public static void main(String args[]){
        List<String> a = new ArrayList<>();
        a.add("aaaaa");
        List<String> immutablelist = Collections.unmodifiableList(a);
        System.out.println("aaa");
    }
}
