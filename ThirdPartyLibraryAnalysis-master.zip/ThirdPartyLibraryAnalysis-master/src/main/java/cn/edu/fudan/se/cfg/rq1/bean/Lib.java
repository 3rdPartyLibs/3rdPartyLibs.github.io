package cn.edu.fudan.se.cfg.rq1.bean;

public class Lib {

    String name;
    int status;//0表示正常 1表示error 2表示exception,-1表示未找到

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Lib() {

    }

    public Lib(String name, int status) {

        this.name = name;
        this.status = status;
    }
}
