package cn.edu.fudan.se.git;

public class IssueCommitId {

    String issueId;
    String commitId;

    public String getIssueId() {
        return issueId;
    }

    public void setIssueId(String issueId) {
        this.issueId = issueId;
    }

    public String getCommitId() {
        return commitId;
    }

    public void setCommitId(String commitId) {
        this.commitId = commitId;
    }

    public IssueCommitId() {

    }

    public IssueCommitId(String issueId, String commitId) {

        this.issueId = issueId;
        this.commitId = commitId;
    }
}
