package cn.edu.fudan.se.cfg.gradle.parse.bean;

public class ProjInfo {
    /**
     * path : gradle500
     * stars : 500p
     * url : https://github.com/Netflix/SimianArmy
     */
    private String path;
    private String stars;
    private String url;


    public ProjInfo(String path, String stars, String url) {
        this.path = path;
        this.stars = stars;
        this.url = url;
    }

    public ProjInfo() {

    }

    public void setPath(String path) {
        this.path = path;
    }

    public void setStars(String stars) {
        this.stars = stars;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPath() {
        return path;
    }

    public String getStars() {
        return stars;
    }

    public String getUrl() {
        return url;
    }
}
