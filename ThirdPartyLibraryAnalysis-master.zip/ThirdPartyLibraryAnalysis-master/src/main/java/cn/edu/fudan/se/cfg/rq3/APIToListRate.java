package cn.edu.fudan.se.cfg.rq3;

import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class APIToListRate {
    public static void main(String[] args) {
        final String OUTPUT_DIR = "D:/wangying/rq3/lib_api_callgraph_output/";
        final String INPUT_DIR = "D:/wangying/rq3/api_call_rq3_proj_filtered/";

        int totalMethodCount = 0;
        int successMethodCount = 0;
        File[] outputFileList = new File(OUTPUT_DIR).listFiles();
        Gson gson = new Gson();
        for (File file : outputFileList) {
            String outputContent = FileUtil.read(file.getAbsolutePath());
            Map<String, Map<String, List<String>>> outputContentMap = new HashMap<>();
            outputContentMap = gson.fromJson(outputContent, outputContentMap.getClass());
            String inputContent = FileUtil.read(INPUT_DIR+file.getName());
            Map<String, Map<String, List<String>>> inputContentMap = new HashMap<>();
            inputContentMap = gson.fromJson(inputContent, inputContentMap.getClass());

            for (Map.Entry<String, Map<String, List<String>>> jarEntry : outputContentMap.entrySet()) {
                String jarKey = jarEntry.getKey();
                Map<String, List<String>> outputJarValue = jarEntry.getValue();
                Map<String, List<String>> inputJarValue = inputContentMap.get(jarKey);

                totalMethodCount += inputJarValue.size();
                successMethodCount += outputJarValue.size();
            }
        }
        System.out.println("totalMethodCount: " + String.valueOf(totalMethodCount));
        System.out.println("successMethodCount: " + String.valueOf(successMethodCount));
        System.out.println("rate: " + successMethodCount * 1.0 / totalMethodCount);

    }
}
