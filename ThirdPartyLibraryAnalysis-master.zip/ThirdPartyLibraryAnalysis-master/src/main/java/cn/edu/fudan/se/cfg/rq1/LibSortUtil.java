package cn.edu.fudan.se.cfg.rq1;

import cn.edu.fudan.se.cfg.rq1.bean.DependencyLib;
import cn.edu.fudan.se.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class LibSortUtil {

    private static final String RANK_FILE_NAME = "F:/LibSort_Rank.json";

    public static void main(String[] args) {

        String content = FileUtil.read(RANK_FILE_NAME);
        List<DependencyLib> dependencyLibList = new Gson().fromJson(content, new TypeToken<List<DependencyLib>>() {
        }.getType());

        int totalSize = 20016;
        while (true) {

            Scanner sc = new Scanner(System.in);
            System.out.println("输入正数N，N表示排名前N%：");
            int N = sc.nextInt();

            int maxRank = (int) (totalSize * N * 1.0 / 100);

            List<DependencyLib> list = new ArrayList<>();
            for (DependencyLib dependencyLib : dependencyLibList) {
                if (dependencyLib.getRank() <= maxRank) {
                    list.add(dependencyLib);
                }
            }

            output(list, N);
        }

    }

    private static void output(List<DependencyLib> list, int N) {
        System.out.println("排名前" + String.valueOf(N) + "%的异常Jar包共： " + String.valueOf(list.size()));
        System.out.println("占总数933个的比例为： " + String.valueOf(list.size() * 1.0 / 933));
        System.out.println("占全部Jar包的比例为： " + String.valueOf(list.size() * 1.0 / 20016));

    }

}
