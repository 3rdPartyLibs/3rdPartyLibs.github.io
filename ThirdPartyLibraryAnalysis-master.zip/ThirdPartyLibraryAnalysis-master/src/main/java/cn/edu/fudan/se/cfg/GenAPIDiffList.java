package cn.edu.fudan.se.cfg;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
/**
 * api diff 两个json文件，load 为diff的info
 * @author huangkaifeng
 *
 */
public class GenAPIDiffList {
	
	/**
	 * <K,V> FileName,Tagged API List
	 */
	private Map<String,Map<String,JSONObject>> diffMap;
	
	public void generateAPIDiffList(String jsonAPath,String jsonBPath){
		
		Map<String,Map<String,JSONObject>> mapA = loadIntoMap(jsonAPath);
		Map<String,Map<String,JSONObject>> mapB = loadIntoMap(jsonBPath);
		diffMap = mapA;
		for(Entry<String,Map<String,JSONObject>> entry:mapB.entrySet()){
			String fileName = entry.getKey();
			Map<String,JSONObject> value = entry.getValue();
			for(Entry<String,JSONObject> entry2:value.entrySet()){
				String methodName = entry2.getKey();
				JSONObject job = entry2.getValue();
				compare(diffMap,fileName,methodName,job);				
			}
		}
		for(Entry<String,Map<String,JSONObject>> entry:diffMap.entrySet()){
			String fileName = entry.getKey();
			Map<String,JSONObject> value = entry.getValue();
			for(Entry<String,JSONObject> entry2:value.entrySet()){
				String methodName = entry2.getKey();
				JSONObject job = entry2.getValue();
				if(!job.containsKey("status")){
					//旧
					job.put("status", "delete");
				}
			}
		}
	}
	public void compare(Map<String,Map<String,JSONObject>> map,String fileName,String methodName,JSONObject job){
		if(map.containsKey(fileName)){
			Map<String,JSONObject> subMap = map.get(fileName);
			if(subMap.containsKey(methodName)){
				JSONObject job2 = subMap.get(methodName);
				String hashCode2 = job2.getString("hashcode");
				String hashCode = job.getString("hashcode");
				if(hashCode.equals(hashCode2)){
					//旧文件 一样方法
					job2.put("status", "equal");
				}else{
					//旧文件 方法变了
					job2.put("status", "change");
				}
			}else{
				//旧文件 新方法
				job.put("status","add");
				subMap.put(methodName, job);
			}
		}else{
			//新文件新方法
			Map<String,JSONObject> subMap = new HashMap<>();
			job.put("status", "add");
			subMap.put(methodName, job);
		}
	}
	
	
	
	public boolean checkMethodStatus(String filePath,String methodSinature){
		JSONObject jsonObj = diffMap.get(filePath).get(methodSinature);
		return (boolean)jsonObj.get("status");
	}
	
	
	
	
	public 	Map<String,Map<String,JSONObject>> loadIntoMap(String jsonPath){
		Map<String,Map<String,JSONObject>> map = new HashMap<String,Map<String,JSONObject>>();
		JSONArray array = JSONArray.fromObject(readFile(jsonPath));
		for(int i=0;i<array.size();i++){
			JSONObject job = (JSONObject)array.get(i);
			String fileName = job.getString("name");
			Map<String,JSONObject> methodNameObjMap = new HashMap<String,JSONObject>();
			JSONArray jArr = (JSONArray)job.get("api");
			for(int j =0;j<jArr.size();j++){
				JSONObject job2 = jArr.getJSONObject(j);
				String methodName = job2.getString("name");
				methodNameObjMap.put(methodName, job2);
			}
			map.put(fileName,methodNameObjMap);
			
		}
		return map;
	}
	
	
	private String readFile(String textFilePath){
		try {
			StringBuffer sb = new StringBuffer();
			FileInputStream fis = new FileInputStream(textFilePath);
			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(isr);
			String line;
			while((line = br.readLine())!= null){
				sb.append(line);
			}
			return sb.toString();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public static void main(String[] args){
		GenAPIDiffList diff = new GenAPIDiffList();
		String path = "E:/wangying/third_party_lib_apis";
		String libA = "accumulo-minicluster-1.6.6_decompile.json";
		String libB = "accumulo-minicluster-1.7.4_decompile.json";
		diff.generateAPIDiffList(path+"/"+libA,path+"/"+libB);
	}
	
	
	

}
