package cn.edu.fudan.se.git;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestMain {
    public static void main(String[] args) {

        String a = "sdafsdfHTTP-123HTTP-234";
        String reg = "HTTP-([0-9]+)";
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(a);
        while (matcher.find()) {

        }

    }
}
