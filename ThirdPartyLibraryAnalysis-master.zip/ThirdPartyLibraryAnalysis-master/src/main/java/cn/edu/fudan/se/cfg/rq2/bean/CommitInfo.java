package cn.edu.fudan.se.cfg.rq2.bean;

public class CommitInfo {
    String commitId;
    int time;
    String parentCommitId;

    public String getParentCommitId() {
        return parentCommitId;
    }

    public void setParentCommitId(String parentCommitId) {
        this.parentCommitId = parentCommitId;
    }

    public String getCommitId() {
        return commitId;
    }

    public void setCommitId(String commitId) {
        this.commitId = commitId;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public CommitInfo() {

    }

    public CommitInfo(String commitId,String parentCommitId, int time) {

        this.commitId = commitId;
        this.time = time;
        this.parentCommitId = parentCommitId;
    }
}
